import { pgTable, text, timestamp, uuid, index } from "drizzle-orm/pg-core";
import { usersTable } from "./users";

/**
 * A conversation. `kind` is either `group` (named, many members) or `direct`
 * (a private conversation between exactly two people). For direct rooms
 * `dmKey` holds the two member ids sorted and joined with `:` so a pair can
 * only ever have one private conversation.
 */
export const roomsTable = pgTable(
  "rooms",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    kind: text("kind").notNull().default("group"),
    name: text("name"),
    description: text("description"),
    colorKey: text("color_key").notNull().default("lilac"),
    picturePath: text("picture_path"),
    ownerId: uuid("owner_id").references(() => usersTable.id, {
      onDelete: "set null",
    }),
    dmKey: text("dm_key").unique(),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => [index("rooms_updated_at_idx").on(table.updatedAt)],
);

export type Room = typeof roomsTable.$inferSelect;
export type InsertRoom = typeof roomsTable.$inferInsert;
