import { pgTable, text, timestamp, uuid, index } from "drizzle-orm/pg-core";
import { usersTable } from "./users";

/**
 * Every presigned upload URL we hand out is recorded here so that later we can
 * tell who owns an object. Without this an object path is just a guessable
 * string that anyone could attach to their own message or avatar.
 */
export const uploadsTable = pgTable(
  "uploads",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    objectPath: text("object_path").notNull().unique(),
    uploaderId: uuid("uploader_id")
      .notNull()
      .references(() => usersTable.id, { onDelete: "cascade" }),
    fileName: text("file_name").notNull(),
    contentType: text("content_type").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => [index("uploads_uploader_idx").on(table.uploaderId)],
);

export type Upload = typeof uploadsTable.$inferSelect;
export type InsertUpload = typeof uploadsTable.$inferInsert;
