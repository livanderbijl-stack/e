import {
  pgTable,
  timestamp,
  uuid,
  uniqueIndex,
} from "drizzle-orm/pg-core";
import { roomsTable } from "./rooms";
import { usersTable } from "./users";

/**
 * One row per person currently in a room's video call. Rows are removed when
 * someone leaves or their realtime connection drops, so the presence of any
 * row for a room means a call is live.
 */
export const callParticipantsTable = pgTable(
  "call_participants",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    roomId: uuid("room_id")
      .notNull()
      .references(() => roomsTable.id, { onDelete: "cascade" }),
    userId: uuid("user_id")
      .notNull()
      .references(() => usersTable.id, { onDelete: "cascade" }),
    joinedAt: timestamp("joined_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => [
    uniqueIndex("call_participants_room_user_idx").on(table.roomId, table.userId),
  ],
);

export type CallParticipant = typeof callParticipantsTable.$inferSelect;
export type InsertCallParticipant = typeof callParticipantsTable.$inferInsert;
