import { pgTable, text, timestamp, uuid, index } from "drizzle-orm/pg-core";
import { messagesTable } from "./messages";

export const linkPreviewsTable = pgTable(
  "link_previews",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    messageId: uuid("message_id")
      .notNull()
      .references(() => messagesTable.id, { onDelete: "cascade" }),
    url: text("url").notNull(),
    title: text("title"),
    description: text("description"),
    imageUrl: text("image_url"),
    siteName: text("site_name"),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => [index("link_previews_message_idx").on(table.messageId)],
);

export type LinkPreview = typeof linkPreviewsTable.$inferSelect;
export type InsertLinkPreview = typeof linkPreviewsTable.$inferInsert;
