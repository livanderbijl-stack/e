export type MediaFailureKind =
  | 'denied'
  | 'blocked'
  | 'insecure'
  | 'notfound'
  | 'inuse'
  | 'unknown';

export type MediaFailure = {
  kind: MediaFailureKind;
  title: string;
  detail: string;
};

/**
 * getUserMedia rejects with the same DOMException name for very different
 * causes, so the message has to be inspected to tell "the person clicked block"
 * apart from "this frame was never allowed to ask".
 */
export function describeMediaFailure(error: unknown): MediaFailure {
  if (typeof navigator === 'undefined' || !navigator.mediaDevices?.getUserMedia) {
    return {
      kind: 'insecure',
      title: 'This browser will not share your camera here',
      detail:
        'Camera and microphone are only available over a secure (https) connection. Open the app in a new tab and try again.',
    };
  }

  const name = (error as { name?: string })?.name ?? '';
  const message = String((error as { message?: string })?.message ?? '');
  const policyBlocked = /permission(s)? policy|feature policy|disallowed by/i.test(message);

  if (name === 'NotAllowedError' && policyBlocked) {
    return {
      kind: 'blocked',
      title: 'The preview window is not allowed to use your camera',
      detail:
        'This page is embedded in another window, which blocks camera and microphone access before you can even be asked. Open the app in its own tab and the call will work.',
    };
  }

  if (name === 'NotAllowedError' || name === 'SecurityError') {
    return {
      kind: 'denied',
      title: 'Camera and microphone are blocked',
      detail:
        'Your browser is refusing access. Click the camera icon in the address bar, allow this site, then try again.',
    };
  }

  if (name === 'NotFoundError' || name === 'OverconstrainedError') {
    return {
      kind: 'notfound',
      title: 'No camera or microphone found',
      detail:
        'This device has nothing to capture with. Plug something in, or join the call to listen and watch instead.',
    };
  }

  if (name === 'NotReadableError' || name === 'AbortError') {
    return {
      kind: 'inuse',
      title: 'Something else is using your camera',
      detail:
        'Another app or tab has hold of it. Close that one, then try again.',
    };
  }

  return {
    kind: 'unknown',
    title: 'Could not start your camera',
    detail: message || 'The browser refused the request without saying why.',
  };
}

/** True when the app is running inside another page's frame (e.g. a preview pane). */
export function isEmbedded() {
  try {
    return window.self !== window.top;
  } catch {
    return true;
  }
}

type PeerState = {
  pc: RTCPeerConnection;
  polite: boolean;
  makingOffer: boolean;
  ignoreOffer: boolean;
  settingRemoteAnswer: boolean;
  /** Candidates that arrived before the description they belong to. */
  pendingCandidates: RTCIceCandidateInit[];
  /** Signals are applied one at a time; overlapping them corrupts the state. */
  queue: Promise<void>;
  restarted: boolean;
  inboundStream?: MediaStream;
  /** Receive-only slots created before camera permission finishes. */
  transceivers: Partial<Record<'audio' | 'video', RTCRtpTransceiver>>;
};

export class WebRTCManager {
  private peers = new Map<string, PeerState>();
  private localStream: MediaStream | null = null;
  private myId: string;
  private onRemoteStream: (userId: string, stream: MediaStream) => void;
  private sendSignal: (toUserId: string, signal: any) => void;
  /** Reports the peers that cannot be reached, updated as they recover. */
  onPeerTrouble?: (userIds: string[]) => void;
  private troubled = new Set<string>();
  private configuration: RTCConfiguration | null = null;

  configure(configuration: RTCConfiguration) {
    this.configuration = configuration;
  }

  constructor(
    myId: string,
    onRemoteStream: (userId: string, stream: MediaStream) => void,
    sendSignal: (toUserId: string, signal: any) => void,
  ) {
    this.myId = myId;
    this.onRemoteStream = onRemoteStream;
    this.sendSignal = sendSignal;
  }

  /** Resolves with the stream, or throws a MediaFailure the UI can show. */
  async initializeLocalStream(): Promise<MediaStream> {
    if (typeof navigator === 'undefined' || !navigator.mediaDevices?.getUserMedia) {
      throw describeMediaFailure(new Error('mediaDevices unavailable'));
    }

    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: true,
        audio: true,
      });
      this.localStream = stream;
      this.attachLocalTracks();
      return stream;
    } catch (error) {
      throw describeMediaFailure(error);
    }
  }

  /** Push newly acquired tracks into peers that were built without them. */
  private attachLocalTracks() {
    if (!this.localStream) return;

    for (const state of this.peers.values()) {
      const { pc } = state;
      for (const track of this.localStream.getTracks()) {
        const alreadySending = pc
          .getSenders()
          .some((sender) => sender.track?.id === track.id);
        if (alreadySending) continue;

        // addTrack only reuses a slot whose direction is allowed to send.
        // Convert our pre-permission recvonly slot first; otherwise addTrack
        // creates a second m-line and the original remote track stays muted.
        const kind = track.kind as 'audio' | 'video';
        const reserved = state.transceivers[kind];
        if (reserved && !reserved.sender.track) {
          reserved.direction = 'sendrecv';
        }

        // Passing the stream preserves its msid, so the far side can attach
        // both tracks to one MediaStream.
        pc.addTrack(track, this.localStream);
      }
    }
  }

  getLocalStream() {
    return this.localStream;
  }

  hasLocalStream() {
    return this.localStream !== null;
  }

  toggleAudio(enabled: boolean) {
    this.localStream?.getAudioTracks().forEach((t) => (t.enabled = enabled));
  }

  toggleVideo(enabled: boolean) {
    this.localStream?.getVideoTracks().forEach((t) => (t.enabled = enabled));
  }

  createPeer(userId: string) {
    const existing = this.peers.get(userId);
    if (existing) return existing.pc;

    if (!this.configuration) throw new Error('Call relay configuration is not ready');
    const pc = new RTCPeerConnection(this.configuration);

    // Perfect negotiation: the higher id yields when both sides offer at once,
    // which keeps a retry (someone granting permission mid-call) from wedging
    // the connection.
    const state: PeerState = {
      pc,
      polite: this.myId > userId,
      makingOffer: false,
      ignoreOffer: false,
      settingRemoteAnswer: false,
      pendingCandidates: [],
      queue: Promise.resolve(),
      restarted: false,
      transceivers: {},
    };
    this.peers.set(userId, state);

    if (this.localStream) {
      for (const track of this.localStream.getTracks()) {
        pc.addTrack(track, this.localStream);
      }
    } else {
      // No camera of our own — still tell the peer we want to receive theirs.
      state.transceivers.video = pc.addTransceiver('video', { direction: 'recvonly' });
      state.transceivers.audio = pc.addTransceiver('audio', { direction: 'recvonly' });
    }

    pc.ontrack = (event) => {
      // A track can arrive without a stream (a peer that used replaceTrack, so
      // no msid). Keep a per-peer stream so those tracks still reach the UI.
      let stream = event.streams[0];
      if (!stream) {
        state.inboundStream ??= new MediaStream();
        stream = state.inboundStream;
        if (!stream.getTracks().some((t) => t.id === event.track.id)) {
          stream.addTrack(event.track);
        }
      }
      this.onRemoteStream(userId, stream);
    };

    pc.onicecandidate = (event) => {
      if (event.candidate) {
        this.sendSignal(userId, { kind: 'ice', data: event.candidate });
      }
    };

    pc.onnegotiationneeded = async () => {
      try {
        state.makingOffer = true;
        await pc.setLocalDescription();
        this.sendSignal(userId, { kind: 'offer', data: pc.localDescription });
      } catch (error) {
        console.error('Failed to negotiate with peer', userId, error);
      } finally {
        state.makingOffer = false;
      }
    };

    pc.onconnectionstatechange = () => {
      if (pc.connectionState !== 'failed') {
        if (pc.connectionState === 'connected') {
          state.restarted = false;
          this.markTrouble(userId, false);
        }
        return;
      }

      // One ICE restart is worth trying; if it fails again the network is the
      // problem and the UI has to say so rather than showing a still avatar.
      if (state.restarted) {
        this.markTrouble(userId, true);
        return;
      }
      state.restarted = true;
      pc.restartIce();
    };

    return pc;
  }

  handleSignal(fromUserId: string, signal: any) {
    if (!this.peers.has(fromUserId)) this.createPeer(fromUserId);
    const state = this.peers.get(fromUserId);
    if (!state) return Promise.resolve();

    // Signals arrive in bursts. Applying two at once leaves the connection in
    // a state neither of them expected, so each peer drains its own in order.
    state.queue = state.queue
      .then(() => this.applySignal(state, fromUserId, signal))
      .catch((error: unknown) => {
        console.error('Failed to handle signal from', fromUserId, error);
      });

    return state.queue;
  }

  private async applySignal(state: PeerState, fromUserId: string, signal: any) {
    const { pc } = state;

    if (signal.kind === 'offer' || signal.kind === 'answer') {
      const description = new RTCSessionDescription(signal.data);
      const readyForOffer =
        !state.makingOffer &&
        (pc.signalingState === 'stable' || state.settingRemoteAnswer);
      const collision = description.type === 'offer' && !readyForOffer;

      state.ignoreOffer = !state.polite && collision;
      if (state.ignoreOffer) return;

      state.settingRemoteAnswer = description.type === 'answer';
      try {
        // An offer during a collision is applied with an implicit rollback.
        await pc.setRemoteDescription(description);
      } finally {
        state.settingRemoteAnswer = false;
      }

      await this.drainCandidates(state);

      if (description.type === 'offer') {
        await pc.setLocalDescription();
        this.sendSignal(fromUserId, { kind: 'answer', data: pc.localDescription });
      }
      return;
    }

    if (signal.kind === 'ice') {
      // A candidate can outrun the description it belongs to; holding it is
      // the difference between connecting and silently failing.
      if (!this.canApplyCandidate(pc, signal.data)) {
        state.pendingCandidates.push(signal.data);
        return;
      }
      try {
        await pc.addIceCandidate(new RTCIceCandidate(signal.data));
      } catch (error) {
        if (!state.ignoreOffer) throw error;
      }
    }
  }

  /**
   * A candidate belongs to one generation of the remote description. After an
   * ICE restart the old description is still in place, so matching on presence
   * alone would apply new-generation candidates to the old one and lose them.
   */
  private canApplyCandidate(pc: RTCPeerConnection, candidate: RTCIceCandidateInit) {
    const sdp = pc.remoteDescription?.sdp;
    if (!sdp) return false;

    const ufrag = candidate.usernameFragment;
    if (!ufrag) return true;

    return sdp
      .split('\n')
      .some((line) => line.trim() === `a=ice-ufrag:${ufrag}`);
  }

  private async drainCandidates(state: PeerState) {
    const queued = state.pendingCandidates.splice(0);
    for (const candidate of queued) {
      if (!this.canApplyCandidate(state.pc, candidate)) {
        // Belongs to a generation that has not arrived yet — keep holding it.
        state.pendingCandidates.push(candidate);
        continue;
      }
      try {
        await state.pc.addIceCandidate(new RTCIceCandidate(candidate));
      } catch (error) {
        console.warn('Dropped a stale ICE candidate', error);
      }
    }
  }

  private markTrouble(userId: string, inTrouble: boolean) {
    const changed = inTrouble
      ? !this.troubled.has(userId) && !!this.troubled.add(userId)
      : this.troubled.delete(userId);

    if (changed) this.onPeerTrouble?.([...this.troubled]);
  }

  removePeer(userId: string) {
    const state = this.peers.get(userId);
    if (state) {
      state.pc.close();
      this.peers.delete(userId);
    }
    this.markTrouble(userId, false);
  }

  cleanup() {
    this.peers.forEach((state) => state.pc.close());
    this.peers.clear();
    if (this.localStream) {
      this.localStream.getTracks().forEach((t) => t.stop());
      this.localStream = null;
    }
  }
}
