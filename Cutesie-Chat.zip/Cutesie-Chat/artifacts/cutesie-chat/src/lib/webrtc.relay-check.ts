import { WebRTCManager } from './webrtc';

/**
 * Development regression harness. Run in Chromium with fake media flags:
 * --use-fake-device-for-media-stream --use-fake-ui-for-media-stream
 * Import this module through Vite and pass the authenticated /call/ice response.
 * Never log the configuration: it contains temporary TURN credentials.
 * Checks the real manager over forced TURN, not just SDP/ontrack/self preview.
 */
export async function checkForcedRelay(config: RTCConfiguration) {
  const videos: HTMLVideoElement[] = [];
  const receive = (_id: string, stream: MediaStream) => {
    const video = document.createElement('video');
    video.muted = true;
    video.autoplay = true;
    video.srcObject = stream;
    document.body.append(video);
    videos.push(video);
    void video.play();
  };
  const left = new WebRTCManager('relay-test-a', receive, (_id, signal) => {
    void right.handleSignal('relay-test-a', signal);
  });
  const right = new WebRTCManager('relay-test-b', receive, (_id, signal) => {
    void left.handleSignal('relay-test-b', signal);
  });
  left.configure({ ...config, iceTransportPolicy: 'relay' });
  right.configure({ ...config, iceTransportPolicy: 'relay' });
  try {
    await Promise.all([left.initializeLocalStream(), right.initializeLocalStream()]);
    const peers = [left.createPeer('relay-test-b'), right.createPeer('relay-test-a')];
    const deadline = Date.now() + 40000;
    while (Date.now() < deadline) {
      const results = await Promise.all(peers.map(async pc => {
        const stats = await pc.getStats();
        let framesDecoded = 0;
        let selectedRelay = false;
        stats.forEach(s => {
          if (s.type === 'inbound-rtp' && s.kind === 'video') {
            framesDecoded += s.framesDecoded || 0;
          }
          if (s.type === 'transport' && s.selectedCandidatePairId) {
            const pair = stats.get(s.selectedCandidatePairId);
            selectedRelay = !!pair && stats.get(pair.localCandidateId)?.candidateType === 'relay'
              && stats.get(pair.remoteCandidateId)?.candidateType === 'relay';
          }
        });
        return { framesDecoded, selectedRelay, connected: pc.connectionState === 'connected' };
      }));
      if (results.every(r => r.connected && r.selectedRelay && r.framesDecoded > 0)) return results;
      await new Promise(resolve => setTimeout(resolve, 250));
    }
    throw new Error('Forced relay failed: both peers must select relay candidates and decode inbound video frames.');
  } finally {
    left.cleanup();
    right.cleanup();
    videos.forEach(video => { video.srcObject = null; video.remove(); });
  }
}