export const ACCENT_COLORS = [
  'blush',
  'lilac',
  'mint',
  'butter',
  'sky',
  'peach',
] as const;

export type AccentColor = typeof ACCENT_COLORS[number];

export function getAccentClasses(colorKey: string | undefined | null) {
  const key = (colorKey || 'blush') as AccentColor;
  
  const map: Record<AccentColor, { bg: string; border: string; text: string; ring: string }> = {
    blush: {
      bg: 'bg-[hsl(var(--cutesie-blush))]',
      border: 'border-[hsl(var(--cutesie-blush))]',
      text: 'text-[hsl(var(--cutesie-blush))]',
      ring: 'ring-[hsl(var(--cutesie-blush))]',
    },
    lilac: {
      bg: 'bg-[hsl(var(--cutesie-lilac))]',
      border: 'border-[hsl(var(--cutesie-lilac))]',
      text: 'text-[hsl(var(--cutesie-lilac))]',
      ring: 'ring-[hsl(var(--cutesie-lilac))]',
    },
    mint: {
      bg: 'bg-[hsl(var(--cutesie-mint))]',
      border: 'border-[hsl(var(--cutesie-mint))]',
      text: 'text-[hsl(var(--cutesie-mint))]',
      ring: 'ring-[hsl(var(--cutesie-mint))]',
    },
    butter: {
      bg: 'bg-[hsl(var(--cutesie-butter))]',
      border: 'border-[hsl(var(--cutesie-butter))]',
      text: 'text-[hsl(var(--cutesie-butter))]',
      ring: 'ring-[hsl(var(--cutesie-butter))]',
    },
    sky: {
      bg: 'bg-[hsl(var(--cutesie-sky))]',
      border: 'border-[hsl(var(--cutesie-sky))]',
      text: 'text-[hsl(var(--cutesie-sky))]',
      ring: 'ring-[hsl(var(--cutesie-sky))]',
    },
    peach: {
      bg: 'bg-[hsl(var(--cutesie-peach))]',
      border: 'border-[hsl(var(--cutesie-peach))]',
      text: 'text-[hsl(var(--cutesie-peach))]',
      ring: 'ring-[hsl(var(--cutesie-peach))]',
    },
  };

  return map[ACCENT_COLORS.includes(key as AccentColor) ? key : 'blush'];
}
