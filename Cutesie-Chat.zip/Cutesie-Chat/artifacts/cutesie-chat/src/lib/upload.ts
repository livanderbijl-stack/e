import { useRequestUploadUrl } from '@workspace/api-client-react';
import { useState, useCallback, useRef } from 'react';

export function useDirectUpload() {
  const [isUploading, setIsUploading] = useState(false);
  const [progress, setProgress] = useState(0);
  const requestUploadUrl = useRequestUploadUrl();

  const uploadFile = useCallback(async (file: File) => {
    setIsUploading(true);
    setProgress(0);
    try {
      const res = await requestUploadUrl.mutateAsync({
        data: {
          name: file.name,
          size: file.size,
          contentType: file.type,
        }
      });
      
      const { uploadURL, objectPath } = res;
      
      return new Promise<{ objectPath: string }>((resolve, reject) => {
        const xhr = new XMLHttpRequest();
        xhr.open('PUT', uploadURL, true);
        xhr.setRequestHeader('Content-Type', file.type);
        
        xhr.upload.onprogress = (e) => {
          if (e.lengthComputable) {
            setProgress(Math.round((e.loaded / e.total) * 100));
          }
        };
        
        xhr.onload = () => {
          if (xhr.status >= 200 && xhr.status < 300) {
            resolve({ objectPath });
          } else {
            reject(new Error(`Upload failed with status ${xhr.status}`));
          }
        };
        
        xhr.onerror = () => reject(new Error('Upload failed'));
        
        xhr.send(file);
      });
    } finally {
      setIsUploading(false);
      setProgress(0);
    }
  }, [requestUploadUrl.mutateAsync]);

  return { uploadFile, isUploading, progress };
}
