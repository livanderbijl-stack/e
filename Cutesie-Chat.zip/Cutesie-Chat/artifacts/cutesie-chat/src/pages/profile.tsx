import { useGetMe, useUpdateMe } from '@workspace/api-client-react';
import { useDirectUpload } from '@/lib/upload';
import { ACCENT_COLORS, getAccentClasses } from '@/lib/theme';
import { useState, useEffect, useRef } from 'react';
import { Camera, Check, Loader2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';

export default function Profile() {
  const { data: me } = useGetMe();
  const updateMe = useUpdateMe();
  const { uploadFile, isUploading } = useDirectUpload();
  const { toast } = useToast();

  const [displayName, setDisplayName] = useState('');
  const [username, setUsername] = useState('');
  const [bio, setBio] = useState('');
  const [accent, setAccent] = useState('blush');

  useEffect(() => {
    if (me) {
      setDisplayName(me.displayName);
      setUsername(me.username);
      setBio(me.bio || '');
      setAccent(me.accentColor || 'blush');
    }
  }, [me]);

  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await updateMe.mutateAsync({
        data: { displayName, username, bio, accentColor: accent }
      });
      toast({ title: 'Profile updated!', description: 'Your fort identity is fresh.' });
    } catch (e: any) {
      toast({ title: 'Failed to update', description: e.message || 'Something went wrong.', variant: 'destructive' });
    }
  };

  const handleAvatarChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      const { objectPath } = await uploadFile(file);
      await updateMe.mutateAsync({ data: { avatarObjectPath: objectPath } });
      toast({ title: 'Avatar updated!' });
    } catch (err: any) {
      toast({ title: 'Upload failed', description: err.message, variant: 'destructive' });
    }
  };

  if (!me) return null;

  const currentColors = getAccentClasses(accent);

  return (
    <div className="h-full flex flex-col p-6 max-w-2xl mx-auto overflow-y-auto">
      <header className="mb-8">
        <h2 className="font-display font-bold text-4xl text-foreground">Your Profile</h2>
      </header>

      <form onSubmit={handleSave} className="bg-white/50 border-4 border-white rounded-3xl p-6 shadow-sm space-y-8">
        {/* Avatar section */}
        <div className="flex flex-col items-center">
          <div className={`relative w-32 h-32 rounded-[2rem] border-4 border-white shadow-md transform rotate-3 flex items-center justify-center ${currentColors.bg} ${currentColors.text} font-display font-bold text-5xl transition-colors`}>
            {isUploading ? (
              <Loader2 className="w-8 h-8 animate-spin" />
            ) : me.avatarUrl ? (
              <img src={me.avatarUrl} alt="" className="w-full h-full rounded-[1.75rem] object-cover" />
            ) : (
              displayName[0]?.toUpperCase() || '?'
            )}
            
            <button 
              type="button"
              onClick={() => fileInputRef.current?.click()}
              disabled={isUploading}
              className="absolute -bottom-3 -right-3 w-12 h-12 bg-white border-2 border-border rounded-xl flex items-center justify-center text-foreground hover:bg-black/5 shadow-sm transform -rotate-6"
            >
              <Camera className="w-5 h-5" />
            </button>
            <input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={handleAvatarChange} />
          </div>
        </div>

        {/* Accent color picker */}
        <div>
          <label className="block text-sm font-bold text-muted-foreground uppercase tracking-wider mb-3 text-center">Fort Color</label>
          <div className="flex justify-center gap-3">
            {ACCENT_COLORS.map(c => {
              const cls = getAccentClasses(c);
              return (
                <button
                  key={c}
                  type="button"
                  onClick={() => setAccent(c)}
                  className={`w-10 h-10 rounded-full border-2 border-white shadow-sm flex items-center justify-center transition-transform ${cls.bg} ${accent === c ? 'scale-110 ring-4 ring-black/10' : 'hover:scale-105'}`}
                >
                  {accent === c && <Check className={`w-5 h-5 ${cls.text}`} />}
                </button>
              )
            })}
          </div>
        </div>

        {/* Inputs */}
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-bold text-foreground mb-1">Display Name</label>
            <input 
              required minLength={1} maxLength={40}
              type="text" 
              value={displayName} onChange={e => setDisplayName(e.target.value)}
              className="w-full bg-white border-2 border-border rounded-xl px-4 py-3 font-medium outline-none focus:ring-4 focus:ring-primary/20" 
            />
          </div>
          <div>
            <label className="block text-sm font-bold text-foreground mb-1">Username</label>
            <input 
              required minLength={2} maxLength={24}
              type="text" 
              value={username} onChange={e => setUsername(e.target.value)}
              className="w-full bg-white border-2 border-border rounded-xl px-4 py-3 font-medium outline-none focus:ring-4 focus:ring-primary/20" 
            />
          </div>
          <div>
            <label className="block text-sm font-bold text-foreground mb-1">Bio</label>
            <textarea 
              maxLength={200}
              value={bio} onChange={e => setBio(e.target.value)}
              className="w-full bg-white border-2 border-border rounded-xl px-4 py-3 font-medium outline-none focus:ring-4 focus:ring-primary/20 min-h-[100px] resize-none" 
            />
          </div>
        </div>

        <Button 
          type="submit" 
          disabled={updateMe.isPending}
          className="w-full h-14 rounded-xl text-lg font-bold border-2 border-primary-foreground/10 shadow-sm"
        >
          {updateMe.isPending ? 'Saving...' : 'Save Profile'}
        </Button>
      </form>
    </div>
  );
}
