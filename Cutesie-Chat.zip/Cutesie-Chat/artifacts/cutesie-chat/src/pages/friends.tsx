import { useState } from 'react';
import { useListFriends, useListFriendRequests, useSearchUsers, getSearchUsersQueryKey, useSendFriendRequest, useAcceptFriendRequest, useDeclineFriendRequest, useRemoveFriend, useOpenDirectMessage, getListFriendsQueryKey, getListFriendRequestsQueryKey, getGetHomeSummaryQueryKey, getListRoomsQueryKey } from '@workspace/api-client-react';
import { useQueryClient } from '@tanstack/react-query';
import { getAccentClasses } from '@/lib/theme';
import { Search, UserPlus, X, Check, MessageSquare } from 'lucide-react';
import { useLocation } from 'wouter';
import { motion } from 'framer-motion';

// Mutations here change friends, requests and the home badge at once, and the
// realtime feed only notifies the *other* person — so the actor has to refetch
// its own view explicitly.
function useRefreshFriendData() {
  const queryClient = useQueryClient();

  return () =>
    Promise.all([
      queryClient.invalidateQueries({ queryKey: getListFriendsQueryKey() }),
      queryClient.invalidateQueries({ queryKey: getListFriendRequestsQueryKey() }),
      queryClient.invalidateQueries({ queryKey: getGetHomeSummaryQueryKey() }),
      queryClient.invalidateQueries({ queryKey: getListRoomsQueryKey() }),
    ]);
}

export default function Friends() {
  const [activeTab, setActiveTab] = useState<'friends' | 'requests' | 'add'>('friends');
  const [, setLocation] = useLocation();

  const { data: friends } = useListFriends();
  const { data: requests } = useListFriendRequests();
  const pendingCount = (requests?.incoming.length || 0);

  return (
    <div className="h-full flex flex-col p-6 max-w-4xl mx-auto overflow-hidden">
      <header className="mb-6 flex-shrink-0">
        <h2 className="font-display font-bold text-4xl text-foreground">Friends</h2>
      </header>

      <div className="flex gap-2 mb-6 flex-shrink-0 overflow-x-auto pb-2">
        <TabButton active={activeTab === 'friends'} onClick={() => setActiveTab('friends')}>
          My Circle ({friends?.length || 0})
        </TabButton>
        <TabButton active={activeTab === 'requests'} onClick={() => setActiveTab('requests')}>
          Requests {pendingCount > 0 && <span className="ml-2 bg-destructive text-destructive-foreground px-2 py-0.5 rounded-full text-xs">{pendingCount}</span>}
        </TabButton>
        <TabButton active={activeTab === 'add'} onClick={() => setActiveTab('add')}>
          Add Friend
        </TabButton>
      </div>

      <div className="flex-1 overflow-y-auto bg-white/50 border-4 border-white rounded-3xl shadow-sm p-2">
        {activeTab === 'friends' && <FriendsList friends={friends} />}
        {activeTab === 'requests' && <RequestsList requests={requests} />}
        {activeTab === 'add' && <AddFriend />}
      </div>
    </div>
  );
}

function TabButton({ active, children, onClick }: any) {
  return (
    <button
      onClick={onClick}
      className={`px-4 py-2 rounded-2xl font-bold whitespace-nowrap transition-colors ${
        active 
          ? 'bg-white text-foreground shadow-sm border-2 border-border' 
          : 'bg-transparent text-muted-foreground hover:bg-white/60 border-2 border-transparent'
      }`}
    >
      {children}
    </button>
  );
}

function FriendsList({ friends }: { friends: any[] | undefined }) {
  const refresh = useRefreshFriendData();
  const openDm = useOpenDirectMessage();
  const removeFriend = useRemoveFriend({ mutation: { onSuccess: refresh } });
  const [, setLocation] = useLocation();

  if (!friends?.length) {
    return (
      <div className="h-full flex flex-col items-center justify-center p-6 text-center">
        <div className="w-24 h-24 bg-cutesie-blush/30 rounded-3xl rotate-12 mb-4 flex items-center justify-center">
          <UserPlus className="w-10 h-10 text-cutesie-blush" />
        </div>
        <h3 className="font-display font-bold text-2xl text-foreground mb-2">No friends yet</h3>
        <p className="text-muted-foreground max-w-sm">It's a bit lonely in the fort. Add some friends to start chatting!</p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-3 p-2">
      {friends.map(friend => {
        const colors = getAccentClasses(friend.user.accentColor);
        return (
          <motion.div key={friend.user.id} layout className="flex items-center gap-3 p-3 bg-white border-2 border-border rounded-2xl shadow-sm">
            <div className={`w-12 h-12 rounded-full border-2 border-white shadow-sm flex-shrink-0 flex items-center justify-center ${colors.bg} ${colors.text} font-display font-bold text-xl`}>
              {friend.user.avatarUrl ? (
                <img src={friend.user.avatarUrl} alt="" className="w-full h-full rounded-full object-cover" />
              ) : friend.user.displayName[0].toUpperCase()}
            </div>
            <div className="flex-1 min-w-0">
              <div className="font-bold text-foreground truncate">{friend.user.displayName}</div>
              <div className="text-xs text-muted-foreground truncate">@{friend.user.username}</div>
            </div>
            <div className="flex gap-2">
              <button 
                onClick={async () => {
                  const room = await openDm.mutateAsync({ data: { userId: friend.user.id } });
                  setLocation(`/chat/${room.id}`);
                }}
                className="w-10 h-10 rounded-xl bg-cutesie-mint/20 text-cutesie-mint flex items-center justify-center hover:bg-cutesie-mint hover:text-white transition-colors"
                title="Message"
              >
                <MessageSquare className="w-5 h-5" />
              </button>
              <button 
                onClick={() => {
                  if (confirm('Remove friend?')) removeFriend.mutate({ userId: friend.user.id });
                }}
                className="w-10 h-10 rounded-xl bg-destructive/10 text-destructive flex items-center justify-center hover:bg-destructive hover:text-white transition-colors"
                title="Remove"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </motion.div>
        );
      })}
    </div>
  );
}

function RequestsList({ requests }: { requests: any }) {
  const refresh = useRefreshFriendData();
  const accept = useAcceptFriendRequest({ mutation: { onSuccess: refresh } });
  const decline = useDeclineFriendRequest({ mutation: { onSuccess: refresh } });

  const incoming = requests?.incoming || [];
  const outgoing = requests?.outgoing || [];

  if (incoming.length === 0 && outgoing.length === 0) {
    return (
      <div className="h-full flex items-center justify-center text-muted-foreground font-medium">
        No pending requests.
      </div>
    );
  }

  return (
    <div className="p-2 space-y-6">
      {incoming.length > 0 && (
        <section>
          <h3 className="text-xs font-bold text-muted-foreground uppercase tracking-wider mb-3 px-2">Incoming</h3>
          <div className="space-y-3">
            {incoming.map((req: any) => {
              const colors = getAccentClasses(req.user.accentColor);
              return (
                <div key={req.id} className="flex items-center gap-3 p-3 bg-white border-2 border-border rounded-2xl shadow-sm">
                  <div className={`w-10 h-10 rounded-full flex-shrink-0 flex items-center justify-center ${colors.bg} ${colors.text} font-bold`}>
                    {req.user.avatarUrl ? <img src={req.user.avatarUrl} className="w-full h-full rounded-full object-cover" alt="" /> : req.user.displayName[0]}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="font-bold text-foreground truncate">{req.user.displayName}</div>
                    {req.note && <div className="text-sm text-muted-foreground italic">"{req.note}"</div>}
                  </div>
                  <div className="flex gap-2">
                    <button 
                      onClick={() => accept.mutate({ requestId: req.id })}
                      className="p-2 rounded-xl bg-green-100 text-green-600 hover:bg-green-500 hover:text-white transition-colors"
                    >
                      <Check className="w-5 h-5" />
                    </button>
                    <button 
                      onClick={() => decline.mutate({ requestId: req.id })}
                      className="p-2 rounded-xl bg-destructive/10 text-destructive hover:bg-destructive hover:text-white transition-colors"
                    >
                      <X className="w-5 h-5" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </section>
      )}

      {outgoing.length > 0 && (
        <section>
          <h3 className="text-xs font-bold text-muted-foreground uppercase tracking-wider mb-3 px-2">Outgoing</h3>
          <div className="space-y-3">
            {outgoing.map((req: any) => (
              <div key={req.id} className="flex items-center gap-3 p-3 bg-white border-2 border-border rounded-2xl opacity-60">
                <div className="w-10 h-10 rounded-full bg-border flex-shrink-0" />
                <div className="flex-1 min-w-0 font-bold truncate">{req.user.displayName}</div>
                <button 
                  onClick={() => decline.mutate({ requestId: req.id })}
                  className="px-3 py-1 text-sm font-bold text-muted-foreground hover:text-destructive"
                >
                  Cancel
                </button>
              </div>
            ))}
          </div>
        </section>
      )}
    </div>
  );
}

function AddFriend() {
  const [rawQuery, setRawQuery] = useState('');
  // People type the handle as they see it (@name); the API wants the bare username.
  const query = rawQuery.trim().replace(/^@+/, '');
  const queryClient = useQueryClient();
  const refresh = useRefreshFriendData();
  const { data: results, isLoading } = useSearchUsers({ q: query }, { query: { enabled: query.length > 1, queryKey: getSearchUsersQueryKey({ q: query }) } });
  const sendRequest = useSendFriendRequest({
    mutation: {
      onSuccess: async () => {
        await refresh();
        await queryClient.invalidateQueries({ queryKey: getSearchUsersQueryKey({ q: query }) });
      },
    },
  });

  return (
    <div className="p-4 max-w-lg mx-auto">
      <div className="relative mb-6">
        <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
          <Search className="w-5 h-5 text-muted-foreground" />
        </div>
        <input 
          type="text" 
          value={rawQuery}
          onChange={e => setRawQuery(e.target.value)}
          placeholder="Search by username or display name..."
          className="w-full bg-white border-2 border-border rounded-2xl py-3 pl-12 pr-4 text-foreground font-medium focus:ring-4 focus:ring-primary/20 outline-none transition-shadow"
        />
      </div>

      <div className="space-y-3">
        {isLoading && query.length > 1 && <div className="text-center text-muted-foreground">Searching...</div>}
        
        {results?.map(res => {
          const colors = getAccentClasses(res.user.accentColor);
          const isFriend = res.relationship === 'friends';
          const isSent = res.relationship === 'request_sent';
          
          return (
            <div key={res.user.id} className="flex items-center gap-3 p-3 bg-white border-2 border-border rounded-2xl shadow-sm">
              <div className={`w-12 h-12 rounded-full border-2 border-white shadow-sm flex-shrink-0 flex items-center justify-center ${colors.bg} ${colors.text} font-display font-bold text-xl`}>
                {res.user.avatarUrl ? <img src={res.user.avatarUrl} className="w-full h-full rounded-full object-cover" alt="" /> : res.user.displayName[0]}
              </div>
              <div className="flex-1 min-w-0">
                <div className="font-bold text-foreground truncate">{res.user.displayName}</div>
                <div className="text-xs text-muted-foreground truncate">@{res.user.username}</div>
              </div>
              {isFriend ? (
                <div className="px-3 py-1 bg-black/5 text-muted-foreground text-sm font-bold rounded-xl">Friends</div>
              ) : isSent ? (
                <div className="px-3 py-1 bg-primary/20 text-primary-foreground text-sm font-bold rounded-xl">Sent</div>
              ) : res.relationship === 'self' ? null : (
                <button 
                  onClick={() => sendRequest.mutate({ data: { username: res.user.username } })}
                  className="w-10 h-10 rounded-xl bg-primary text-primary-foreground flex items-center justify-center hover:brightness-95 transition-colors shadow-sm"
                >
                  <UserPlus className="w-5 h-5" />
                </button>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
