import { useCallback, useEffect, useRef, useState, type ReactNode } from 'react';
import { createCallIce, useJoinCall, useLeaveCall, useGetCall, useGetMe, useGetRoom } from '@workspace/api-client-react';
import { WebRTCManager, isEmbedded, type MediaFailure } from '@/lib/webrtc';
import { useRealtime } from '@/lib/realtime';
import { getAccentClasses } from '@/lib/theme';
import { Mic, MicOff, Video as VideoIcon, VideoOff, PhoneOff, RotateCcw, ExternalLink } from 'lucide-react';
import { useLocation } from 'wouter';

export default function Call({ params }: { params: { roomId: string } }) {
  const { roomId } = params;
  const [, setLocation] = useLocation();
  const { data: me } = useGetMe();
  const joinCall = useJoinCall();
  const leaveCall = useLeaveCall();
  const { data: initialCall } = useGetCall(roomId);
  const { data: room } = useGetRoom(roomId);
  
  const { send, callStates, callSignals, connected } = useRealtime();
  const [relayError, setRelayError] = useState<string | null>(null);
  
  const [streams, setStreams] = useState<Record<string, MediaStream>>({});
  const [localStream, setLocalStream] = useState<MediaStream | null>(null);
  const [mediaError, setMediaError] = useState<MediaFailure | null>(null);
  const [retrying, setRetrying] = useState(false);
  const [audioEnabled, setAudioEnabled] = useState(true);
  const [videoEnabled, setVideoEnabled] = useState(true);
  
  const [joinFailed, setJoinFailed] = useState(false);
  const [peerTrouble, setPeerTrouble] = useState(false);
  const [rtcReady, setRtcReady] = useState(false);
  const [joinedReady, setJoinedReady] = useState(false);

  const rtcRef = useRef<WebRTCManager | null>(null);
  const localVideoRef = useRef<HTMLVideoElement>(null);
  const signalCursor = useRef<number | null>(null);
  const callSignalsRef = useRef(callSignals);
  callSignalsRef.current = callSignals;
  const callState = callStates[roomId] || initialCall;
  const myId = me?.id;

  useEffect(() => {
    if (!myId || !connected) return;
    setStreams({});
    setLocalStream(null);
    setRelayError(null);
    setPeerTrouble(false);

    // Built before the join round-trip so a signal that arrives while joining
    // still has somewhere to land.
    const rtc = new WebRTCManager(
      myId,
      (userId, stream) => setStreams(prev => ({ ...prev, [userId]: stream })),
      (toUserId, signal) => send({ type: 'call:signal', roomId, toUserId, signal }),
    );
    rtc.onPeerTrouble = (userIds) => setPeerTrouble(userIds.length > 0);
    rtcRef.current = rtc;
    signalCursor.current = callSignalsRef.current.length;
    setRtcReady(false);
    setJoinedReady(false);

    let active = true;
    // A failed join may still have been committed before the response was
    // lost, so it counts as settled: leaving is idempotent, a ghost is not.
    let joinSettled = false;

    (async () => {
      try {
        const config = await createCallIce(roomId);
        if (!active) return;
        rtc.configure(config);
        setRtcReady(true);
      } catch (error) {
        if (active) {
          setRelayError(error instanceof Error ? error.message : 'Call relay is unavailable.');
          rtc.cleanup();
          if (rtcRef.current === rtc) rtcRef.current = null;
        }
        return;
      }
      // Ask for media before announcing the participant. Peers then normally
      // start with sendrecv tracks and do not need a second offer merely to
      // begin sending the camera.
      try {
        const ls = await rtc.initializeLocalStream();
        if (!active) {
          ls.getTracks().forEach(t => t.stop());
          return;
        }
        setLocalStream(ls);
        setMediaError(null);
      } catch (failure) {
        if (!active) return;
        setMediaError(failure as MediaFailure);
      }

      try {
        await joinCall.mutateAsync({ roomId });
        joinSettled = true;
      } catch {
        joinSettled = true;
        if (active) {
          rtc.cleanup();
          if (rtcRef.current === rtc) rtcRef.current = null;
          setLocalStream(null);
          setRtcReady(false);
          setJoinFailed(true);
        } else {
          leaveCall.mutate({ roomId });
        }
        return;
      }

      // Leaving mid-join would delete the participant before it was created,
      // stranding a ghost in the call, so the leave waits for the join.
      if (!active) {
        leaveCall.mutate({ roomId });
        return;
      }
      setJoinFailed(false);
      setJoinedReady(true);
    })();

    return () => {
      active = false;
      setRtcReady(false);
      setJoinedReady(false);
      signalCursor.current = null;
      if (joinSettled) leaveCall.mutate({ roomId });
      rtc.cleanup();
      if (rtcRef.current === rtc) rtcRef.current = null;
    };
  }, [roomId, myId, connected]);

  // The <video> element mounts after the stream lands in state, so binding the
  // stream inside init() would attach it to an element that does not exist yet.
  useEffect(() => {
    const el = localVideoRef.current;
    if (el && localStream && el.srcObject !== localStream) {
      el.srcObject = localStream;
    }
  }, [localStream]);

  const retryMedia = useCallback(async () => {
    const rtc = rtcRef.current;
    if (!rtc || retrying) return;

    setRetrying(true);
    try {
      const ls = await rtc.initializeLocalStream();
      // The call may have been left while the permission prompt was open.
      if (rtcRef.current !== rtc) {
        ls.getTracks().forEach(t => t.stop());
        return;
      }
      setLocalStream(ls);
      setMediaError(null);
      setAudioEnabled(true);
      setVideoEnabled(true);
    } catch (failure) {
      if (rtcRef.current === rtc) setMediaError(failure as MediaFailure);
    } finally {
      setRetrying(false);
    }
  }, [retrying]);

  // Every signal has to be handled exactly once and in arrival order — taking
  // only the newest one drops whole offers when frames land in the same batch.
  useEffect(() => {
    const rtc = rtcRef.current;
    if (!rtc || !rtcReady || signalCursor.current === null) return;

    const pending = callSignals.slice(signalCursor.current);
    if (pending.length === 0) return;
    signalCursor.current = callSignals.length;

    for (const frame of pending) {
      if (frame.roomId === roomId && frame.toUserId === myId) {
        void rtc.handleSignal(frame.fromUserId, frame.signal);
      }
    }
  }, [callSignals, roomId, myId, rtcReady]);

  // Handle call state updates to remove peers who left
  useEffect(() => {
    if (joinedReady && callState?.participants && me) {
      const currentIds = new Set(callState.participants.map((p: any) => p.user.id));
      Object.keys(streams).forEach(peerId => {
        if (!currentIds.has(peerId)) {
          rtcRef.current?.removePeer(peerId);
          setStreams(prev => {
            const next = { ...prev };
            delete next[peerId];
            return next;
          });
        }
      });
      // also connect to new peers
      callState.participants.forEach((p: any) => {
        if (p.user.id !== me.id && rtcRef.current) {
          rtcRef.current.createPeer(p.user.id);
        }
      });
    }
    // rtcReady is a dependency so participants already in the call get peers
    // as soon as the manager exists. createPeer is idempotent.
  }, [callState, me?.id, rtcReady, joinedReady]);

  const toggleAudio = () => {
    setAudioEnabled(v => {
      rtcRef.current?.toggleAudio(!v);
      return !v;
    });
  };

  const toggleVideo = () => {
    setVideoEnabled(v => {
      rtcRef.current?.toggleVideo(!v);
      return !v;
    });
  };

  const handleLeave = () => {
    setLocation(`/chat/${roomId}`);
  };

  return (
    <div className="h-[100dvh] w-full bg-background flex flex-col relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-cutesie-mint/20 to-cutesie-sky/20 z-0" />
      
      <header className="relative z-10 p-6 flex justify-between items-center text-center">
        <div className="w-full flex justify-center items-center gap-3">
          {room && <div className={`w-11 h-11 rounded-xl border-2 border-white overflow-hidden flex items-center justify-center font-bold ${getAccentClasses(room.colorKey).bg} ${getAccentClasses(room.colorKey).text}`}>
            {(room.kind === 'group' ? room.pictureUrl : room.otherUser?.avatarUrl)
              ? <img src={(room.kind === 'group' ? room.pictureUrl : room.otherUser?.avatarUrl)!} alt="" className="w-full h-full object-cover" />
              : room.name[0]?.toUpperCase()}
          </div>}
          <h2 className="font-display font-bold text-2xl text-foreground">{callState?.roomName || 'Call'}</h2>
        </div>
      </header>

      {(relayError || !connected) && (
        <div role="alert" className="relative z-20 mx-auto max-w-2xl rounded-3xl bg-white/90 p-4">
          <p className="font-display font-bold">Call connection unavailable</p>
          <p className="text-sm">{relayError || 'Reconnecting to the call signaling service…'}</p>
          {relayError && <p className="text-sm">Hang up and retry after the relay connection is restored.</p>}
        </div>
      )}
      {joinFailed && (
        <div className="relative z-20 px-4 pb-2">
          <div
            role="alert"
            className="mx-auto w-full max-w-2xl bg-white/90 backdrop-blur border-4 border-white shadow-lg rounded-3xl p-4"
          >
            <p className="font-display font-bold text-foreground">Couldn't join the call</p>
            <p className="text-sm text-muted-foreground">
              Nobody can see you in here yet. Hang up and start the call again.
            </p>
          </div>
        </div>
      )}

      {peerTrouble && !joinFailed && (
        <div className="relative z-20 px-4 pb-2">
          <div
            role="alert"
            className="mx-auto w-full max-w-2xl bg-white/90 backdrop-blur border-4 border-white shadow-lg rounded-3xl p-4"
          >
            <p className="font-display font-bold text-foreground">Trouble reaching someone</p>
            <p className="text-sm text-muted-foreground">
              The connection to someone in this call keeps dropping. It's usually a wifi
              or firewall problem on one side.
            </p>
          </div>
        </div>
      )}

      {mediaError && (
        <div className="relative z-20 px-4 pb-2">
          <div
            role="alert"
            className="mx-auto w-full max-w-2xl bg-white/90 backdrop-blur border-4 border-white shadow-lg rounded-3xl p-4 flex flex-col sm:flex-row sm:items-center gap-3"
          >
            <div className="flex-1 min-w-0">
              <p className="font-display font-bold text-foreground">{mediaError.title}</p>
              <p className="text-sm text-muted-foreground">{mediaError.detail}</p>
              <p className="text-xs text-muted-foreground mt-1">
                You're still in the call — you can see and hear everyone else.
              </p>
            </div>
            <div className="flex gap-2 shrink-0">
              {(mediaError.kind === 'blocked' || mediaError.kind === 'insecure' || isEmbedded()) && (
                <a
                  href={window.location.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-4 py-2 rounded-full bg-primary/25 hover:bg-primary/40 font-bold text-sm flex items-center gap-2 transition-colors"
                >
                  <ExternalLink className="w-4 h-4" />
                  New tab
                </a>
              )}
              <button
                onClick={retryMedia}
                disabled={retrying}
                className="px-4 py-2 rounded-full bg-white border-2 border-primary/40 hover:bg-primary/10 font-bold text-sm flex items-center gap-2 transition-colors disabled:opacity-60"
              >
                <RotateCcw className={`w-4 h-4 ${retrying ? 'animate-spin' : ''}`} />
                {retrying ? 'Asking…' : 'Try again'}
              </button>
            </div>
          </div>
        </div>
      )}

      <main className="flex-1 relative z-10 p-4 flex items-center justify-center">
        <div className="w-full max-w-6xl grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 auto-rows-fr h-full max-h-[80vh]">
          {/* Local Video */}
          <div className="relative rounded-3xl overflow-hidden bg-white/50 border-4 border-white shadow-lg flex flex-col">
            {/* Kept mounted whatever happens: unmounting it on mute would drop
                the attached stream and leave a black square on the way back. */}
            <video
              ref={localVideoRef}
              autoPlay
              muted
              playsInline
              className={`w-full h-full object-cover transform scale-x-[-1] ${localStream && videoEnabled ? '' : 'hidden'}`}
            />
            {(!localStream || !videoEnabled) && (
              <div className="flex-1 flex flex-col items-center justify-center">
                <div className={`w-24 h-24 rounded-full border-4 border-white shadow-sm flex items-center justify-center font-display font-bold text-4xl ${getAccentClasses(me?.accentColor).bg} ${getAccentClasses(me?.accentColor).text}`}>
                  {me?.avatarUrl ? <img src={me.avatarUrl} className="w-full h-full rounded-full object-cover" alt="" /> : me?.displayName[0]}
                </div>
              </div>
            )}
            <div className="absolute bottom-4 left-4 right-4 flex justify-between items-center bg-black/40 backdrop-blur rounded-2xl px-4 py-2">
              <span className="font-bold text-white text-sm truncate">You</span>
              {!audioEnabled && <MicOff className="w-4 h-4 text-destructive" />}
            </div>
          </div>

          {/* Remote Videos */}
          {callState?.participants?.filter((p: any) => p.user.id !== me?.id).map((p: any) => {
            const stream = streams[p.user.id];
            const colors = getAccentClasses(p.user.accentColor);
            
            return (
              <div key={p.user.id} className="relative min-h-0 rounded-3xl overflow-hidden bg-white/50 border-4 border-white shadow-lg flex flex-col">
                {stream ? (
                  <VideoPlayer
                    stream={stream}
                    fallback={
                      <div className="absolute inset-0 flex flex-col items-center justify-center">
                        <div className={`w-24 h-24 rounded-full border-4 border-white shadow-sm flex items-center justify-center font-display font-bold text-4xl ${colors.bg} ${colors.text} animate-pulse`}>
                          {p.user.avatarUrl ? <img src={p.user.avatarUrl} className="w-full h-full rounded-full object-cover" alt="" /> : p.user.displayName[0]}
                        </div>
                      </div>
                    }
                  />
                ) : (
                  <div className="flex-1 flex flex-col items-center justify-center">
                    <div className={`w-24 h-24 rounded-full border-4 border-white shadow-sm flex items-center justify-center font-display font-bold text-4xl ${colors.bg} ${colors.text} animate-pulse`}>
                      {p.user.avatarUrl ? <img src={p.user.avatarUrl} className="w-full h-full rounded-full object-cover" alt="" /> : p.user.displayName[0]}
                    </div>
                  </div>
                )}
                <div className="absolute bottom-4 left-4 right-4 flex justify-between items-center bg-black/40 backdrop-blur rounded-2xl px-4 py-2">
                  <span className="font-bold text-white text-sm truncate">{p.user.displayName}</span>
                </div>
              </div>
            );
          })}
        </div>
      </main>

      <footer className="relative z-10 p-6 flex justify-center gap-4 pb-safe">
        <button 
          onClick={toggleAudio}
          disabled={!localStream}
          aria-label={audioEnabled ? 'Mute microphone' : 'Unmute microphone'}
          title={localStream ? undefined : 'No microphone available'}
          className={`w-14 h-14 rounded-2xl flex items-center justify-center shadow-lg transition-transform hover:scale-105 active:scale-95 border-2 border-white disabled:opacity-50 disabled:hover:scale-100 ${audioEnabled && localStream ? 'bg-white text-foreground' : 'bg-destructive text-white'}`}
        >
          {audioEnabled && localStream ? <Mic className="w-6 h-6" /> : <MicOff className="w-6 h-6" />}
        </button>
        <button 
          onClick={toggleVideo}
          disabled={!localStream}
          aria-label={videoEnabled ? 'Turn camera off' : 'Turn camera on'}
          title={localStream ? undefined : 'No camera available'}
          className={`w-14 h-14 rounded-2xl flex items-center justify-center shadow-lg transition-transform hover:scale-105 active:scale-95 border-2 border-white disabled:opacity-50 disabled:hover:scale-100 ${videoEnabled && localStream ? 'bg-white text-foreground' : 'bg-destructive text-white'}`}
        >
          {videoEnabled && localStream ? <VideoIcon className="w-6 h-6" /> : <VideoOff className="w-6 h-6" />}
        </button>
        <button 
          onClick={handleLeave}
          className="w-16 h-14 rounded-2xl bg-destructive text-white border-2 border-white shadow-lg flex items-center justify-center transition-transform hover:scale-105 active:scale-95 px-6"
        >
          <PhoneOff className="w-6 h-6" />
        </button>
      </footer>
    </div>
  );
}

function VideoPlayer({ stream, fallback }: { stream: MediaStream; fallback: ReactNode }) {
  const ref = useRef<HTMLVideoElement>(null);
  const [mutedFallback, setMutedFallback] = useState(false);
  const [needsSound, setNeedsSound] = useState(false);
  const [hasFrames, setHasFrames] = useState(false);
  
  useEffect(() => {
    const video = ref.current;
    if (!video) return;

    let disposed = false;
    setHasFrames(false);
    video.srcObject = stream;

    const revealVideo = () => {
      if (!disposed && video.videoWidth > 0 && video.videoHeight > 0) {
        setHasFrames(true);
      }
    };

    const startPlayback = () => {
      void video.play().catch(() => {
        // Browsers can block an unmuted remote stream after navigation. Mute
        // only as a fallback so the video still renders, then let the viewer
        // enable sound with a real click.
        if (disposed) return;
        video.muted = true;
        setMutedFallback(true);
        setNeedsSound(true);
        void video.play().catch(() => undefined);
      });
    };

    video.addEventListener('loadedmetadata', startPlayback);
    video.addEventListener('canplay', startPlayback);
    video.addEventListener('loadeddata', revealVideo);
    video.addEventListener('playing', revealVideo);
    startPlayback();

    return () => {
      disposed = true;
      video.removeEventListener('loadedmetadata', startPlayback);
      video.removeEventListener('canplay', startPlayback);
      video.removeEventListener('loadeddata', revealVideo);
      video.removeEventListener('playing', revealVideo);
    };
  }, [stream]);

  return (
    <div className="absolute inset-0">
      <video
        ref={ref}
        autoPlay
        playsInline
        muted={mutedFallback}
        className={`absolute inset-0 w-full h-full object-cover ${hasFrames ? '' : 'opacity-0'}`}
      />
      {!hasFrames && fallback}
      {needsSound && (
        <button
          type="button"
          onClick={() => {
            const video = ref.current;
            if (!video) return;
            video.muted = false;
            void video.play()
              .then(() => {
                setMutedFallback(false);
                setNeedsSound(false);
              })
              .catch(() => {
                video.muted = true;
              });
          }}
          className="absolute top-3 right-3 rounded-full bg-black/60 px-3 py-2 text-xs font-bold text-white backdrop-blur"
        >
          Enable sound
        </button>
      )}
    </div>
  );
}
