import { Link } from 'wouter';
import { useAuth } from '@clerk/react';
import { motion } from 'framer-motion';
import { Heart, Sparkles, Video, Users } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function Landing() {
  const { isSignedIn } = useAuth();

  return (
    <div className="min-h-screen bg-background relative overflow-hidden flex flex-col">
      {/* Decorative background blobs */}
      <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-cutesie-blush rounded-full blur-3xl opacity-40 mix-blend-multiply" />
      <div className="absolute top-[20%] right-[-10%] w-[30%] h-[50%] bg-cutesie-lilac rounded-full blur-3xl opacity-40 mix-blend-multiply" />
      <div className="absolute bottom-[-10%] left-[20%] w-[50%] h-[40%] bg-cutesie-mint rounded-full blur-3xl opacity-40 mix-blend-multiply" />

      <header className="relative z-10 p-6 flex justify-between items-center max-w-6xl mx-auto w-full">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-primary flex items-center justify-center text-primary-foreground shadow-sm font-display font-bold text-2xl transform -rotate-6">
            PF
          </div>
          <h1 className="font-display font-bold text-2xl text-foreground">Pillow Fort</h1>
        </div>
        <div>
          {isSignedIn ? (
            <Link href="/home">
              <Button size="lg" className="rounded-xl font-bold bg-white text-foreground hover:bg-white/90 border-2 border-border shadow-sm">
                Go to my fort
              </Button>
            </Link>
          ) : (
            <div className="flex gap-3">
              <Link href="/sign-in">
                <Button variant="ghost" className="font-bold text-foreground hover:bg-black/5 rounded-xl">
                  Sign In
                </Button>
              </Link>
              <Link href="/sign-up">
                <Button className="rounded-xl font-bold border-2 border-primary-foreground/10 shadow-sm">
                  Sign Up
                </Button>
              </Link>
            </div>
          )}
        </div>
      </header>

      <main className="flex-1 relative z-10 flex flex-col items-center justify-center p-6 text-center max-w-4xl mx-auto w-full">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/60 backdrop-blur border-2 border-white shadow-sm mb-8">
            <Sparkles className="w-4 h-4 text-primary" />
            <span className="text-sm font-bold text-foreground">A cozy place for your circle</span>
          </div>
          <h2 className="font-display font-extrabold text-6xl md:text-8xl text-foreground mb-6 leading-tight">
            Chat, chill, <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-secondary">
              build a fort.
            </span>
          </h2>
          <p className="text-xl text-muted-foreground mb-10 max-w-2xl mx-auto font-medium">
            Pillow Fort is a soft, warm space for you and your friends. 
            No algorithms, no feeds—just paper-cut cards, pastel gradients, and your favorite people.
          </p>

          {!isSignedIn && (
            <div className="flex flex-wrap justify-center gap-4">
              <Link href="/sign-up">
                <Button size="lg" className="rounded-2xl h-14 px-8 text-lg font-bold border-2 border-primary-foreground/10 shadow-md transform hover:scale-105 transition-transform">
                  Build your fort
                </Button>
              </Link>
            </div>
          )}
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-24 w-full">
          <FeatureCard 
            icon={Heart} 
            title="Soft Vibes" 
            desc="Pastel colors, squishy buttons, and a warm cream background that feels like home."
            color="bg-cutesie-blush"
          />
          <FeatureCard 
            icon={Users} 
            title="Close Friends" 
            desc="Keep your circle tight. Send friend requests and hang out in private or group forts."
            color="bg-cutesie-lilac"
          />
          <FeatureCard 
            icon={Video} 
            title="Video Calls" 
            desc="Jump into a peer-to-peer video call right from your chat. No links required."
            color="bg-cutesie-mint"
          />
        </div>
      </main>
    </div>
  );
}

function FeatureCard({ icon: Icon, title, desc, color }: any) {
  return (
    <motion.div 
      whileHover={{ y: -5 }}
      className="bg-white/80 backdrop-blur border-4 border-white p-6 rounded-3xl shadow-lg text-left flex flex-col"
    >
      <div className={`w-14 h-14 rounded-2xl ${color} flex items-center justify-center text-foreground mb-4 shadow-sm transform -rotate-3`}>
        <Icon className="w-7 h-7" />
      </div>
      <h3 className="font-display font-bold text-2xl text-foreground mb-2">{title}</h3>
      <p className="text-muted-foreground font-medium">{desc}</p>
    </motion.div>
  );
}
