import { useEffect, useRef, useState, useMemo } from 'react';
import { useGetRoom, useListMessages, useSendMessage, useReactToMessage, useDeleteMessage, useMarkRoomRead, useGetMe, getListMessagesQueryKey } from '@workspace/api-client-react';
import { useRealtime } from '@/lib/realtime';
import { useDirectUpload } from '@/lib/upload';
import { getAccentClasses } from '@/lib/theme';
import { Video, Paperclip, Send, Loader2, Play, FileText, SmilePlus, X, Settings2, Trash2 } from 'lucide-react';
import { FortSettingsDialog } from '@/components/fort-settings-dialog';
import { format } from 'date-fns';
import { Link } from 'wouter';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { useQueryClient } from '@tanstack/react-query';

const ALLOWED_REACTIONS = ["❤️", "🌸", "✨", "😹", "🥺", "🎀"];

export default function Chat({ params }: { params: { roomId: string } }) {
  const { roomId } = params;
  const { data: me } = useGetMe();
  const { data: room, isError: roomFailed } = useGetRoom(roomId);
  const { data: messagesData } = useListMessages({ roomId, limit: 50 }); 
  
  const messages = useMemo(() => {
    // If it's not infinite, it's just an array or object. Let's assume it's just an array of messages returned.
    // The swagger says `useListMessages` returns `Message[]`.
    return messagesData || [];
  }, [messagesData]);

  const sendMessage = useSendMessage();
  const deleteMessage = useDeleteMessage();
  const markRead = useMarkRoomRead();
  const { send, typingIndicators } = useRealtime();
  const { uploadFile, isUploading } = useDirectUpload();
  const queryClient = useQueryClient();

  const [body, setBody] = useState('');
  const [attachments, setAttachments] = useState<any[]>([]);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  
  const roomColors = getAccentClasses(room?.colorKey);
  const typing = typingIndicators[roomId] || [];

  const markReadMutateRef = useRef(markRead.mutate);
  markReadMutateRef.current = markRead.mutate;

  const lastReadMessageId = useRef<string | null>(null);
  
  useEffect(() => {
    if (messages.length > 0) {
      // The list arrives oldest-first, so the newest message is the last one.
      const latestMsgId = messages[messages.length - 1]?.id;
      if (latestMsgId && lastReadMessageId.current !== latestMsgId) {
        lastReadMessageId.current = latestMsgId;
        markReadMutateRef.current({ roomId });
      }
    }
  }, [roomId, messages]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  let typingTimeout: any;
  const handleTyping = (e: React.ChangeEvent<HTMLInputElement>) => {
    setBody(e.target.value);
    send({ type: 'typing', roomId, isTyping: true });
    clearTimeout(typingTimeout);
    typingTimeout = setTimeout(() => {
      send({ type: 'typing', roomId, isTyping: false });
    }, 2000);
  };

  const handleSend = async (e?: React.FormEvent) => {
    e?.preventDefault();
    if (!body.trim() && attachments.length === 0) return;
    
    // optimistic update could go here, but let's just let it send and rely on WS
    const currentBody = body;
    const currentAttachments = attachments;
    setBody('');
    setAttachments([]);
    send({ type: 'typing', roomId, isTyping: false });

    await sendMessage.mutateAsync({
      roomId,
      data: {
        body: currentBody.trim() || undefined,
        attachments: currentAttachments,
      }
    });
  };

  const handleDeleteMessage = async (messageId: string) => {
    if (
      deleteMessage.isPending ||
      !window.confirm('Delete this message? This cannot be undone.')
    ) {
      return;
    }

    try {
      await deleteMessage.mutateAsync({ messageId });
      // Remove it immediately for the person who deleted it. The server's
      // message:deleted broadcast (also sent back to this browser) refreshes
      // room and home previews for everybody without racing a second fetch.
      queryClient.setQueryData(
        getListMessagesQueryKey({ roomId }),
        (current: any) =>
          Array.isArray(current)
            ? current.filter((message) => message.id !== messageId)
            : current,
      );
    } catch {
      window.alert("Couldn't delete that message. Please try again.");
    }
  };

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const { objectPath } = await uploadFile(file);
      setAttachments(prev => [...prev, {
        objectPath,
        fileName: file.name,
        contentType: file.type,
        size: file.size
      }]);
    } catch (err) {
      console.error(err);
    }
  };

  // Losing access (left the fort, removed from it) fails this query, and a
  // spinner would hang forever — say what happened and point the way out.
  if (roomFailed && !room) {
    return (
      <div className="h-full flex flex-col items-center justify-center gap-3 p-6 text-center">
        <p className="font-display font-bold text-lg">This fort is closed to you</p>
        <p className="text-sm text-muted-foreground max-w-xs">
          You're not a member of this chat anymore. Ask a friend inside for a new invite.
        </p>
        <Link href="/home" className="mt-1 px-5 py-2 rounded-full bg-primary/20 font-bold text-sm hover:bg-primary/30 transition-colors">
          Back home
        </Link>
      </div>
    );
  }

  if (!room) return <div className="h-full flex items-center justify-center"><Loader2 className="w-8 h-8 animate-spin text-muted-foreground" /></div>;

  return (
    <div className="h-full flex flex-col bg-white/40">
      {/* Header */}
      <header className={`p-4 bg-white/80 backdrop-blur border-b-2 border-white flex justify-between items-center shadow-sm z-10`}>
        <div className="flex items-center gap-3">
          <div className={`w-12 h-12 rounded-[1.2rem] border-2 border-white shadow-sm flex items-center justify-center ${roomColors.bg} ${roomColors.text} font-display font-bold text-xl transform -rotate-3`}>
            {(room.kind === 'group' ? room.pictureUrl : room.otherUser?.avatarUrl)
              ? <img src={(room.kind === 'group' ? room.pictureUrl : room.otherUser?.avatarUrl)!} alt="" className="w-full h-full rounded-[1.1rem] object-cover" />
              : room.name[0].toUpperCase()}
          </div>
          <div>
            <h2 className="font-display font-bold text-xl text-foreground">{room.name}</h2>
            {typing.length > 0 ? (
              <p className="text-xs font-bold text-primary animate-pulse">{typing.map(t => t.displayName).join(', ')} is typing...</p>
            ) : (
              <p className="text-xs text-muted-foreground">{room.kind === 'group' ? `${room.members.length} ${room.members.length === 1 ? 'member' : 'members'}` : 'Direct Message'}</p>
            )}
          </div>
        </div>
        
        <div className="flex items-center gap-2">
          {room.kind === 'group' && (
            <button
              onClick={() => setSettingsOpen(true)}
              aria-label="Fort settings"
              title="Fort settings"
              className="w-10 h-10 rounded-xl bg-white border-2 border-border text-muted-foreground flex items-center justify-center hover:text-foreground hover:bg-black/5 transition-colors"
            >
              <Settings2 className="w-5 h-5" />
            </button>
          )}

          <Link href={`/call/${roomId}`}>
            <button className={`px-4 py-2 rounded-xl font-bold flex items-center gap-2 border-2 border-transparent transition-transform hover:scale-105 active:scale-95 ${room.callActive ? 'bg-destructive text-white shadow-sm' : 'bg-cutesie-mint text-cutesie-mint-foreground shadow-sm'}`}>
              <Video className="w-5 h-5" />
              {room.callActive ? 'Join Call' : 'Start Call'}
            </button>
          </Link>
        </div>
      </header>

      {room.kind === 'group' && (
        <FortSettingsDialog room={room} open={settingsOpen} onOpenChange={setSettingsOpen} />
      )}

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-6" ref={scrollRef}>
        {messages.map((msg: any) => {
          const isMe = msg.author.id === me?.id;
          return (
            <div key={msg.id} className={`flex gap-3 ${isMe ? 'flex-row-reverse' : ''}`}>
              {!isMe && (
                <div className={`w-10 h-10 rounded-[1rem] border-2 border-white shadow-sm flex-shrink-0 flex items-center justify-center ${getAccentClasses(msg.author.accentColor).bg} ${getAccentClasses(msg.author.accentColor).text} font-bold text-sm transform ${isMe ? 'rotate-6' : '-rotate-6'}`}>
                  {msg.author.avatarUrl ? <img src={msg.author.avatarUrl} className="w-full h-full rounded-[0.85rem] object-cover" alt="" /> : msg.author.displayName[0]}
                </div>
              )}
              
              <div className={`max-w-[75%] flex flex-col ${isMe ? 'items-end' : 'items-start'}`}>
                <div className={`flex items-baseline gap-2 mb-1 ${isMe ? 'flex-row-reverse' : ''}`}>
                  <span className="text-xs font-bold text-foreground">{msg.author.displayName}</span>
                  <span className="text-[10px] text-muted-foreground">{format(new Date(msg.createdAt), 'h:mm a')}</span>
                   {isMe && (
                     <button
                       type="button"
                       onClick={() => handleDeleteMessage(msg.id)}
                       disabled={deleteMessage.isPending}
                       aria-label="Delete message"
                       title="Delete message"
                       className="p-1 -my-1 rounded-md text-muted-foreground hover:bg-destructive/10 hover:text-destructive transition-colors disabled:opacity-50"
                     >
                       <Trash2 className="w-3.5 h-3.5" />
                     </button>
                   )}
                </div>
                
                <div className="group relative flex flex-col gap-1">
                  {msg.attachments?.map((att: any) => (
                    <AttachmentPreview key={att.id} attachment={att} />
                  ))}
                  
                  {msg.body && (
                    <div className={`px-4 py-3 rounded-3xl shadow-sm border-2 border-white relative text-[15px] ${isMe ? `bg-white ${getAccentClasses(me?.accentColor).text} rounded-br-sm` : `${roomColors.bg} text-foreground rounded-bl-sm`}`}>
                      {msg.body}
                    </div>
                  )}

                  {/* Reactions */}
                  {msg.reactions && msg.reactions.length > 0 && (
                    <div className={`flex flex-wrap gap-1 mt-1 ${isMe ? 'justify-end' : 'justify-start'}`}>
                      {msg.reactions.map((r: any) => (
                        <ReactionChip key={r.emoji} reaction={r} roomId={roomId} messageId={msg.id} />
                      ))}
                    </div>
                  )}

                  {/* Reaction Picker Button */}
                  <div className={`absolute top-1/2 -translate-y-1/2 opacity-0 group-hover:opacity-100 transition-opacity ${isMe ? '-left-10' : '-right-10'}`}>
                    <ReactionPicker roomId={roomId} messageId={msg.id} />
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Composer */}
      <div className="p-4 bg-white/80 backdrop-blur border-t-2 border-white">
        {attachments.length > 0 && (
          <div className="flex gap-2 mb-3 overflow-x-auto pb-2">
            {attachments.map((att, i) => (
              <div key={i} className="px-3 py-1.5 bg-background border-2 border-border rounded-xl text-xs font-bold flex items-center gap-2">
                <FileText className="w-3 h-3" />
                <span className="max-w-[100px] truncate">{att.fileName}</span>
                <button onClick={() => setAttachments(a => a.filter((_, idx) => idx !== i))} className="hover:text-destructive"><X className="w-3 h-3"/></button>
              </div>
            ))}
          </div>
        )}
        <form onSubmit={handleSend} className="flex gap-2 items-end">
          <div className="relative flex-1 bg-white border-2 border-border rounded-3xl shadow-sm focus-within:ring-4 focus-within:ring-primary/20 transition-shadow">
            <input
              type="text"
              value={body}
              onChange={handleTyping}
              placeholder="Say something soft..."
              className="w-full bg-transparent px-4 py-3 pr-12 outline-none font-medium"
            />
            <div className="absolute right-2 bottom-2">
              <input type="file" id="file-upload" className="hidden" onChange={handleFileSelect} />
              <label htmlFor="file-upload" className="p-2 block rounded-xl text-muted-foreground hover:bg-black/5 hover:text-foreground cursor-pointer">
                {isUploading ? <Loader2 className="w-5 h-5 animate-spin" /> : <Paperclip className="w-5 h-5" />}
              </label>
            </div>
          </div>
          <button 
            type="submit" 
            disabled={(!body.trim() && attachments.length === 0) || isUploading}
            className={`w-12 h-12 rounded-full border-2 border-white shadow-sm flex items-center justify-center transform transition-transform hover:scale-105 active:scale-95 disabled:opacity-50 disabled:hover:scale-100 ${body.trim() || attachments.length > 0 ? 'bg-primary text-primary-foreground' : 'bg-muted text-muted-foreground'}`}
          >
            <Send className="w-5 h-5 ml-1" />
          </button>
        </form>
      </div>
    </div>
  );
}

function AttachmentPreview({ attachment }: { attachment: any }) {
  const isImage = attachment.contentType.startsWith('image/');
  const isVideo = attachment.contentType.startsWith('video/');

  if (isImage) {
    return <img src={attachment.url} alt="" className="max-w-[240px] rounded-2xl border-2 border-white shadow-sm" />;
  }
  
  if (isVideo) {
    return (
      <div className="relative max-w-[240px] rounded-2xl overflow-hidden border-2 border-white shadow-sm">
        <video src={attachment.url} controls className="w-full" />
      </div>
    );
  }

  return (
    <a href={attachment.url} download className="flex items-center gap-3 p-3 bg-white border-2 border-border rounded-2xl hover:bg-black/5 transition-colors shadow-sm">
      <div className="p-2 bg-cutesie-peach/30 text-cutesie-peach rounded-xl">
        <FileText className="w-6 h-6" />
      </div>
      <div>
        <div className="text-sm font-bold text-foreground">{attachment.fileName}</div>
        <div className="text-xs text-muted-foreground">{(attachment.size / 1024).toFixed(1)} KB</div>
      </div>
    </a>
  );
}

function ReactionChip({ reaction, roomId, messageId }: any) {
  const react = useReactToMessage();
  return (
    <button 
      onClick={() => react.mutate({ messageId, data: { emoji: reaction.emoji } })}
      className={`flex items-center gap-1 px-2 py-0.5 rounded-full border-2 text-xs font-bold shadow-sm transition-colors ${reaction.reactedByMe ? 'bg-primary/20 border-primary text-foreground' : 'bg-white border-white text-muted-foreground hover:bg-white/80'}`}
    >
      <span>{reaction.emoji}</span>
      <span>{reaction.count}</span>
    </button>
  );
}

function ReactionPicker({ roomId, messageId }: { roomId: string, messageId: string }) {
  const react = useReactToMessage();
  
  return (
    <Popover>
      <PopoverTrigger asChild>
        <button className="p-1.5 rounded-full bg-white border-2 border-border shadow-sm text-muted-foreground hover:text-foreground">
          <SmilePlus className="w-4 h-4" />
        </button>
      </PopoverTrigger>
      <PopoverContent side="top" className="w-auto p-2 rounded-2xl bg-white border-2 border-border shadow-xl flex gap-1">
        {ALLOWED_REACTIONS.map(emoji => (
          <button 
            key={emoji}
            onClick={() => react.mutate({ messageId, data: { emoji } })}
            className="w-8 h-8 rounded-xl flex items-center justify-center hover:bg-black/5 text-lg transition-transform hover:scale-110 active:scale-95"
          >
            {emoji}
          </button>
        ))}
      </PopoverContent>
    </Popover>
  );
}
