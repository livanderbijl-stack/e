import { useGetHomeSummary, useListActivity, useListRooms } from '@workspace/api-client-react';
import { Link } from 'wouter';
import { motion } from 'framer-motion';
import { Video, Sparkles, MessageSquare, Plus } from 'lucide-react';
import { getAccentClasses } from '@/lib/theme';
import { formatDistanceToNow } from 'date-fns';

export default function Home() {
  const { data: summary, isLoading: loadingSummary } = useGetHomeSummary();
  const { data: activity, isLoading: loadingActivity } = useListActivity();
  const { data: rooms } = useListRooms();

  return (
    <div className="h-full flex flex-col p-6 max-w-5xl mx-auto overflow-y-auto">
      <header className="mb-8">
        <h2 className="font-display font-bold text-4xl text-foreground">Welcome to the Fort</h2>
        <p className="text-muted-foreground mt-2">See who's around and what's happening.</p>
      </header>

      {/* Online Friends Rail */}
      <section className="mb-10">
        <h3 className="text-sm font-bold text-muted-foreground uppercase tracking-wider mb-4 px-2">Online Now</h3>
        {loadingSummary ? (
          <div className="flex gap-4 px-2">
            {[1,2,3].map(i => <div key={i} className="w-16 h-16 rounded-full bg-border animate-pulse" />)}
          </div>
        ) : summary?.onlineFriends?.length ? (
          <div className="flex gap-4 overflow-x-auto pb-4 px-2 -mx-2 snap-x">
            {summary.onlineFriends.map(friend => {
              const colors = getAccentClasses(friend.accentColor);
              return (
                <div key={friend.id} className="snap-start flex flex-col items-center gap-2 flex-shrink-0">
                  <div className={`relative w-16 h-16 rounded-full border-4 border-white shadow-sm ${colors.bg}`}>
                    {friend.avatarUrl ? (
                      <img src={friend.avatarUrl} alt={friend.displayName} className="w-full h-full rounded-full object-cover" />
                    ) : (
                      <div className={`w-full h-full flex items-center justify-center font-display font-bold text-2xl ${colors.text}`}>
                        {friend.displayName[0].toUpperCase()}
                      </div>
                    )}
                    <div className="absolute bottom-0 right-0 w-4 h-4 rounded-full bg-green-400 border-2 border-white" />
                  </div>
                  <span className="text-xs font-bold text-foreground truncate w-16 text-center">{friend.displayName.split(' ')[0]}</span>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="px-6 py-8 bg-white/50 border-4 border-white rounded-3xl shadow-sm flex flex-col items-center justify-center text-center">
            <Sparkles className="w-8 h-8 text-muted-foreground mb-3" />
            <p className="text-muted-foreground font-medium">It's quiet here. Go invite some friends!</p>
            <Link href="/friends">
              <button className="mt-4 px-4 py-2 bg-white border-2 border-border rounded-xl font-bold hover:bg-black/5">
                Find friends
              </button>
            </Link>
          </div>
        )}
      </section>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Live Calls */}
        <section>
          <h3 className="text-sm font-bold text-muted-foreground uppercase tracking-wider mb-4 px-2">Live Calls</h3>
          <div className="space-y-4">
            {summary?.liveCalls?.length ? (
              summary.liveCalls.map(call => (
                <Link key={call.roomId} href={`/call/${call.roomId}`}>
                  <motion.div 
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    className="p-4 bg-cutesie-mint/30 border-4 border-white rounded-3xl shadow-sm cursor-pointer relative overflow-hidden"
                  >
                    <div className="absolute -right-4 -bottom-4 text-cutesie-mint opacity-50 transform rotate-12">
                      <Video className="w-24 h-24" />
                    </div>
                    <div className="relative z-10">
                      <div className="flex items-center gap-2 mb-2">
                        <div className="w-2 h-2 rounded-full bg-destructive animate-pulse" />
                        <span className="text-xs font-bold text-destructive uppercase tracking-wider">Live</span>
                      </div>
                      <div className="flex items-center gap-3">
                        {(() => {
                          const room = rooms?.find(room => room.id === call.roomId);
                          if (!room) return null;
                          const image = room.kind === 'group' ? room.pictureUrl : room.otherUser?.avatarUrl;
                          const colors = getAccentClasses(room.colorKey);
                          return <div className={`w-10 h-10 rounded-xl border-2 border-white overflow-hidden flex items-center justify-center font-bold flex-shrink-0 ${colors.bg} ${colors.text}`}>
                            {image ? <img src={image} alt="" className="w-full h-full object-cover" /> : room.name[0]?.toUpperCase()}
                          </div>;
                        })()}
                        <h4 className="font-display font-bold text-xl text-foreground">{call.roomName}</h4>
                      </div>
                      <p className="text-sm text-foreground/80 mt-1">{call.participants.length} in call</p>
                    </div>
                  </motion.div>
                </Link>
              ))
            ) : (
              <div className="p-6 bg-white/50 border-4 border-white rounded-3xl shadow-sm text-center">
                <Video className="w-8 h-8 text-muted-foreground mx-auto mb-3 opacity-50" />
                <p className="text-sm text-muted-foreground">No one is on a call right now.</p>
              </div>
            )}
          </div>
        </section>

        {/* Activity Feed */}
        <section>
          <h3 className="text-sm font-bold text-muted-foreground uppercase tracking-wider mb-4 px-2">Recent Activity</h3>
          <div className="bg-white border-4 border-white rounded-3xl shadow-sm p-4 h-[400px] overflow-y-auto space-y-4">
            {loadingActivity ? (
              <div className="space-y-4">
                {[1,2,3].map(i => (
                  <div key={i} className="flex gap-3 items-start">
                    <div className="w-10 h-10 rounded-full bg-border animate-pulse flex-shrink-0" />
                    <div className="flex-1 space-y-2 py-1">
                      <div className="h-4 bg-border rounded w-3/4 animate-pulse" />
                      <div className="h-3 bg-border rounded w-1/4 animate-pulse" />
                    </div>
                  </div>
                ))}
              </div>
            ) : activity?.length ? (
              activity.map(item => {
                const colors = getAccentClasses(item.actor.accentColor);
                return (
                  <Link key={item.id} href={`/chat/${item.roomId}`}>
                    <div className="flex gap-3 items-start p-2 rounded-2xl hover:bg-black/5 transition-colors cursor-pointer group">
                      <div className={`w-10 h-10 rounded-full border-2 border-white shadow-sm flex-shrink-0 flex items-center justify-center ${colors.bg} ${colors.text} font-display font-bold`}>
                        {item.actor.avatarUrl ? (
                          <img src={item.actor.avatarUrl} alt="" className="w-full h-full rounded-full object-cover" />
                        ) : (
                          item.actor.displayName[0].toUpperCase()
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm text-foreground">
                          <span className="font-bold">{item.actor.displayName}</span>
                          {' '}<span className="text-muted-foreground">{item.summary}</span>
                        </p>
                        <p className="text-xs text-muted-foreground mt-0.5">
                          {formatDistanceToNow(new Date(item.createdAt), { addSuffix: true })} in {item.roomName}
                        </p>
                      </div>
                    </div>
                  </Link>
                );
              })
            ) : (
              <div className="h-full flex flex-col items-center justify-center text-center p-4">
                <MessageSquare className="w-8 h-8 text-muted-foreground mb-3 opacity-50" />
                <p className="text-sm text-muted-foreground">It's a bit too quiet... say hi somewhere!</p>
              </div>
            )}
          </div>
        </section>
      </div>
    </div>
  );
}
