import { type ReactNode } from 'react';
import { QueryClientProvider } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import {
  Route,
  Switch,
  useLocation,
  Router as WouterRouter,
  Redirect,
} from 'wouter';
import { ClerkProvider, SignIn, SignUp, Show, useClerk } from '@clerk/react';
import { publishableKeyFromHost } from '@clerk/react/internal';
import { queryClient } from '@/lib/queryClient';
import { RealtimeProvider } from '@/lib/realtime';

import Home from '@/pages/home';
import Landing from '@/pages/landing';
import Chat from '@/pages/chat';
import Friends from '@/pages/friends';
import Profile from '@/pages/profile';
import Call from '@/pages/call';
import { AppShell } from '@/components/app-shell';

const clerkPubKey = publishableKeyFromHost(
  window.location.hostname,
  import.meta.env.VITE_CLERK_PUBLISHABLE_KEY,
);

const clerkProxyUrl = import.meta.env.VITE_CLERK_PROXY_URL;
const basePath = import.meta.env.BASE_URL.replace(/\/$/, "");

function stripBase(path: string): string {
  return basePath && path.startsWith(basePath)
    ? path.slice(basePath.length) || "/"
    : path;
}

if (!clerkPubKey) {
  throw new Error('Missing VITE_CLERK_PUBLISHABLE_KEY in .env file');
}

const clerkAppearance = {
  cssLayerName: "clerk",
  variables: {
    colorPrimary: "hsl(346 100% 91%)",
    colorForeground: "hsl(293 13% 26%)",
    colorMutedForeground: "hsl(293 10% 50%)",
    colorDanger: "hsl(0 84% 60%)",
    colorBackground: "hsl(40 33% 98%)",
    colorInput: "hsl(293 13% 90%)",
    colorInputForeground: "hsl(293 13% 26%)",
    colorNeutral: "hsl(293 13% 90%)",
    fontFamily: "'Nunito', sans-serif",
    borderRadius: "16px",
  },
  elements: {
    rootBox: "w-full flex justify-center",
    cardBox: "bg-[hsl(40_33%_98%)] rounded-2xl w-[440px] max-w-full overflow-hidden shadow-xl border-4 border-white",
    card: "!shadow-none !border-0 !bg-transparent !rounded-none",
    footer: "!shadow-none !border-0 !bg-transparent !rounded-none",
    headerTitle: "text-2xl font-display font-bold text-foreground",
    headerSubtitle: "text-muted-foreground",
    socialButtonsBlockButtonText: "text-foreground font-semibold",
    formFieldLabel: "text-foreground font-semibold",
    footerActionLink: "text-primary-foreground font-bold hover:underline",
    footerActionText: "text-muted-foreground",
    dividerText: "text-muted-foreground",
    identityPreviewEditButton: "text-primary-foreground",
    formFieldSuccessText: "text-green-600",
    alertText: "text-destructive font-semibold",
    logoBox: "mb-4",
    logoImage: "h-12 w-auto",
    socialButtonsBlockButton: "border-2 border-border hover:bg-black/5 transition-colors rounded-xl",
    formButtonPrimary: "bg-primary text-primary-foreground font-bold hover:brightness-95 rounded-xl border-2 border-primary-foreground/10",
    formFieldInput: "border-2 border-border rounded-xl bg-white px-3 py-2 text-foreground focus:ring-4 focus:ring-primary/20",
    footerAction: "mt-4",
    dividerLine: "bg-border",
    alert: "bg-destructive/10 border-destructive border-2 rounded-xl text-destructive",
    otpCodeFieldInput: "border-2 border-border rounded-xl",
    formFieldRow: "mb-4",
    main: "p-8",
  },
};

function SignInPage() {
  return (
    <div className="flex min-h-[100dvh] items-center justify-center bg-background px-4">
      <SignIn routing="path" path={`${basePath}/sign-in`} signUpUrl={`${basePath}/sign-up`} />
    </div>
  );
}

function SignUpPage() {
  return (
    <div className="flex min-h-[100dvh] items-center justify-center bg-background px-4">
      <SignUp routing="path" path={`${basePath}/sign-up`} signInUrl={`${basePath}/sign-in`} />
    </div>
  );
}

function HomeRedirect() {
  return (
    <>
      <Show when="signed-in">
        <Redirect to="/home" />
      </Show>
      <Show when="signed-out">
        <Landing />
      </Show>
    </>
  );
}

function ProtectedRoute({ component: Component, ...rest }: any) {
  return (
    <Route {...rest}>
      {(params) => (
        <>
          <Show when="signed-in">
            <AppShell>
              <Component params={params} />
            </AppShell>
          </Show>
          <Show when="signed-out">
            <Redirect to="/sign-in" />
          </Show>
        </>
      )}
    </Route>
  );
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function App() {
  const [, setLocation] = useLocation();

  return (
    <ClerkProvider
      publishableKey={clerkPubKey}
      proxyUrl={clerkProxyUrl}
      appearance={clerkAppearance}
      signInUrl={`${basePath}/sign-in`}
      signUpUrl={`${basePath}/sign-up`}
      routerPush={(to) => setLocation(stripBase(to))}
      routerReplace={(to) => setLocation(stripBase(to), { replace: true })}
    >
      <QueryClientProvider client={queryClient}>
        <TooltipProvider>
          <Toaster />
          <RealtimeProvider>
            <RoutedErrorBoundary>
              <Switch>
                <Route path="/" component={HomeRedirect} />
                <Route path="/sign-in/*?" component={SignInPage} />
                <Route path="/sign-up/*?" component={SignUpPage} />
                
                <ProtectedRoute path="/home" component={Home} />
                <ProtectedRoute path="/chat/:roomId" component={Chat} />
                <ProtectedRoute path="/friends" component={Friends} />
                <ProtectedRoute path="/profile" component={Profile} />
                
                <Route path="/call/:roomId">
                  {(params) => (
                    <>
                      <Show when="signed-in">
                        <Call params={params} />
                      </Show>
                      <Show when="signed-out">
                        <Redirect to="/sign-in" />
                      </Show>
                    </>
                  )}
                </Route>

                <Route component={NotFound} />
              </Switch>
            </RoutedErrorBoundary>
          </RealtimeProvider>
        </TooltipProvider>
      </QueryClientProvider>
    </ClerkProvider>
  );
}

export default function Root() {
  return (
    <WouterRouter base={basePath}>
      <App />
    </WouterRouter>
  );
}
