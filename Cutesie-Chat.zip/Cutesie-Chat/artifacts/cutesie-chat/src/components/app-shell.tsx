import { Link, useLocation } from 'wouter';
import { useGetMe, useListRooms, useGetHomeSummary } from '@workspace/api-client-react';
import { MessageSquare, Users, User, Home as HomeIcon, LogOut, Menu, X, Plus } from 'lucide-react';
import { useClerk } from '@clerk/react';
import { useState } from 'react';
import { getAccentClasses } from '@/lib/theme';
import { motion, AnimatePresence } from 'framer-motion';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { CreateFortDialog, NewFortButton } from '@/components/create-fort-dialog';

export function AppShell({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();
  const { signOut } = useClerk();
  const { data: me } = useGetMe();
  const { data: rooms } = useListRooms();
  const { data: homeSummary } = useGetHomeSummary();

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [createFortOpen, setCreateFortOpen] = useState(false);

  const meColors = getAccentClasses(me?.accentColor);

  return (
    <div className="flex h-[100dvh] w-full bg-background overflow-hidden relative">
      {/* Desktop Sidebar */}
      <aside className="hidden md:flex flex-col w-72 bg-white/50 border-r-4 border-white shadow-sm z-10">
        <div className="p-6 flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-primary flex items-center justify-center text-primary-foreground shadow-sm font-display font-bold text-xl transform -rotate-6">
            PF
          </div>
          <h1 className="font-display font-bold text-2xl text-foreground">Pillow Fort</h1>
        </div>

        <nav className="flex-1 overflow-y-auto px-4 py-2 space-y-6">
          <div className="space-y-2">
            <h2 className="px-2 text-xs font-bold text-muted-foreground uppercase tracking-wider mb-2">Menu</h2>
            <NavItem href="/home" icon={HomeIcon} label="Home" active={location === '/home'} />
            <NavItem href="/friends" icon={Users} label="Friends" active={location === '/friends'} badge={homeSummary?.pendingRequestCount} />
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between px-2 mb-2">
              <h2 className="text-xs font-bold text-muted-foreground uppercase tracking-wider">Forts & Chats</h2>
              <NewFortButton compact />
            </div>
            {rooms?.map(room => (
              <NavItem 
                key={room.id}
                href={`/chat/${room.id}`}
                label={room.name}
                active={location === `/chat/${room.id}`}
                badge={room.unreadCount}
                colorKey={room.colorKey}
                pictureUrl={room.kind === 'group' ? room.pictureUrl : room.otherUser?.avatarUrl}
              />
            ))}
            {rooms?.length === 0 && (
              <div className="px-2 space-y-3">
                <div className="py-4 text-sm text-muted-foreground text-center bg-white rounded-xl border-2 border-dashed border-border">
                  No active chats yet.
                </div>
                <NewFortButton />
              </div>
            )}
          </div>
        </nav>

        <div className="p-4 border-t-2 border-border/50 bg-white/50">
          <div className="flex items-center gap-3 mb-4">
            <div className={`w-12 h-12 rounded-full border-4 ${meColors.border} ${meColors.bg} overflow-hidden flex-shrink-0 shadow-sm transform hover:rotate-12 transition-transform`}>
              {me?.avatarUrl ? (
                <img src={me.avatarUrl} alt={me.displayName} className="w-full h-full object-cover" />
              ) : (
                <div className={`w-full h-full flex items-center justify-center font-display font-bold text-xl ${meColors.text}`}>
                  {me?.displayName?.[0]?.toUpperCase()}
                </div>
              )}
            </div>
            <div className="flex-1 min-w-0">
              <div className="font-bold text-foreground truncate">{me?.displayName}</div>
              <div className="text-xs text-muted-foreground truncate">@{me?.username}</div>
            </div>
          </div>
          <div className="flex gap-2">
            <Link href="/profile" className="flex-1 py-2 px-3 bg-white border-2 border-border rounded-xl text-center text-sm font-bold text-foreground hover:bg-black/5 transition-colors">
              Profile
            </Link>
            <button 
              onClick={() => signOut({ redirectUrl: '/' })}
              className="py-2 px-3 bg-white border-2 border-border rounded-xl text-muted-foreground hover:text-destructive hover:bg-destructive/10 transition-colors"
              aria-label="Sign out"
            >
              <LogOut className="w-5 h-5" />
            </button>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col min-w-0 bg-background relative z-0 h-full overflow-hidden">
        {/* Mobile Header */}
        <header className="md:hidden flex items-center justify-between p-4 bg-white/80 backdrop-blur border-b-2 border-white sticky top-0 z-10 shadow-sm">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-primary flex items-center justify-center text-primary-foreground shadow-sm font-display font-bold text-lg transform -rotate-6">
              PF
            </div>
            <h1 className="font-display font-bold text-xl text-foreground">Pillow Fort</h1>
          </div>
        </header>

        <div className="flex-1 overflow-hidden relative">
          {children}
        </div>

        {/* Mobile Bottom Nav */}
        <nav className="md:hidden flex items-center justify-around p-3 bg-white border-t-2 border-border pb-safe z-10 shadow-[0_-4px_20px_rgba(0,0,0,0.05)]">
          <MobileNavItem href="/home" icon={HomeIcon} active={location === '/home'} />
          <MobileNavItem href="/friends" icon={Users} active={location === '/friends'} badge={homeSummary?.pendingRequestCount} />
          
          <Dialog open={mobileMenuOpen} onOpenChange={setMobileMenuOpen}>
            <DialogTrigger asChild>
              <button className={`p-3 rounded-2xl transition-all ${mobileMenuOpen ? 'bg-primary text-primary-foreground scale-95 shadow-inner' : 'text-muted-foreground hover:bg-black/5'}`}>
                <MessageSquare className="w-6 h-6" />
                {(homeSummary?.unreadTotal || 0) > 0 && (
                  <span className="absolute top-2 right-2 w-3 h-3 bg-destructive rounded-full border-2 border-white" />
                )}
              </button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[425px] bg-background border-4 border-white shadow-xl rounded-3xl p-0 overflow-hidden">
              <div className="p-4 bg-white border-b-2 border-border">
                <DialogTitle className="font-display font-bold text-xl">Forts & Chats</DialogTitle>
              </div>
              <div className="p-4 max-h-[60vh] overflow-y-auto space-y-2">
                <button
                  onClick={() => {
                    setMobileMenuOpen(false);
                    setCreateFortOpen(true);
                  }}
                  className="w-full flex items-center justify-center gap-2 py-3 rounded-2xl bg-white border-2 border-dashed border-border font-bold text-muted-foreground active:scale-95 transition-transform"
                >
                  <Plus className="w-4 h-4" />
                  Build a fort
                </button>
                {rooms?.map(room => (
                  <Link key={room.id} href={`/chat/${room.id}`} onClick={() => setMobileMenuOpen(false)}>
                    <div className="flex items-center gap-3 p-3 bg-white border-2 border-border rounded-2xl active:scale-95 transition-transform">
                      <div className={`w-10 h-10 rounded-full border-2 border-white shadow-sm overflow-hidden flex items-center justify-center font-bold ${getAccentClasses(room.colorKey).bg} ${getAccentClasses(room.colorKey).text}`}>
                        {(room.kind === 'group' ? room.pictureUrl : room.otherUser?.avatarUrl)
                          ? <img src={(room.kind === 'group' ? room.pictureUrl : room.otherUser?.avatarUrl)!} alt="" className="w-full h-full object-cover" />
                          : room.name[0]?.toUpperCase()}
                      </div>
                      <div className="flex-1 font-bold">{room.name}</div>
                      {room.unreadCount > 0 && (
                        <div className="px-2 py-0.5 rounded-full bg-destructive text-destructive-foreground text-xs font-bold">
                          {room.unreadCount}
                        </div>
                      )}
                    </div>
                  </Link>
                ))}
              </div>
            </DialogContent>
          </Dialog>

          <MobileNavItem href="/profile" icon={User} active={location === '/profile'} />
        </nav>
      </main>

      <CreateFortDialog open={createFortOpen} onOpenChange={setCreateFortOpen} />
    </div>
  );
}

function NavItem({ href, icon: Icon, label, active, badge, colorKey, pictureUrl }: { href: string, icon?: any, label: string, active?: boolean, badge?: number, colorKey?: string, pictureUrl?: string | null }) {
  const colors = colorKey ? getAccentClasses(colorKey) : null;
  
  return (
    <Link href={href} className="block group outline-none">
      <motion.div 
        whileHover={{ scale: 1.02 }}
        whileTap={{ scale: 0.96 }}
        className={`flex items-center justify-between p-3 rounded-2xl transition-all duration-200 border-2 ${
          active 
            ? 'bg-white border-border shadow-sm' 
            : 'border-transparent hover:bg-white/60 focus:bg-white/60'
        }`}
      >
        <div className="flex items-center gap-3 min-w-0">
          {Icon && (
            <div className={`p-2 rounded-xl ${active ? 'bg-primary/20 text-primary-foreground' : 'text-muted-foreground group-hover:text-foreground'}`}>
              <Icon className="w-5 h-5" />
            </div>
          )}
          {colors && (
            <div className={`w-8 h-8 rounded-full border-2 border-white shadow-sm flex-shrink-0 overflow-hidden flex items-center justify-center font-bold text-sm ${colors.bg} ${colors.text}`}>
              {pictureUrl ? <img src={pictureUrl} alt="" className="w-full h-full object-cover" /> : label[0]?.toUpperCase()}
            </div>
          )}
          <span className={`font-bold truncate ${active ? 'text-foreground' : 'text-muted-foreground group-hover:text-foreground'}`}>
            {label}
          </span>
        </div>
        
        {badge ? (
          <div className="px-2 py-1 rounded-full bg-destructive text-destructive-foreground text-xs font-bold shadow-sm">
            {badge}
          </div>
        ) : null}
      </motion.div>
    </Link>
  );
}

function MobileNavItem({ href, icon: Icon, active, badge }: { href: string, icon: any, active?: boolean, badge?: number }) {
  return (
    <Link href={href} className="relative outline-none">
      <div className={`p-3 rounded-2xl transition-all active:scale-90 ${active ? 'bg-primary text-primary-foreground shadow-inner' : 'text-muted-foreground hover:bg-black/5'}`}>
        <Icon className="w-6 h-6" />
        {badge ? (
          <span className="absolute top-2 right-2 w-3 h-3 bg-destructive rounded-full border-2 border-white" />
        ) : null}
      </div>
    </Link>
  );
}
