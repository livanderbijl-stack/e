import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { useQueryClient } from "@tanstack/react-query";
import {
  useUpdateRoom,
  useAddRoomMember,
  useRemoveRoomMember,
  useLeaveRoom,
  useListFriends,
  useGetMe,
  getListRoomsQueryKey,
  getGetRoomQueryKey,
  getGetHomeSummaryQueryKey,
  type RoomDetail,
} from "@workspace/api-client-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogTitle,
} from "@/components/ui/dialog";
import { ACCENT_COLORS, getAccentClasses } from "@/lib/theme";
import { useDirectUpload } from "@/lib/upload";
import { Camera, Check, DoorOpen, Loader2, Plus, Settings2, X } from "lucide-react";

const NAME_LIMIT = 60;
const DESCRIPTION_LIMIT = 200;

export function FortSettingsDialog({
  room,
  open,
  onOpenChange,
}: {
  room: RoomDetail;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}) {
  const [, setLocation] = useLocation();
  const queryClient = useQueryClient();
  const { data: me } = useGetMe();
  const { data: friends } = useListFriends();

  const updateRoom = useUpdateRoom();
  const addMember = useAddRoomMember();
  const removeMember = useRemoveRoomMember();
  const leaveRoom = useLeaveRoom();
  const { uploadFile, isUploading } = useDirectUpload();

  const [name, setName] = useState(room.name);
  const [description, setDescription] = useState(room.description ?? "");
  const [colorKey, setColorKey] = useState(room.colorKey);
  const [pictureObjectPath, setPictureObjectPath] = useState<string | null | undefined>(undefined);
  const [confirmLeave, setConfirmLeave] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Re-sync when the room changes underneath the dialog (realtime edits).
  useEffect(() => {
    if (!open) return;
    setName(room.name);
    setDescription(room.description ?? "");
    setColorKey(room.colorKey);
    setPictureObjectPath(undefined);
    setConfirmLeave(false);
    setError(null);
  }, [open, room.name, room.description, room.colorKey, room.pictureUrl]);

  const isOwner = !!me && room.ownerId === me.id;
  const memberIds = new Set(room.members.map((member) => member.user.id));
  const invitable = (friends ?? []).filter(
    (friend) => !memberIds.has(friend.user.id),
  );

  const refresh = () =>
    Promise.all([
      queryClient.invalidateQueries({ queryKey: getGetRoomQueryKey(room.id) }),
      queryClient.invalidateQueries({ queryKey: getListRoomsQueryKey() }),
      queryClient.invalidateQueries({ queryKey: getGetHomeSummaryQueryKey() }),
    ]);

  const dirty =
    name.trim() !== room.name ||
    description.trim() !== (room.description ?? "") ||
    colorKey !== room.colorKey ||
    pictureObjectPath !== undefined;

  const handlePicture = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    event.target.value = "";
    if (!file) return;
    if (!["image/jpeg", "image/png", "image/webp", "image/gif", "image/avif"].includes(file.type)) {
      setError("Choose a JPEG, PNG, WebP, GIF or AVIF image.");
      return;
    }
    if (file.size > 10 * 1024 * 1024) {
      setError("Choose a picture smaller than 10 MB.");
      return;
    }
    setError(null);
    try {
      const { objectPath } = await uploadFile(file);
      setPictureObjectPath(objectPath);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Couldn't upload that picture.");
    }
  };

  const handleSave = async () => {
    const trimmed = name.trim();
    if (!trimmed) {
      setError("Your fort needs a name.");
      return;
    }
    setError(null);
    try {
      await updateRoom.mutateAsync({
        roomId: room.id,
        data: { name: trimmed, description: description.trim(), colorKey, ...(pictureObjectPath !== undefined ? { pictureObjectPath } : {}) },
      });
      await refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Couldn't save those changes.");
    }
  };

  const handleAdd = async (userId: string) => {
    setError(null);
    try {
      await addMember.mutateAsync({ roomId: room.id, data: { userId } });
      await refresh();
    } catch {
      setError("Couldn't add them to the fort.");
    }
  };

  const handleRemove = async (userId: string) => {
    setError(null);
    try {
      await removeMember.mutateAsync({ roomId: room.id, userId });
      await refresh();
    } catch {
      setError("Couldn't remove them.");
    }
  };

  const handleLeave = async () => {
    setError(null);
    try {
      await leaveRoom.mutateAsync({ roomId: room.id });

      // Anything still cached for this room is no longer ours to read, so drop
      // it outright — invalidating would leave the old data renderable while a
      // now-forbidden refetch fails.
      // Room keys are the request path (`/api/rooms/<id>`); message keys carry
      // the id inside a params object. Both shapes have to be caught.
      const scopedToRoom = (queryKey: readonly unknown[]) =>
        queryKey.some((part) => {
          if (typeof part === "string") return part.includes(room.id);
          if (part !== null && typeof part === "object") {
            return (part as Record<string, unknown>).roomId === room.id;
          }
          return false;
        });

      await queryClient.cancelQueries({
        predicate: (query) => scopedToRoom(query.queryKey),
      });
      queryClient.removeQueries({
        predicate: (query) => scopedToRoom(query.queryKey),
      });

      await Promise.all([
        queryClient.invalidateQueries({ queryKey: getListRoomsQueryKey() }),
        queryClient.invalidateQueries({
          queryKey: getGetHomeSummaryQueryKey(),
        }),
      ]);
      onOpenChange(false);
      setLocation("/home");
    } catch {
      setError("Couldn't leave the fort.");
    }
  };

  const selected = getAccentClasses(colorKey);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[480px] bg-background border-4 border-white shadow-xl rounded-3xl p-0 overflow-hidden gap-0">
        <div className="p-5 bg-white border-b-2 border-border flex items-center gap-3">
          <div
            className={`w-11 h-11 rounded-[1.1rem] border-2 border-white shadow-sm flex items-center justify-center transform -rotate-6 ${selected.bg} ${selected.text}`}
          >
            <Settings2 className="w-5 h-5" />
          </div>
          <div className="min-w-0">
            <DialogTitle className="font-display font-bold text-xl truncate">
              Fort settings
            </DialogTitle>
            <DialogDescription className="text-xs text-muted-foreground">
              {room.members.length}{" "}
              {room.members.length === 1 ? "member" : "members"}
            </DialogDescription>
          </div>
        </div>

        <div className="p-5 space-y-6 max-h-[70vh] overflow-y-auto">
          <section className="space-y-4">
            <div>
              <span className="block text-xs font-bold text-muted-foreground uppercase tracking-wider mb-2">Fort picture</span>
              <div className="flex items-center gap-3">
                <div className={`w-16 h-16 rounded-2xl border-2 border-white shadow-sm flex items-center justify-center overflow-hidden font-display font-bold text-2xl ${selected.bg} ${selected.text}`}>
                  {isUploading ? <Loader2 className="w-6 h-6 animate-spin" /> : pictureObjectPath || (pictureObjectPath === undefined && room.pictureUrl) ? (
                    <img src={pictureObjectPath ? `/api/storage${pictureObjectPath}` : room.pictureUrl!} alt="" className="w-full h-full object-cover" />
                  ) : room.name[0]?.toUpperCase()}
                </div>
                {isOwner ? (
                  <div className="flex gap-2">
                    <label className={`px-3 py-2 rounded-xl bg-white border-2 border-border font-bold text-sm flex items-center gap-2 ${isUploading || updateRoom.isPending ? "opacity-50 pointer-events-none" : "cursor-pointer"}`}>
                      <Camera className="w-4 h-4" /> {isUploading ? "Uploading..." : "Choose picture"}
                      <input type="file" accept="image/jpeg,image/png,image/webp,image/gif,image/avif" className="hidden" disabled={isUploading || updateRoom.isPending} onChange={handlePicture} />
                    </label>
                    {(pictureObjectPath || (pictureObjectPath === undefined && room.pictureUrl)) && (
                      <button type="button" disabled={isUploading || updateRoom.isPending} onClick={() => setPictureObjectPath(null)} className="px-3 py-2 rounded-xl bg-white border-2 border-border font-bold text-sm disabled:opacity-50">Remove</button>
                    )}
                  </div>
                ) : <span className="text-xs text-muted-foreground">Only the owner can change this picture.</span>}
              </div>
              {isOwner && <p className="text-xs text-muted-foreground mt-2">Choose or remove a picture, then save changes.</p>}
            </div>
            <div>
              <label
                htmlFor="settings-name"
                className="block text-xs font-bold text-muted-foreground uppercase tracking-wider mb-2"
              >
                Fort name
              </label>
              <input
                id="settings-name"
                value={name}
                onChange={(e) => setName(e.target.value.slice(0, NAME_LIMIT))}
                className="w-full bg-white border-2 border-border rounded-2xl py-3 px-4 font-medium outline-none focus:ring-4 focus:ring-primary/20 transition-shadow"
              />
            </div>

            <div>
              <label
                htmlFor="settings-description"
                className="block text-xs font-bold text-muted-foreground uppercase tracking-wider mb-2"
              >
                What's it for
              </label>
              <input
                id="settings-description"
                value={description}
                onChange={(e) =>
                  setDescription(e.target.value.slice(0, DESCRIPTION_LIMIT))
                }
                placeholder="Add a little description"
                className="w-full bg-white border-2 border-border rounded-2xl py-3 px-4 font-medium outline-none focus:ring-4 focus:ring-primary/20 transition-shadow"
              />
            </div>

            <div>
              <span className="block text-xs font-bold text-muted-foreground uppercase tracking-wider mb-2">
                Fort colour
              </span>
              <div className="flex gap-2 flex-wrap">
                {ACCENT_COLORS.map((color) => {
                  const colors = getAccentClasses(color);
                  const active = color === colorKey;
                  return (
                    <button
                      key={color}
                      type="button"
                      onClick={() => setColorKey(color)}
                      aria-label={color}
                      aria-pressed={active}
                      className={`w-11 h-11 rounded-2xl border-4 shadow-sm transition-transform flex items-center justify-center ${colors.bg} ${
                        active
                          ? "border-foreground/30 scale-105"
                          : "border-white hover:scale-105"
                      }`}
                    >
                      {active && <Check className="w-5 h-5 text-white" />}
                    </button>
                  );
                })}
              </div>
            </div>

            {dirty && (
              <button
                onClick={handleSave}
                disabled={updateRoom.isPending || isUploading}
                className="w-full py-3 rounded-2xl bg-primary text-primary-foreground font-bold shadow-sm border-2 border-white disabled:opacity-50 flex items-center justify-center gap-2"
              >
                {updateRoom.isPending ? (
                  <Loader2 className="w-5 h-5 animate-spin" />
                ) : (
                  "Save changes"
                )}
              </button>
            )}
          </section>

          <section>
            <h3 className="text-xs font-bold text-muted-foreground uppercase tracking-wider mb-2">
              Who's inside
            </h3>
            <div className="space-y-2">
              {room.members.map((member) => {
                const colors = getAccentClasses(member.user.accentColor);
                const isMe = member.user.id === me?.id;
                const canRemove = isOwner && !isMe;
                return (
                  <div
                    key={member.user.id}
                    className="flex items-center gap-3 p-2.5 bg-white border-2 border-border rounded-2xl"
                  >
                    <div
                      className={`w-9 h-9 rounded-full border-2 border-white shadow-sm flex-shrink-0 flex items-center justify-center font-bold ${colors.bg} ${colors.text}`}
                    >
                      {member.user.avatarUrl ? (
                        <img
                          src={member.user.avatarUrl}
                          alt=""
                          className="w-full h-full rounded-full object-cover"
                        />
                      ) : (
                        member.user.displayName[0]?.toUpperCase()
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="font-bold text-sm truncate">
                        {member.user.displayName}
                        {isMe && (
                          <span className="text-muted-foreground font-medium">
                            {" "}
                            (you)
                          </span>
                        )}
                      </div>
                      <div className="text-xs text-muted-foreground truncate">
                        @{member.user.username}
                      </div>
                    </div>
                    {member.role === "owner" && (
                      <span className="px-2 py-0.5 rounded-full bg-black/5 text-[11px] font-bold text-muted-foreground">
                        Owner
                      </span>
                    )}
                    {canRemove && (
                      <button
                        onClick={() => handleRemove(member.user.id)}
                        disabled={removeMember.isPending}
                        aria-label={`Remove ${member.user.displayName}`}
                        className="w-8 h-8 rounded-xl bg-destructive/10 text-destructive flex items-center justify-center hover:bg-destructive hover:text-white transition-colors disabled:opacity-50"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                );
              })}
            </div>
          </section>

          {invitable.length > 0 && (
            <section>
              <h3 className="text-xs font-bold text-muted-foreground uppercase tracking-wider mb-2">
                Invite more friends
              </h3>
              <div className="space-y-2 max-h-44 overflow-y-auto pr-1">
                {invitable.map((friend) => {
                  const colors = getAccentClasses(friend.user.accentColor);
                  return (
                    <div
                      key={friend.user.id}
                      className="flex items-center gap-3 p-2.5 bg-white border-2 border-border rounded-2xl"
                    >
                      <div
                        className={`w-9 h-9 rounded-full border-2 border-white shadow-sm flex-shrink-0 flex items-center justify-center font-bold ${colors.bg} ${colors.text}`}
                      >
                        {friend.user.avatarUrl ? (
                          <img
                            src={friend.user.avatarUrl}
                            alt=""
                            className="w-full h-full rounded-full object-cover"
                          />
                        ) : (
                          friend.user.displayName[0]?.toUpperCase()
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="font-bold text-sm truncate">
                          {friend.user.displayName}
                        </div>
                        <div className="text-xs text-muted-foreground truncate">
                          @{friend.user.username}
                        </div>
                      </div>
                      <button
                        onClick={() => handleAdd(friend.user.id)}
                        disabled={addMember.isPending}
                        aria-label={`Add ${friend.user.displayName}`}
                        className="w-8 h-8 rounded-xl bg-primary text-primary-foreground flex items-center justify-center hover:brightness-95 transition-colors disabled:opacity-50"
                      >
                        <Plus className="w-4 h-4" />
                      </button>
                    </div>
                  );
                })}
              </div>
            </section>
          )}

          {error && (
            <p
              role="alert"
              className="text-sm font-bold text-destructive text-center"
            >
              {error}
            </p>
          )}

          <section className="pt-2 border-t-2 border-border/60">
            {confirmLeave ? (
              <div
                role="alertdialog"
                aria-label="Confirm leaving this fort"
                className="p-3 bg-destructive/5 border-2 border-destructive/30 rounded-2xl space-y-3"
              >
                <p className="text-sm font-medium text-foreground text-center">
                  Leave this fort? You'll need an invite to come back.
                </p>
                <div className="flex gap-2">
                  <button
                    autoFocus
                    onClick={() => setConfirmLeave(false)}
                    className="flex-1 py-2.5 rounded-xl border-2 border-border bg-white font-bold text-muted-foreground hover:bg-black/5 transition-colors"
                  >
                    Stay
                  </button>
                  <button
                    onClick={handleLeave}
                    disabled={leaveRoom.isPending}
                    className="flex-1 py-2.5 rounded-xl bg-destructive text-destructive-foreground font-bold disabled:opacity-50 flex items-center justify-center"
                  >
                    {leaveRoom.isPending ? (
                      <Loader2 className="w-5 h-5 animate-spin" />
                    ) : (
                      "Leave fort"
                    )}
                  </button>
                </div>
              </div>
            ) : (
              <button
                onClick={() => setConfirmLeave(true)}
                className="w-full py-3 rounded-2xl border-2 border-border bg-white font-bold text-muted-foreground hover:text-destructive hover:border-destructive/40 transition-colors flex items-center justify-center gap-2"
              >
                <DoorOpen className="w-4 h-4" />
                Leave fort
              </button>
            )}
          </section>
        </div>
      </DialogContent>
    </Dialog>
  );
}
