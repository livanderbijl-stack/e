import { useState } from "react";
import { useLocation } from "wouter";
import { useQueryClient } from "@tanstack/react-query";
import {
  useCreateRoom,
  useListFriends,
  getListRoomsQueryKey,
  getGetHomeSummaryQueryKey,
} from "@workspace/api-client-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogTitle,
} from "@/components/ui/dialog";
import { ACCENT_COLORS, getAccentClasses } from "@/lib/theme";
import { useDirectUpload } from "@/lib/upload";
import { Camera, Check, Loader2, Tent, UserPlus } from "lucide-react";
import { motion } from "framer-motion";

const NAME_LIMIT = 60;
const DESCRIPTION_LIMIT = 200;

export function CreateFortDialog({
  open,
  onOpenChange,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}) {
  const [, setLocation] = useLocation();
  const queryClient = useQueryClient();
  const { data: friends } = useListFriends();
  const createRoom = useCreateRoom();
  const { uploadFile, isUploading } = useDirectUpload();

  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [colorKey, setColorKey] = useState<string>("lilac");
  const [pictureObjectPath, setPictureObjectPath] = useState<string | null>(null);
  const [memberIds, setMemberIds] = useState<string[]>([]);
  const [error, setError] = useState<string | null>(null);

  const reset = () => {
    setName("");
    setDescription("");
    setColorKey("lilac");
    setPictureObjectPath(null);
    setMemberIds([]);
    setError(null);
  };

  // Closing mid-create would still navigate (or resurface a stale error) when
  // the request lands, so the dialog stays put until it settles.
  const close = (next: boolean) => {
    if (!next && (createRoom.isPending || isUploading)) return;
    if (!next) reset();
    onOpenChange(next);
  };

  const toggleMember = (id: string) => {
    setMemberIds((prev) =>
      prev.includes(id) ? prev.filter((m) => m !== id) : [...prev, id],
    );
  };

  const handlePicture = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    event.target.value = "";
    if (!file) return;
    if (!["image/jpeg", "image/png", "image/webp", "image/gif", "image/avif"].includes(file.type)) {
      setError("Choose a JPEG, PNG, WebP, GIF or AVIF image.");
      return;
    }
    if (file.size > 10 * 1024 * 1024) {
      setError("Choose a picture smaller than 10 MB.");
      return;
    }
    setError(null);
    try {
      const { objectPath } = await uploadFile(file);
      setPictureObjectPath(objectPath);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Couldn't upload that picture.");
    }
  };

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault();
    const trimmed = name.trim();
    if (!trimmed) {
      setError("Your fort needs a name.");
      return;
    }

    setError(null);
    try {
      const room = await createRoom.mutateAsync({
        data: {
          name: trimmed,
          description: description.trim() || undefined,
          colorKey,
          ...(pictureObjectPath ? { pictureObjectPath } : {}),
          memberIds,
        },
      });
      await Promise.all([
        queryClient.invalidateQueries({ queryKey: getListRoomsQueryKey() }),
        queryClient.invalidateQueries({
          queryKey: getGetHomeSummaryQueryKey(),
        }),
      ]);
      close(false);
      setLocation(`/chat/${room.id}`);
    } catch {
      setError("That didn't work. Give it another try.");
    }
  };

  const selected = getAccentClasses(colorKey);

  return (
    <Dialog open={open} onOpenChange={close}>
      <DialogContent
        className="sm:max-w-[480px] bg-background border-4 border-white shadow-xl rounded-3xl p-0 overflow-hidden gap-0"
        onEscapeKeyDown={(e) => {
          if (createRoom.isPending || isUploading) e.preventDefault();
        }}
        onPointerDownOutside={(e) => {
          if (createRoom.isPending || isUploading) e.preventDefault();
        }}
        onInteractOutside={(e) => {
          if (createRoom.isPending || isUploading) e.preventDefault();
        }}
      >
        <div className="p-5 bg-white border-b-2 border-border flex items-center gap-3">
          <div
            className={`w-11 h-11 rounded-[1.1rem] border-2 border-white shadow-sm flex items-center justify-center transform -rotate-6 ${selected.bg} ${selected.text}`}
          >
            <Tent className="w-5 h-5" />
          </div>
          <div>
            <DialogTitle className="font-display font-bold text-xl">
              Build a fort
            </DialogTitle>
            <DialogDescription className="text-xs text-muted-foreground">
              A group chat for a few of your people.
            </DialogDescription>
          </div>
        </div>

        <form
          onSubmit={handleSubmit}
          className="p-5 space-y-5 max-h-[70vh] overflow-y-auto"
        >
          <div>
            <span className="block text-xs font-bold text-muted-foreground uppercase tracking-wider mb-2">Fort picture (optional)</span>
            <div className="flex items-center gap-3">
              <div className={`w-14 h-14 rounded-2xl border-2 border-white shadow-sm flex items-center justify-center overflow-hidden font-bold text-xl ${selected.bg} ${selected.text}`}>
                {isUploading ? <Loader2 className="w-5 h-5 animate-spin" /> : pictureObjectPath ? <img src={`/api/storage${pictureObjectPath}`} alt="" className="w-full h-full object-cover" /> : name[0]?.toUpperCase() || "?"}
              </div>
              <label className={`px-3 py-2 rounded-xl bg-white border-2 border-border font-bold text-sm flex items-center gap-2 ${isUploading ? "opacity-50 pointer-events-none" : "cursor-pointer"}`}>
                <Camera className="w-4 h-4" /> Choose picture
                <input type="file" accept="image/jpeg,image/png,image/webp,image/gif,image/avif" className="hidden" disabled={isUploading} onChange={handlePicture} />
              </label>
              {pictureObjectPath && <button type="button" onClick={() => setPictureObjectPath(null)} className="text-sm font-bold text-muted-foreground">Remove</button>}
            </div>
          </div>
          <div>
            <label
              htmlFor="fort-name"
              className="block text-xs font-bold text-muted-foreground uppercase tracking-wider mb-2"
            >
              Fort name
            </label>
            <input
              id="fort-name"
              value={name}
              onChange={(e) => setName(e.target.value.slice(0, NAME_LIMIT))}
              placeholder="Sunday Movie Club"
              className="w-full bg-white border-2 border-border rounded-2xl py-3 px-4 font-medium outline-none focus:ring-4 focus:ring-primary/20 transition-shadow"
              autoFocus
            />
          </div>

          <div>
            <label
              htmlFor="fort-description"
              className="block text-xs font-bold text-muted-foreground uppercase tracking-wider mb-2"
            >
              What's it for{" "}
              <span className="normal-case font-medium">(optional)</span>
            </label>
            <input
              id="fort-description"
              value={description}
              onChange={(e) =>
                setDescription(e.target.value.slice(0, DESCRIPTION_LIMIT))
              }
              placeholder="Snacks, films, and bad opinions"
              className="w-full bg-white border-2 border-border rounded-2xl py-3 px-4 font-medium outline-none focus:ring-4 focus:ring-primary/20 transition-shadow"
            />
          </div>

          <div>
            <span className="block text-xs font-bold text-muted-foreground uppercase tracking-wider mb-2">
              Fort colour
            </span>
            <div className="flex gap-2 flex-wrap">
              {ACCENT_COLORS.map((color) => {
                const colors = getAccentClasses(color);
                const active = color === colorKey;
                return (
                  <button
                    key={color}
                    type="button"
                    onClick={() => setColorKey(color)}
                    aria-label={color}
                    aria-pressed={active}
                    className={`w-11 h-11 rounded-2xl border-4 shadow-sm transition-transform flex items-center justify-center ${colors.bg} ${
                      active
                        ? "border-foreground/30 scale-105"
                        : "border-white hover:scale-105"
                    }`}
                  >
                    {active && <Check className="w-5 h-5 text-white" />}
                  </button>
                );
              })}
            </div>
          </div>

          <div>
            <div className="flex items-baseline justify-between mb-2">
              <span className="text-xs font-bold text-muted-foreground uppercase tracking-wider">
                Invite friends
              </span>
              {memberIds.length > 0 && (
                <span className="text-xs font-bold text-foreground">
                  {memberIds.length} selected
                </span>
              )}
            </div>

            {friends?.length ? (
              <div className="space-y-2 max-h-52 overflow-y-auto pr-1">
                {friends.map((friend) => {
                  const colors = getAccentClasses(friend.user.accentColor);
                  const active = memberIds.includes(friend.user.id);
                  return (
                    <button
                      key={friend.user.id}
                      type="button"
                      onClick={() => toggleMember(friend.user.id)}
                      aria-pressed={active}
                      className={`w-full flex items-center gap-3 p-2.5 rounded-2xl border-2 text-left transition-colors ${
                        active
                          ? "bg-primary/15 border-primary"
                          : "bg-white border-border hover:bg-black/[0.03]"
                      }`}
                    >
                      <div
                        className={`w-9 h-9 rounded-full border-2 border-white shadow-sm flex-shrink-0 flex items-center justify-center font-bold ${colors.bg} ${colors.text}`}
                      >
                        {friend.user.avatarUrl ? (
                          <img
                            src={friend.user.avatarUrl}
                            alt=""
                            className="w-full h-full rounded-full object-cover"
                          />
                        ) : (
                          friend.user.displayName[0]?.toUpperCase()
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="font-bold text-sm truncate">
                          {friend.user.displayName}
                        </div>
                        <div className="text-xs text-muted-foreground truncate">
                          @{friend.user.username}
                        </div>
                      </div>
                      <div
                        className={`w-6 h-6 rounded-lg border-2 flex items-center justify-center flex-shrink-0 ${
                          active
                            ? "bg-primary border-primary text-primary-foreground"
                            : "border-border"
                        }`}
                      >
                        {active && <Check className="w-4 h-4" />}
                      </div>
                    </button>
                  );
                })}
              </div>
            ) : (
              <div className="p-4 bg-white rounded-2xl border-2 border-dashed border-border text-center">
                <UserPlus className="w-6 h-6 text-muted-foreground mx-auto mb-2" />
                <p className="text-sm text-muted-foreground">
                  Add friends first, then you can invite them in.
                </p>
              </div>
            )}
          </div>

          {error && (
            <p
              role="alert"
              className="text-sm font-bold text-destructive text-center"
            >
              {error}
            </p>
          )}

          <div className="flex gap-2 pt-1">
            <button
              type="button"
              onClick={() => close(false)}
              className="flex-1 py-3 rounded-2xl border-2 border-border bg-white font-bold text-muted-foreground hover:bg-black/5 transition-colors"
            >
              Never mind
            </button>
            <motion.button
              type="submit"
              whileTap={{ scale: 0.97 }}
              disabled={createRoom.isPending || isUploading || !name.trim()}
              className="flex-1 py-3 rounded-2xl bg-primary text-primary-foreground font-bold shadow-sm border-2 border-white disabled:opacity-50 flex items-center justify-center gap-2"
            >
              {createRoom.isPending ? (
                <Loader2 className="w-5 h-5 animate-spin" />
              ) : (
                "Build it"
              )}
            </motion.button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}

export function NewFortButton({ compact }: { compact?: boolean }) {
  const [open, setOpen] = useState(false);

  return (
    <>
      {compact ? (
        <button
          onClick={() => setOpen(true)}
          aria-label="Build a fort"
          className="p-1.5 rounded-xl text-muted-foreground hover:text-foreground hover:bg-white transition-colors"
        >
          <Tent className="w-4 h-4" />
        </button>
      ) : (
        <button
          onClick={() => setOpen(true)}
          className="w-full flex items-center justify-center gap-2 py-3 rounded-2xl bg-white border-2 border-dashed border-border font-bold text-muted-foreground hover:text-foreground hover:border-primary transition-colors"
        >
          <Tent className="w-4 h-4" />
          Build a fort
        </button>
      )}
      <CreateFortDialog open={open} onOpenChange={setOpen} />
    </>
  );
}
