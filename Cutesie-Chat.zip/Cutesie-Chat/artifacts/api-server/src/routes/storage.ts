import { Readable } from "stream";
import {
  RequestUploadUrlBody,
  RequestUploadUrlResponse,
} from "@workspace/api-zod";
import { Router, type IRouter, type Request, type Response } from "express";

import {
  db,
  uploadsTable,
  usersTable,
  attachmentsTable,
  messagesTable,
  roomMembersTable,
  roomsTable,
} from "@workspace/db";
import { and, eq } from "drizzle-orm";

import {
  ObjectNotFoundError,
  ObjectStorageService,
} from "../lib/objectStorage";
import { currentUser, requireUser } from "../lib/auth";

const router: IRouter = Router();
const objectStorageService = new ObjectStorageService();

/**
 * A stored object may be read by the person who uploaded it, by anyone when it
 * is somebody's avatar, and by the members of a room where it was shared.
 */
async function canRead(objectPath: string, viewerId: string): Promise<boolean> {
  const [upload] = await db
    .select({ uploaderId: uploadsTable.uploaderId })
    .from(uploadsTable)
    .where(eq(uploadsTable.objectPath, objectPath))
    .limit(1);

  if (upload?.uploaderId === viewerId) return true;

  const [avatar] = await db
    .select({ id: usersTable.id })
    .from(usersTable)
    .where(eq(usersTable.avatarPath, objectPath))
    .limit(1);

  if (avatar) return true;

  const [fortPicture] = await db
    .select({ id: roomsTable.id })
    .from(roomsTable)
    .where(and(eq(roomsTable.kind, "group"), eq(roomsTable.picturePath, objectPath)))
    .limit(1);
  if (fortPicture) return true;

  const [shared] = await db
    .select({ id: attachmentsTable.id })
    .from(attachmentsTable)
    .innerJoin(messagesTable, eq(messagesTable.id, attachmentsTable.messageId))
    .innerJoin(
      roomMembersTable,
      and(
        eq(roomMembersTable.roomId, messagesTable.roomId),
        eq(roomMembersTable.userId, viewerId),
      ),
    )
    .where(eq(attachmentsTable.objectPath, objectPath))
    .limit(1);

  return Boolean(shared);
}

/**
 * POST /storage/uploads/request-url
 *
 * Request a presigned URL for file upload.
 * The client sends JSON metadata (name, size, contentType) — NOT the file.
 * Then uploads the file directly to the returned presigned URL.
 * Requires auth middleware so public callers cannot mint write-capable URLs.
 */
router.post(
  "/storage/uploads/request-url",
  requireUser,
  async (req: Request, res: Response) => {
    const viewer = currentUser(req);
    const parsed = RequestUploadUrlBody.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: "Missing or invalid required fields" });
      return;
    }

    try {
      const { name, size, contentType } = parsed.data;

      const uploadURL = await objectStorageService.getObjectEntityUploadURL();
      const objectPath =
        objectStorageService.normalizeObjectEntityPath(uploadURL);

      await db
        .insert(uploadsTable)
        .values({
          objectPath,
          uploaderId: viewer.id,
          fileName: name,
          contentType,
        })
        .onConflictDoNothing();

      res.json(
        RequestUploadUrlResponse.parse({
          uploadURL,
          objectPath,
          metadata: { name, size, contentType },
        }),
      );
    } catch (error) {
      req.log.error({ err: error }, "Error generating upload URL");
      res.status(500).json({ error: "Failed to generate upload URL" });
    }
  },
);

/**
 * GET /storage/public-objects/*
 *
 * Serve public assets from PUBLIC_OBJECT_SEARCH_PATHS.
 * These are unconditionally public — no authentication or ACL checks.
 * IMPORTANT: Always provide this endpoint when object storage is set up.
 */
router.get(
  "/storage/public-objects/*filePath",
  async (req: Request, res: Response) => {
    try {
      const raw = req.params.filePath;
      const filePath = Array.isArray(raw) ? raw.join("/") : raw;
      const file = await objectStorageService.searchPublicObject(filePath);
      if (!file) {
        res.status(404).json({ error: "File not found" });
        return;
      }

      const response = await objectStorageService.downloadObject(file);

      res.status(response.status);
      response.headers.forEach((value, key) => res.setHeader(key, value));

      if (response.body) {
        const nodeStream = Readable.fromWeb(
          response.body as ReadableStream<Uint8Array>,
        );
        nodeStream.pipe(res);
      } else {
        res.end();
      }
    } catch (error) {
      req.log.error({ err: error }, "Error serving public object");
      res.status(500).json({ error: "Failed to serve public object" });
    }
  },
);

/**
 * GET /storage/objects/*
 *
 * Serve object entities from PRIVATE_OBJECT_DIR.
 * These are served from a separate path from /public-objects and can optionally
 * be protected with authentication or ACL checks based on the use case.
 */
router.get(
  "/storage/objects/*path",
  requireUser,
  async (req: Request, res: Response) => {
    try {
      const viewer = currentUser(req);
      const raw = req.params.path;
      const wildcardPath = Array.isArray(raw) ? raw.join("/") : raw;
      const objectPath = `/objects/${wildcardPath}`;

      if (!(await canRead(objectPath, viewer.id))) {
        res.status(403).json({ error: "Forbidden" });
        return;
      }

      const objectFile =
        await objectStorageService.getObjectEntityFile(objectPath);

      const response = await objectStorageService.downloadObject(objectFile);

      res.status(response.status);
      response.headers.forEach((value, key) => res.setHeader(key, value));

      if (response.body) {
        const nodeStream = Readable.fromWeb(
          response.body as ReadableStream<Uint8Array>,
        );
        nodeStream.pipe(res);
      } else {
        res.end();
      }
    } catch (error) {
      if (error instanceof ObjectNotFoundError) {
        req.log.warn({ err: error }, "Object not found");
        res.status(404).json({ error: "Object not found" });
        return;
      }
      req.log.error({ err: error }, "Error serving object");
      res.status(500).json({ error: "Failed to serve object" });
    }
  },
);

export default router;
