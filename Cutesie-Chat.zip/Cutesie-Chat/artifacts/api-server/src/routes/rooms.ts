import { Router, type IRouter } from "express";
import {
  CreateRoomBody,
  UpdateRoomBody,
  AddRoomMemberBody,
  OpenDirectMessageBody,
} from "@workspace/api-zod";
import {
  db,
  roomsTable,
  roomMembersTable,
  messagesTable,
  attachmentsTable,
  linkPreviewsTable,
  usersTable,
  callParticipantsTable,
  uploadsTable,
} from "@workspace/db";
import { and, desc, eq, inArray } from "drizzle-orm";
import { currentUser, requireUser } from "../lib/auth";
import {
  areFriends,
  directRoomKey,
  getMembership,
  listRoomsFor,
  loadUsers,
  serializeRoomDetail,
  serializeUser,
} from "../lib/data";
import { broadcastToRoom, sendToUser } from "../lib/realtime";
import { toServingUrl } from "../lib/serving";
import { ObjectStorageService } from "../lib/objectStorage";

const router: IRouter = Router();

const ACCENTS = new Set(["blush", "lilac", "mint", "butter", "sky", "peach"]);
const PICTURE_TYPES = new Set(["image/jpeg", "image/png", "image/webp", "image/gif", "image/avif"]);
const storage = new ObjectStorageService();

async function validPicture(path: string, userId: string): Promise<boolean> {
  if (!path.startsWith("/objects/")) return false;
  const [upload] = await db.select({ contentType: uploadsTable.contentType })
    .from(uploadsTable)
    .where(and(eq(uploadsTable.objectPath, path), eq(uploadsTable.uploaderId, userId)))
    .limit(1);
  if (!upload || !PICTURE_TYPES.has(upload.contentType)) return false;
  try {
    const file = await storage.getObjectEntityFile(path);
    const [metadata] = await file.getMetadata();
    return PICTURE_TYPES.has(String(metadata.contentType)) &&
      Number(metadata.size) > 0 && Number(metadata.size) <= 10 * 1024 * 1024;
  } catch {
    return false;
  }
}

async function loadRoom(roomId: string) {
  const [room] = await db
    .select()
    .from(roomsTable)
    .where(eq(roomsTable.id, roomId))
    .limit(1);
  return room ?? null;
}

router.get("/rooms", requireUser, async (req, res) => {
  res.json(await listRoomsFor(currentUser(req).id));
});

router.post("/rooms", requireUser, async (req, res) => {
  const viewer = currentUser(req);
  const parsed = CreateRoomBody.safeParse(req.body);

  if (!parsed.success) {
    res.status(400).json({ error: "Give your fort a name to get started" });
    return;
  }

  const { name, description, colorKey, memberIds, pictureObjectPath } = parsed.data;

  if (colorKey && !ACCENTS.has(colorKey)) {
    res.status(400).json({ error: "Unknown colour" });
    return;
  }
  if (pictureObjectPath && !(await validPicture(pictureObjectPath, viewer.id))) {
    res.status(400).json({ error: "Upload an image of your own before using it as a fort picture" });
    return;
  }

  const invited: string[] = [];
  for (const memberId of memberIds ?? []) {
    if (memberId === viewer.id) continue;
    if (await areFriends(viewer.id, memberId)) invited.push(memberId);
  }

  const [room] = await db
    .insert(roomsTable)
    .values({
      kind: "group",
      name: name.trim(),
      description: description ?? null,
      colorKey: colorKey ?? "lilac",
      picturePath: pictureObjectPath ?? null,
      ownerId: viewer.id,
    })
    .returning();

  if (!room) {
    res.status(500).json({ error: "Could not build that fort" });
    return;
  }

  await db.insert(roomMembersTable).values([
    { roomId: room.id, userId: viewer.id, role: "owner" },
    ...[...new Set(invited)].map((userId) => ({
      roomId: room.id,
      userId,
      role: "member",
    })),
  ]);

  for (const userId of invited) {
    sendToUser(userId, { type: "room:updated", roomId: room.id });
  }

  res.status(201).json(await serializeRoomDetail(room, viewer.id));
});

router.get("/rooms/:roomId", requireUser, async (req, res) => {
  const viewer = currentUser(req);
  const room = await loadRoom(String(req.params.roomId));

  if (!room) {
    res.status(404).json({ error: "That conversation is gone" });
    return;
  }

  if (!(await getMembership(room.id, viewer.id))) {
    res.status(403).json({ error: "You are not in that conversation" });
    return;
  }

  res.json(await serializeRoomDetail(room, viewer.id));
});

router.patch("/rooms/:roomId", requireUser, async (req, res) => {
  const viewer = currentUser(req);
  const parsed = UpdateRoomBody.safeParse(req.body);

  if (!parsed.success) {
    res.status(400).json({ error: "Those details do not look right" });
    return;
  }

  const room = await loadRoom(String(req.params.roomId));
  if (!room) {
    res.status(404).json({ error: "That conversation is gone" });
    return;
  }

  const membership = await getMembership(room.id, viewer.id);
  if (!membership) {
    res.status(403).json({ error: "You are not in that conversation" });
    return;
  }

  if (room.kind === "direct") {
    res.status(403).json({ error: "Private chats cannot be renamed" });
    return;
  }

  const { name, description, colorKey, pictureObjectPath } = parsed.data;
  if (colorKey && !ACCENTS.has(colorKey)) {
    res.status(400).json({ error: "Unknown colour" });
    return;
  }
  if (pictureObjectPath !== undefined) {
    if (room.ownerId !== viewer.id) {
      res.status(403).json({ error: "Only the fort owner can change its picture" });
      return;
    }
    if (pictureObjectPath !== null && !(await validPicture(pictureObjectPath, viewer.id))) {
      res.status(400).json({ error: "Upload an image of your own before using it as a fort picture" });
      return;
    }
  }

  const [updated] = await db
    .update(roomsTable)
    .set({
      ...(name ? { name: name.trim() } : {}),
      ...(description !== undefined ? { description } : {}),
      ...(colorKey ? { colorKey } : {}),
      ...(pictureObjectPath !== undefined ? { picturePath: pictureObjectPath } : {}),
      updatedAt: new Date(),
    })
    .where(eq(roomsTable.id, room.id))
    .returning();

  if (!updated) {
    res.status(500).json({ error: "Could not update that fort" });
    return;
  }

  await broadcastToRoom(room.id, { type: "room:updated", roomId: room.id });

  res.json(await serializeRoomDetail(updated, viewer.id));
});

router.delete("/rooms/:roomId", requireUser, async (req, res) => {
  const viewer = currentUser(req);
  const room = await loadRoom(String(req.params.roomId));

  if (!room) {
    res.status(404).json({ error: "That conversation is gone" });
    return;
  }

  if (room.kind === "direct") {
    res.status(403).json({ error: "Private chats cannot be left" });
    return;
  }

  const deleted = await db
    .delete(roomMembersTable)
    .where(
      and(
        eq(roomMembersTable.roomId, room.id),
        eq(roomMembersTable.userId, viewer.id),
      ),
    )
    .returning();

  if (deleted.length === 0) {
    res.status(404).json({ error: "You are not in that conversation" });
    return;
  }

  await db
    .delete(callParticipantsTable)
    .where(
      and(
        eq(callParticipantsTable.roomId, room.id),
        eq(callParticipantsTable.userId, viewer.id),
      ),
    );

  const remaining = await db
    .select({ id: roomMembersTable.id })
    .from(roomMembersTable)
    .where(eq(roomMembersTable.roomId, room.id));

  if (remaining.length === 0) {
    await db.delete(roomsTable).where(eq(roomsTable.id, room.id));
  } else {
    await broadcastToRoom(room.id, { type: "room:updated", roomId: room.id });
  }

  res.json({ ok: true });
});

router.post("/rooms/:roomId/members", requireUser, async (req, res) => {
  const viewer = currentUser(req);
  const parsed = AddRoomMemberBody.safeParse(req.body);

  if (!parsed.success) {
    res.status(400).json({ error: "Pick a friend to invite" });
    return;
  }

  const room = await loadRoom(String(req.params.roomId));
  if (!room) {
    res.status(404).json({ error: "That conversation is gone" });
    return;
  }

  if (room.kind === "direct") {
    res.status(403).json({ error: "Private chats stay between two people" });
    return;
  }

  if (!(await getMembership(room.id, viewer.id))) {
    res.status(403).json({ error: "You are not in that conversation" });
    return;
  }

  if (!(await areFriends(viewer.id, parsed.data.userId))) {
    res
      .status(403)
      .json({ error: "You can only invite people you are friends with" });
    return;
  }

  await db
    .insert(roomMembersTable)
    .values({ roomId: room.id, userId: parsed.data.userId, role: "member" })
    .onConflictDoNothing();

  sendToUser(parsed.data.userId, { type: "room:updated", roomId: room.id });
  await broadcastToRoom(room.id, { type: "room:updated", roomId: room.id });

  res.json(await serializeRoomDetail(room, viewer.id));
});

router.delete(
  "/rooms/:roomId/members/:userId",
  requireUser,
  async (req, res) => {
    const viewer = currentUser(req);
    const room = await loadRoom(String(req.params.roomId));

    if (!room) {
      res.status(404).json({ error: "That conversation is gone" });
      return;
    }

    if (!(await getMembership(room.id, viewer.id))) {
      res.status(403).json({ error: "You are not in that conversation" });
      return;
    }

    if (room.ownerId !== viewer.id) {
      res
        .status(403)
        .json({ error: "Only the person who made the fort can remove people" });
      return;
    }

    if (String(req.params.userId) === viewer.id) {
      res.status(403).json({ error: "Leave the fort instead" });
      return;
    }

    await db
      .delete(roomMembersTable)
      .where(
        and(
          eq(roomMembersTable.roomId, room.id),
          eq(roomMembersTable.userId, String(req.params.userId)),
        ),
      );

    await db
      .delete(callParticipantsTable)
      .where(
        and(
          eq(callParticipantsTable.roomId, room.id),
          eq(callParticipantsTable.userId, String(req.params.userId)),
        ),
      );

    sendToUser(String(req.params.userId), { type: "room:updated", roomId: room.id });
    await broadcastToRoom(room.id, { type: "room:updated", roomId: room.id });

    res.json(await serializeRoomDetail(room, viewer.id));
  },
);

router.post("/rooms/:roomId/read", requireUser, async (req, res) => {
  const viewer = currentUser(req);

  const updated = await db
    .update(roomMembersTable)
    .set({ lastReadAt: new Date() })
    .where(
      and(
        eq(roomMembersTable.roomId, String(req.params.roomId)),
        eq(roomMembersTable.userId, viewer.id),
      ),
    )
    .returning();

  if (updated.length === 0) {
    res.status(404).json({ error: "You are not in that conversation" });
    return;
  }

  res.json({ ok: true });
});

router.get("/rooms/:roomId/media", requireUser, async (req, res) => {
  const viewer = currentUser(req);

  if (!(await getMembership(String(req.params.roomId), viewer.id))) {
    res.status(403).json({ error: "You are not in that conversation" });
    return;
  }

  const messages = await db
    .select()
    .from(messagesTable)
    .where(eq(messagesTable.roomId, String(req.params.roomId)))
    .orderBy(desc(messagesTable.createdAt))
    .limit(300);

  if (messages.length === 0) {
    res.json([]);
    return;
  }

  const messageIds = messages.map((row) => row.id);

  const [attachments, links] = await Promise.all([
    db
      .select()
      .from(attachmentsTable)
      .where(inArray(attachmentsTable.messageId, messageIds)),
    db
      .select()
      .from(linkPreviewsTable)
      .where(inArray(linkPreviewsTable.messageId, messageIds)),
  ]);

  const authorByMessage = new Map(
    messages.map((row) => [row.id, row.authorId]),
  );
  const users = await loadUsers(messages.map((row) => row.authorId));

  const items = [
    ...attachments.map((attachment) => ({
      id: attachment.id,
      messageId: attachment.messageId,
      kind: attachment.kind,
      url: toServingUrl(attachment.objectPath),
      fileName: attachment.fileName,
      contentType: attachment.contentType,
      size: attachment.size,
      linkTitle: null,
      linkImageUrl: null,
      sharedById: authorByMessage.get(attachment.messageId),
      createdAt: attachment.createdAt,
    })),
    ...links.map((link) => ({
      id: link.id,
      messageId: link.messageId,
      kind: "link",
      url: link.url,
      fileName: null,
      contentType: null,
      size: null,
      linkTitle: link.title,
      linkImageUrl: link.imageUrl,
      sharedById: authorByMessage.get(link.messageId),
      createdAt: link.createdAt,
    })),
  ]
    .filter((item) => item.sharedById && users.has(item.sharedById))
    .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())
    .map((item) => ({
      id: item.id,
      messageId: item.messageId,
      kind: item.kind,
      url: item.url,
      fileName: item.fileName,
      contentType: item.contentType,
      size: item.size,
      linkTitle: item.linkTitle,
      linkImageUrl: item.linkImageUrl,
      sharedBy: serializeUser(users.get(item.sharedById!)!),
      createdAt: item.createdAt.toISOString(),
    }));

  res.json(items);
});

router.post("/dms", requireUser, async (req, res) => {
  const viewer = currentUser(req);
  const parsed = OpenDirectMessageBody.safeParse(req.body);

  if (!parsed.success) {
    res.status(400).json({ error: "Pick a friend to chat with" });
    return;
  }

  const friendId = parsed.data.userId;

  if (friendId === viewer.id) {
    res.status(400).json({ error: "You cannot start a chat with yourself" });
    return;
  }

  if (!(await areFriends(viewer.id, friendId))) {
    res
      .status(403)
      .json({ error: "You can only message people you are friends with" });
    return;
  }

  const [friend] = await db
    .select()
    .from(usersTable)
    .where(eq(usersTable.id, friendId))
    .limit(1);

  if (!friend) {
    res.status(404).json({ error: "That person is no longer here" });
    return;
  }

  const dmKey = directRoomKey(viewer.id, friendId);
  const [existing] = await db
    .select()
    .from(roomsTable)
    .where(eq(roomsTable.dmKey, dmKey))
    .limit(1);

  if (existing) {
    res.json(await serializeRoomDetail(existing, viewer.id));
    return;
  }

  const [room] = await db
    .insert(roomsTable)
    .values({
      kind: "direct",
      name: null,
      colorKey: friend.accentColor,
      dmKey,
    })
    .returning();

  if (!room) {
    res.status(500).json({ error: "Could not open that chat" });
    return;
  }

  await db.insert(roomMembersTable).values([
    { roomId: room.id, userId: viewer.id, role: "member" },
    { roomId: room.id, userId: friendId, role: "member" },
  ]);

  sendToUser(friendId, { type: "room:updated", roomId: room.id });

  res.json(await serializeRoomDetail(room, viewer.id));
});

export default router;
