import { Router, type IRouter } from "express";
import {
  db,
  friendshipsTable,
  roomMembersTable,
  roomsTable,
  messagesTable,
  attachmentsTable,
  linkPreviewsTable,
  callParticipantsTable,
} from "@workspace/db";
import { and, desc, eq, inArray, sql } from "drizzle-orm";
import { currentUser, requireUser } from "../lib/auth";
import {
  friendIdsOf,
  getCallState,
  loadUsers,
  previewTextFor,
  serializeUser,
} from "../lib/data";
import { isOnline } from "../lib/presence";

const router: IRouter = Router();

router.get("/home/summary", requireUser, async (req, res) => {
  const viewer = currentUser(req);

  const memberships = await db
    .select()
    .from(roomMembersTable)
    .where(eq(roomMembersTable.userId, viewer.id));

  let unreadTotal = 0;
  for (const membership of memberships) {
    const [row] = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(messagesTable)
      .where(
        and(
          eq(messagesTable.roomId, membership.roomId),
          sql`${messagesTable.createdAt} > ${membership.lastReadAt.toISOString()}`,
          sql`${messagesTable.authorId} <> ${viewer.id}`,
        ),
      );
    unreadTotal += row?.count ?? 0;
  }

  const [friendIds, pending] = await Promise.all([
    friendIdsOf(viewer.id),
    db
      .select({ count: sql<number>`count(*)::int` })
      .from(friendshipsTable)
      .where(
        and(
          eq(friendshipsTable.status, "pending"),
          eq(friendshipsTable.addresseeId, viewer.id),
        ),
      ),
  ]);

  const friends = await loadUsers(friendIds);
  const onlineFriends = [...friends.values()]
    .filter((friend) => isOnline(friend.id))
    .map(serializeUser);

  const roomIds = memberships.map((row) => row.roomId);
  const liveRooms =
    roomIds.length > 0
      ? await db
          .select({ roomId: callParticipantsTable.roomId })
          .from(callParticipantsTable)
          .where(inArray(callParticipantsTable.roomId, roomIds))
      : [];

  const liveCalls = await Promise.all(
    [...new Set(liveRooms.map((row) => row.roomId))].map((roomId) =>
      getCallState(roomId),
    ),
  );

  res.json({
    unreadTotal,
    friendCount: friendIds.length,
    pendingRequestCount: pending[0]?.count ?? 0,
    roomCount: memberships.length,
    onlineFriends,
    liveCalls,
  });
});

router.get("/activity", requireUser, async (req, res) => {
  const viewer = currentUser(req);

  const memberships = await db
    .select({ roomId: roomMembersTable.roomId })
    .from(roomMembersTable)
    .where(eq(roomMembersTable.userId, viewer.id));

  if (memberships.length === 0) {
    res.json([]);
    return;
  }

  const roomIds = memberships.map((row) => row.roomId);

  const messages = await db
    .select()
    .from(messagesTable)
    .where(inArray(messagesTable.roomId, roomIds))
    .orderBy(desc(messagesTable.createdAt))
    .limit(30);

  if (messages.length === 0) {
    res.json([]);
    return;
  }

  const messageIds = messages.map((row) => row.id);

  const [rooms, users, attachments, links] = await Promise.all([
    db.select().from(roomsTable).where(inArray(roomsTable.id, roomIds)),
    loadUsers(messages.map((row) => row.authorId)),
    db
      .select()
      .from(attachmentsTable)
      .where(inArray(attachmentsTable.messageId, messageIds)),
    db
      .select()
      .from(linkPreviewsTable)
      .where(inArray(linkPreviewsTable.messageId, messageIds)),
  ]);

  const roomById = new Map(rooms.map((room) => [room.id, room]));

  const items = messages
    .map((message) => {
      const author = users.get(message.authorId);
      if (!author) return null;

      const room = roomById.get(message.roomId);
      const messageAttachments = attachments.filter(
        (attachment) => attachment.messageId === message.id,
      );
      const hasLink = links.some((link) => link.messageId === message.id);

      let kind: string = "message";
      if (messageAttachments.length > 0) kind = "media";
      else if (hasLink) kind = "link";

      return {
        id: message.id,
        kind,
        roomId: message.roomId,
        roomName:
          room?.kind === "direct"
            ? `Chat with ${author.displayName}`
            : (room?.name ?? "Chat"),
        actor: serializeUser(author),
        summary: previewTextFor(
          message.body,
          messageAttachments.map((attachment) => attachment.kind),
        ),
        createdAt: message.createdAt.toISOString(),
      };
    })
    .filter(Boolean);

  res.json(items);
});

export default router;
