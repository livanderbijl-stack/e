import { Router, type IRouter } from "express";
import { db, callParticipantsTable, roomMembersTable } from "@workspace/db";
import { and, eq, inArray } from "drizzle-orm";
import { currentUser, requireUser } from "../lib/auth";
import { getCallState, getMembership } from "../lib/data";
import { broadcastToRoom } from "../lib/realtime";
import { getCallIce } from "../lib/call-ice";

const router: IRouter = Router();

router.post("/rooms/:roomId/call/ice", requireUser, async (req, res) => {
  res.setHeader("Cache-Control", "no-store");
  if (!(await getMembership(String(req.params.roomId), currentUser(req).id))) {
    res.status(403).json({ error: "You are not in that conversation" });
    return;
  }
  try {
    res.json(await getCallIce());
  } catch (error) {
    res.status(503).json({ error: error instanceof Error && error.message.startsWith("Call relay")
      ? error.message : "Call relay could not be reached. Please try again shortly." });
  }
});

router.get("/rooms/:roomId/call", requireUser, async (req, res) => {
  const viewer = currentUser(req);

  if (!(await getMembership(String(req.params.roomId), viewer.id))) {
    res.status(403).json({ error: "You are not in that conversation" });
    return;
  }

  res.json(await getCallState(String(req.params.roomId)));
});

router.post("/rooms/:roomId/call", requireUser, async (req, res) => {
  const viewer = currentUser(req);
  const roomId = String(req.params.roomId);

  if (!(await getMembership(roomId, viewer.id))) {
    res.status(403).json({ error: "You are not in that conversation" });
    return;
  }

  await db
    .insert(callParticipantsTable)
    .values({ roomId, userId: viewer.id })
    .onConflictDoNothing();

  const call = await getCallState(roomId);
  res.json(call);

  void broadcastToRoom(roomId, { type: "call:state", roomId, call });
});

router.delete("/rooms/:roomId/call", requireUser, async (req, res) => {
  const viewer = currentUser(req);
  const roomId = String(req.params.roomId);

  if (!(await getMembership(roomId, viewer.id))) {
    res.status(403).json({ error: "You are not in that conversation" });
    return;
  }

  await db
    .delete(callParticipantsTable)
    .where(
      and(
        eq(callParticipantsTable.roomId, roomId),
        eq(callParticipantsTable.userId, viewer.id),
      ),
    );

  const call = await getCallState(roomId);
  res.json(call);

  void broadcastToRoom(roomId, { type: "call:state", roomId, call });
});

router.get("/calls/live", requireUser, async (req, res) => {
  const viewer = currentUser(req);

  const memberships = await db
    .select({ roomId: roomMembersTable.roomId })
    .from(roomMembersTable)
    .where(eq(roomMembersTable.userId, viewer.id));

  if (memberships.length === 0) {
    res.json([]);
    return;
  }

  const roomIds = memberships.map((row) => row.roomId);

  const live = await db
    .select({ roomId: callParticipantsTable.roomId })
    .from(callParticipantsTable)
    .where(inArray(callParticipantsTable.roomId, roomIds));

  const uniqueRooms = [...new Set(live.map((row) => row.roomId))];
  res.json(await Promise.all(uniqueRooms.map((roomId) => getCallState(roomId))));
});

export default router;
