import { Router, type IRouter } from "express";
import { SendFriendRequestBody } from "@workspace/api-zod";
import {
  db,
  usersTable,
  friendshipsTable,
  roomsTable,
  type User,
} from "@workspace/db";
import { and, eq, or, sql } from "drizzle-orm";
import { currentUser, requireUser } from "../lib/auth";
import { directRoomKey, loadUsers, serializeUser } from "../lib/data";
import { sendToUser } from "../lib/realtime";

const router: IRouter = Router();

async function directRoomIdFor(a: string, b: string): Promise<string | null> {
  const [room] = await db
    .select({ id: roomsTable.id })
    .from(roomsTable)
    .where(eq(roomsTable.dmKey, directRoomKey(a, b)))
    .limit(1);
  return room?.id ?? null;
}

router.get("/friends", requireUser, async (req, res) => {
  const viewer = currentUser(req);

  const links = await db
    .select()
    .from(friendshipsTable)
    .where(
      and(
        eq(friendshipsTable.status, "accepted"),
        or(
          eq(friendshipsTable.requesterId, viewer.id),
          eq(friendshipsTable.addresseeId, viewer.id),
        ),
      ),
    );

  const users = await loadUsers(
    links.map((link) =>
      link.requesterId === viewer.id ? link.addresseeId : link.requesterId,
    ),
  );

  const friends = await Promise.all(
    links.map(async (link) => {
      const friendId =
        link.requesterId === viewer.id ? link.addresseeId : link.requesterId;
      const friend = users.get(friendId);
      if (!friend) return null;

      return {
        user: serializeUser(friend),
        friendsSince: (link.respondedAt ?? link.createdAt).toISOString(),
        directRoomId: await directRoomIdFor(viewer.id, friendId),
      };
    }),
  );

  res.json(friends.filter(Boolean));
});

router.delete("/friends/:userId", requireUser, async (req, res) => {
  const viewer = currentUser(req);
  const friendId = String(req.params.userId);

  const deleted = await db
    .delete(friendshipsTable)
    .where(
      and(
        eq(friendshipsTable.status, "accepted"),
        sql`((${friendshipsTable.requesterId} = ${viewer.id} AND ${friendshipsTable.addresseeId} = ${friendId}) OR (${friendshipsTable.requesterId} = ${friendId} AND ${friendshipsTable.addresseeId} = ${viewer.id}))`,
      ),
    )
    .returning();

  if (deleted.length === 0) {
    res.status(404).json({ error: "You are not friends with that person" });
    return;
  }

  res.json({ ok: true });
});

function serializeRequest(
  row: typeof friendshipsTable.$inferSelect,
  direction: "incoming" | "outgoing",
  user: User,
) {
  return {
    id: row.id,
    direction,
    user: serializeUser(user),
    note: row.note,
    createdAt: row.createdAt.toISOString(),
  };
}

router.get("/friend-requests", requireUser, async (req, res) => {
  const viewer = currentUser(req);

  const rows = await db
    .select()
    .from(friendshipsTable)
    .where(
      and(
        eq(friendshipsTable.status, "pending"),
        or(
          eq(friendshipsTable.requesterId, viewer.id),
          eq(friendshipsTable.addresseeId, viewer.id),
        ),
      ),
    );

  const users = await loadUsers([
    ...rows.map((row) => row.requesterId),
    ...rows.map((row) => row.addresseeId),
  ]);

  const incoming = rows
    .filter((row) => row.addresseeId === viewer.id)
    .map((row) => {
      const user = users.get(row.requesterId);
      return user ? serializeRequest(row, "incoming", user) : null;
    })
    .filter(Boolean);

  const outgoing = rows
    .filter((row) => row.requesterId === viewer.id)
    .map((row) => {
      const user = users.get(row.addresseeId);
      return user ? serializeRequest(row, "outgoing", user) : null;
    })
    .filter(Boolean);

  res.json({ incoming, outgoing });
});

router.post("/friend-requests", requireUser, async (req, res) => {
  const viewer = currentUser(req);
  const parsed = SendFriendRequestBody.safeParse(req.body);

  if (!parsed.success) {
    res.status(400).json({ error: "Enter the username you want to add" });
    return;
  }

  const username = parsed.data.username.trim().replace(/^@/, "").toLowerCase();

  const [target] = await db
    .select()
    .from(usersTable)
    .where(eq(usersTable.username, username))
    .limit(1);

  if (!target) {
    res.status(404).json({ error: `Nobody here goes by @${username}` });
    return;
  }

  if (target.id === viewer.id) {
    res.status(400).json({ error: "You are already your own best friend" });
    return;
  }

  const [existing] = await db
    .select()
    .from(friendshipsTable)
    .where(
      sql`((${friendshipsTable.requesterId} = ${viewer.id} AND ${friendshipsTable.addresseeId} = ${target.id}) OR (${friendshipsTable.requesterId} = ${target.id} AND ${friendshipsTable.addresseeId} = ${viewer.id}))`,
    )
    .limit(1);

  if (existing) {
    res.status(409).json({
      error:
        existing.status === "accepted"
          ? "You are already friends"
          : "There is already a pending request between you two",
    });
    return;
  }

  const [created] = await db
    .insert(friendshipsTable)
    .values({
      requesterId: viewer.id,
      addresseeId: target.id,
      note: parsed.data.note ?? null,
    })
    .returning();

  if (!created) {
    res.status(500).json({ error: "Could not send that request" });
    return;
  }

  sendToUser(target.id, { type: "friend:request", requestId: created.id });

  res.status(201).json(serializeRequest(created, "outgoing", target));
});

router.post(
  "/friend-requests/:requestId/accept",
  requireUser,
  async (req, res) => {
    const viewer = currentUser(req);

    const [request] = await db
      .select()
      .from(friendshipsTable)
      .where(
        and(
          eq(friendshipsTable.id, String(req.params.requestId)),
          eq(friendshipsTable.addresseeId, viewer.id),
          eq(friendshipsTable.status, "pending"),
        ),
      )
      .limit(1);

    if (!request) {
      res.status(404).json({ error: "That request is no longer waiting" });
      return;
    }

    const [updated] = await db
      .update(friendshipsTable)
      .set({ status: "accepted", respondedAt: new Date() })
      .where(eq(friendshipsTable.id, request.id))
      .returning();

    const [friend] = await db
      .select()
      .from(usersTable)
      .where(eq(usersTable.id, request.requesterId))
      .limit(1);

    if (!updated || !friend) {
      res.status(500).json({ error: "Could not accept that request" });
      return;
    }

    sendToUser(friend.id, { type: "friend:accepted", userId: viewer.id });

    res.json({
      user: serializeUser(friend),
      friendsSince: (updated.respondedAt ?? updated.createdAt).toISOString(),
      directRoomId: await directRoomIdFor(viewer.id, friend.id),
    });
  },
);

router.post(
  "/friend-requests/:requestId/decline",
  requireUser,
  async (req, res) => {
    const viewer = currentUser(req);

    const deleted = await db
      .delete(friendshipsTable)
      .where(
        and(
          eq(friendshipsTable.id, String(req.params.requestId)),
          eq(friendshipsTable.status, "pending"),
          or(
            eq(friendshipsTable.addresseeId, viewer.id),
            eq(friendshipsTable.requesterId, viewer.id),
          ),
        ),
      )
      .returning();

    if (deleted.length === 0) {
      res.status(404).json({ error: "That request is no longer waiting" });
      return;
    }

    const other =
      deleted[0]!.requesterId === viewer.id
        ? deleted[0]!.addresseeId
        : deleted[0]!.requesterId;
    sendToUser(other, { type: "friend:request", requestId: deleted[0]!.id });

    res.json({ ok: true });
  },
);

export default router;
