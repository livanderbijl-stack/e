import { Router, type IRouter } from "express";
import healthRouter from "./health";
import meRouter from "./me";
import friendsRouter from "./friends";
import roomsRouter from "./rooms";
import messagesRouter from "./messages";
import callsRouter from "./calls";
import overviewRouter from "./overview";
import storageRouter from "./storage";

const router: IRouter = Router();

router.use(healthRouter);
router.use(meRouter);
router.use(friendsRouter);
router.use(roomsRouter);
router.use(messagesRouter);
router.use(callsRouter);
router.use(overviewRouter);
router.use(storageRouter);

export default router;
