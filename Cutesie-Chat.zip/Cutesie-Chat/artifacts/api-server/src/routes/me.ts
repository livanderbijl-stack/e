import { Router, type IRouter } from "express";
import { UpdateMeBody } from "@workspace/api-zod";
import {
  db,
  usersTable,
  friendshipsTable,
  uploadsTable,
} from "@workspace/db";
import { and, eq, ne, or, sql } from "drizzle-orm";
import { currentUser, requireUser } from "../lib/auth";
import { serializeUser } from "../lib/data";

const router: IRouter = Router();

const ACCENTS = new Set([
  "blush",
  "lilac",
  "mint",
  "butter",
  "sky",
  "peach",
]);

function serializeCurrentUser(user: typeof usersTable.$inferSelect) {
  return {
    ...serializeUser(user),
    createdAt: user.createdAt.toISOString(),
  };
}

router.get("/me", requireUser, async (req, res) => {
  const user = currentUser(req);
  await db
    .update(usersTable)
    .set({ lastSeenAt: new Date() })
    .where(eq(usersTable.id, user.id));
  res.json(serializeCurrentUser(user));
});

router.patch("/me", requireUser, async (req, res) => {
  const user = currentUser(req);
  const parsed = UpdateMeBody.safeParse(req.body);

  if (!parsed.success) {
    res.status(400).json({ error: "Those profile details do not look right" });
    return;
  }

  const { username, displayName, bio, avatarObjectPath, accentColor } =
    parsed.data;

  if (username) {
    const normalized = username.toLowerCase().replace(/[^a-z0-9_]/g, "");
    if (normalized.length < 2) {
      res.status(400).json({
        error: "Usernames need at least two letters, numbers or underscores",
      });
      return;
    }

    const [taken] = await db
      .select({ id: usersTable.id })
      .from(usersTable)
      .where(
        and(eq(usersTable.username, normalized), ne(usersTable.id, user.id)),
      )
      .limit(1);

    if (taken) {
      res.status(409).json({ error: "That username is already taken" });
      return;
    }
  }

  if (accentColor && !ACCENTS.has(accentColor)) {
    res.status(400).json({ error: "Unknown colour" });
    return;
  }

  if (avatarObjectPath) {
    const [upload] = await db
      .select({ id: uploadsTable.id })
      .from(uploadsTable)
      .where(
        and(
          eq(uploadsTable.objectPath, avatarObjectPath),
          eq(uploadsTable.uploaderId, user.id),
        ),
      )
      .limit(1);

    if (!upload) {
      res.status(403).json({ error: "That picture is not yours to use" });
      return;
    }
  }

  const [updated] = await db
    .update(usersTable)
    .set({
      ...(username
        ? { username: username.toLowerCase().replace(/[^a-z0-9_]/g, "") }
        : {}),
      ...(displayName ? { displayName } : {}),
      ...(bio !== undefined ? { bio } : {}),
      ...(avatarObjectPath ? { avatarPath: avatarObjectPath } : {}),
      ...(accentColor ? { accentColor } : {}),
    })
    .where(eq(usersTable.id, user.id))
    .returning();

  if (!updated) {
    res.status(404).json({ error: "Profile not found" });
    return;
  }

  res.json(serializeCurrentUser(updated));
});

router.get("/users/search", requireUser, async (req, res) => {
  const viewer = currentUser(req);
  const raw = req.query.q;
  const q = (Array.isArray(raw) ? raw[0] : raw)?.toString().trim() ?? "";

  if (q.length === 0) {
    res.json([]);
    return;
  }

  const term = `%${q.replace(/[%_]/g, "")}%`;

  const rows = await db
    .select()
    .from(usersTable)
    .where(
      or(
        sql`${usersTable.username} ILIKE ${term}`,
        sql`${usersTable.displayName} ILIKE ${term}`,
      ),
    )
    .limit(20);

  const links = await db
    .select()
    .from(friendshipsTable)
    .where(
      or(
        eq(friendshipsTable.requesterId, viewer.id),
        eq(friendshipsTable.addresseeId, viewer.id),
      ),
    );

  const result = rows.map((row) => {
    if (row.id === viewer.id) {
      return {
        user: serializeUser(row),
        relationship: "self",
        requestId: null,
      };
    }

    const link = links.find(
      (candidate) =>
        candidate.requesterId === row.id || candidate.addresseeId === row.id,
    );

    let relationship = "none";
    if (link) {
      if (link.status === "accepted") relationship = "friends";
      else if (link.requesterId === viewer.id) relationship = "request_sent";
      else relationship = "request_received";
    }

    return {
      user: serializeUser(row),
      relationship,
      requestId: link?.id ?? null,
    };
  });

  res.json(result);
});

export default router;
