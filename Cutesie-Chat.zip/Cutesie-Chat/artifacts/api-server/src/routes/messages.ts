import { Router, type IRouter } from "express";
import { SendMessageBody, ReactToMessageBody } from "@workspace/api-zod";
import {
  db,
  messagesTable,
  attachmentsTable,
  reactionsTable,
  roomMembersTable,
  uploadsTable,
} from "@workspace/db";
import { and, eq, inArray } from "drizzle-orm";
import { currentUser, requireUser } from "../lib/auth";
import {
  getMembership,
  messagesPage,
  serializeMessageById,
  serializeMessages,
  touchRoom,
} from "../lib/data";
import { extractUrls, storePreviews } from "../lib/linkPreview";
import { broadcastToRoom, sendToUser } from "../lib/realtime";
import { attachmentKindFor } from "../lib/serving";
import { logger } from "../lib/logger";

const router: IRouter = Router();

router.get("/messages", requireUser, async (req, res) => {
  const viewer = currentUser(req);
  const roomIdRaw = req.query.roomId;
  const roomId = (Array.isArray(roomIdRaw) ? roomIdRaw[0] : roomIdRaw)?.toString();

  if (!roomId) {
    res.status(400).json({ error: "Which conversation?" });
    return;
  }

  if (!(await getMembership(roomId, viewer.id))) {
    res.status(403).json({ error: "You are not in that conversation" });
    return;
  }

  const beforeRaw = req.query.before;
  const before = (Array.isArray(beforeRaw) ? beforeRaw[0] : beforeRaw)
    ?.toString()
    .trim();

  const limitRaw = req.query.limit;
  const parsedLimit = Number(
    (Array.isArray(limitRaw) ? limitRaw[0] : limitRaw) ?? 50,
  );
  const limit = Number.isFinite(parsedLimit)
    ? Math.min(Math.max(Math.trunc(parsedLimit), 1), 100)
    : 50;

  const rows = await messagesPage(roomId, before || undefined, limit);
  res.json(await serializeMessages(rows, viewer.id));
});

router.post("/rooms/:roomId/messages", requireUser, async (req, res) => {
  const viewer = currentUser(req);
  const roomId = String(req.params.roomId);
  const parsed = SendMessageBody.safeParse(req.body);

  if (!parsed.success) {
    res.status(400).json({ error: "That message could not be sent" });
    return;
  }

  if (!(await getMembership(roomId, viewer.id))) {
    res.status(403).json({ error: "You are not in that conversation" });
    return;
  }

  const body = parsed.data.body?.trim() ?? "";
  const attachments = parsed.data.attachments ?? [];

  if (body.length === 0 && attachments.length === 0) {
    res.status(400).json({ error: "Write something or add a file first" });
    return;
  }

  // A reply must point at a message in this same room, otherwise the preview
  // would leak a snippet of a conversation the room cannot see.
  if (parsed.data.replyToId) {
    const [target] = await db
      .select({ roomId: messagesTable.roomId })
      .from(messagesTable)
      .where(eq(messagesTable.id, parsed.data.replyToId))
      .limit(1);

    if (!target || target.roomId !== roomId) {
      res.status(400).json({ error: "You can only reply to messages here" });
      return;
    }
  }

  if (attachments.length > 0) {
    const owned = await db
      .select({ objectPath: uploadsTable.objectPath })
      .from(uploadsTable)
      .where(
        and(
          eq(uploadsTable.uploaderId, viewer.id),
          inArray(
            uploadsTable.objectPath,
            attachments.map((attachment) => attachment.objectPath),
          ),
        ),
      );

    const ownedPaths = new Set(owned.map((row) => row.objectPath));
    if (attachments.some((a) => !ownedPaths.has(a.objectPath))) {
      res.status(403).json({ error: "Those files are not yours to share" });
      return;
    }
  }

  const [message] = await db
    .insert(messagesTable)
    .values({
      roomId,
      authorId: viewer.id,
      body: body.length > 0 ? body : null,
      kind: attachments.length > 0 ? "media" : "text",
      replyToId: parsed.data.replyToId ?? null,
    })
    .returning();

  if (!message) {
    res.status(500).json({ error: "That message could not be sent" });
    return;
  }

  if (attachments.length > 0) {
    await db.insert(attachmentsTable).values(
      attachments.map((attachment) => ({
        messageId: message.id,
        objectPath: attachment.objectPath,
        fileName: attachment.fileName,
        contentType: attachment.contentType,
        size: attachment.size,
        kind: attachmentKindFor(attachment.contentType),
      })),
    );
  }

  await Promise.all([
    touchRoom(roomId),
    db
      .update(roomMembersTable)
      .set({ lastReadAt: new Date() })
      .where(
        and(
          eq(roomMembersTable.roomId, roomId),
          eq(roomMembersTable.userId, viewer.id),
        ),
      ),
  ]);

  const serialized = await serializeMessageById(message.id, viewer.id);
  res.status(201).json(serialized);

  void broadcastToRoom(roomId, {
    type: "message:new",
    roomId,
    message: serialized,
  });

  // Link cards are fetched after the message lands so the sender never waits
  // on a slow third-party site.
  const urls = extractUrls(body);
  if (urls.length > 0) {
    void storePreviews(message.id, urls)
      .then(async (stored) => {
        if (!stored) return;
        const updated = await serializeMessageById(message.id, viewer.id);
        await broadcastToRoom(roomId, {
          type: "message:updated",
          roomId,
          message: updated,
        });
      })
      .catch((error: unknown) => {
        logger.debug({ err: error }, "Link preview enrichment failed");
      });
  }
});

router.delete("/messages/:messageId", requireUser, async (req, res) => {
  const viewer = currentUser(req);

  const [message] = await db
    .select()
    .from(messagesTable)
    .where(eq(messagesTable.id, String(req.params.messageId)))
    .limit(1);

  if (!message) {
    res.status(404).json({ error: "That message is already gone" });
    return;
  }

  if (message.authorId !== viewer.id) {
    res.status(403).json({ error: "You can only delete your own messages" });
    return;
  }

  if (!(await getMembership(message.roomId, viewer.id))) {
    res.status(403).json({ error: "You are not in that conversation" });
    return;
  }

  await db.delete(messagesTable).where(eq(messagesTable.id, message.id));

  res.json({ ok: true });

  void broadcastToRoom(message.roomId, {
    type: "message:deleted",
    roomId: message.roomId,
    messageId: message.id,
  });
});

router.post("/messages/:messageId/reactions", requireUser, async (req, res) => {
  const viewer = currentUser(req);
  const parsed = ReactToMessageBody.safeParse(req.body);

  if (!parsed.success) {
    res.status(400).json({ error: "That reaction is not allowed" });
    return;
  }

  const [message] = await db
    .select()
    .from(messagesTable)
    .where(eq(messagesTable.id, String(req.params.messageId)))
    .limit(1);

  if (!message) {
    res.status(404).json({ error: "That message is gone" });
    return;
  }

  if (!(await getMembership(message.roomId, viewer.id))) {
    res.status(403).json({ error: "You are not in that conversation" });
    return;
  }

  const emoji = parsed.data.emoji;

  const existing = await db
    .select()
    .from(reactionsTable)
    .where(
      and(
        eq(reactionsTable.messageId, message.id),
        eq(reactionsTable.userId, viewer.id),
        eq(reactionsTable.emoji, emoji),
      ),
    )
    .limit(1);

  if (existing.length > 0) {
    await db.delete(reactionsTable).where(eq(reactionsTable.id, existing[0]!.id));
  } else {
    await db
      .insert(reactionsTable)
      .values({ messageId: message.id, userId: viewer.id, emoji })
      .onConflictDoNothing();
  }

  const serialized = await serializeMessageById(message.id, viewer.id);
  res.json(serialized);

  // `reactedByMe` differs per person, so each member gets their own view.
  const members = await db
    .select({ userId: roomMembersTable.userId })
    .from(roomMembersTable)
    .where(eq(roomMembersTable.roomId, message.roomId));

  for (const member of members) {
    if (member.userId === viewer.id) continue;
    const forMember = await serializeMessageById(message.id, member.userId);
    sendToUser(member.userId, {
      type: "message:updated",
      roomId: message.roomId,
      message: forMember,
    });
  }
});

export default router;
