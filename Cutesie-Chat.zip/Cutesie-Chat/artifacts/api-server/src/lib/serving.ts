/**
 * Object storage paths are stored in the database as `/objects/<key>`.
 * Browsers need the route that streams them, which lives under the API prefix.
 */
export function toServingUrl(objectPath: string | null): string | null {
  if (!objectPath) return null;
  if (/^https?:\/\//i.test(objectPath)) return objectPath;
  if (objectPath.startsWith("/objects/")) {
    return `/api/storage${objectPath.replace("/objects/", "/objects/")}`;
  }
  return objectPath;
}

export function attachmentKindFor(contentType: string): string {
  if (contentType.startsWith("image/")) return "image";
  if (contentType.startsWith("video/")) return "video";
  if (contentType.startsWith("audio/")) return "audio";
  return "file";
}
