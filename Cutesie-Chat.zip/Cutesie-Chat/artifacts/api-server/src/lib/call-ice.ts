import type { CallIce } from "@workspace/api-zod";

// Credentials stay on the server. Only short-lived TURN credentials leave it.
let cached: { config: CallIce; expires: number } | undefined;
let pending: Promise<CallIce> | undefined;

export function getCallIce(): Promise<CallIce> {
  if (cached && cached.expires > Date.now()) return Promise.resolve(cached.config);
  if (pending) return pending;
  pending = issueIce().finally(() => { pending = undefined; });
  return pending;
}

async function issueIce(): Promise<CallIce> {
  const sid = process.env.TWILIO_ACCOUNT_SID;
  const token = process.env.TWILIO_AUTH_TOKEN;
  if (!sid || !token) throw new Error("Call relay is not configured. The app owner must configure Twilio.");
  const response = await fetch(`https://api.twilio.com/2010-04-01/Accounts/${encodeURIComponent(sid)}/Tokens.json`, {
    method: "POST",
    headers: {
      Authorization: `Basic ${Buffer.from(`${sid}:${token}`).toString("base64")}`,
      "Content-Type": "application/x-www-form-urlencoded",
    },
    body: "Ttl=86400",
    signal: AbortSignal.timeout(10000),
  });
  if (!response.ok) {
    // Do not log provider payloads, which may contain sensitive account details.
    if (response.status === 401 || response.status === 403) {
      throw new Error("Call relay authentication failed. The app owner must correct the Twilio Account SID and Auth Token. Your camera settings are not the problem.");
    }
    throw new Error("Call relay provider is unavailable. Please try again shortly.");
  }
  const data = await response.json() as { ice_servers?: { urls?: string; username?: string; credential?: string }[] };
  const iceServers = data.ice_servers?.filter((s) => typeof s.urls === "string")
    .map((s) => ({ urls: s.urls!, ...(s.username ? { username: s.username } : {}), ...(s.credential ? { credential: s.credential } : {}) }));
  if (!iceServers?.some(s => /^turns?:/.test(s.urls) && s.username && s.credential)) {
    throw new Error("Call relay provider returned no usable relay servers.");
  }
  const config = { iceServers };
  // Reuse across short bursts, while leaving almost the full 24h for a call.
  cached = { config, expires: Date.now() + 60000 };
  return config;
}