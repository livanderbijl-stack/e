import type { NextFunction, Request, RequestHandler, Response } from "express";
import { getAuth, clerkClient } from "@clerk/express";
import { db, usersTable, type User } from "@workspace/db";
import { eq } from "drizzle-orm";

declare global {
  // eslint-disable-next-line @typescript-eslint/no-namespace
  namespace Express {
    interface Request {
      currentUser?: User;
    }
  }
}

function slugify(value: string): string {
  return value
    .toLowerCase()
    .replace(/[^a-z0-9_]+/g, "")
    .slice(0, 20);
}

async function pickUsername(candidates: string[]): Promise<string> {
  const cleaned = candidates.map(slugify).filter((value) => value.length >= 2);
  const bases = cleaned.length > 0 ? cleaned : ["friend"];

  for (const base of bases) {
    const [taken] = await db
      .select({ id: usersTable.id })
      .from(usersTable)
      .where(eq(usersTable.username, base))
      .limit(1);
    if (!taken) return base;
  }

  const base = bases[0] ?? "friend";
  for (let attempt = 0; attempt < 50; attempt += 1) {
    const candidate = `${base}${Math.floor(Math.random() * 10000)}`;
    const [taken] = await db
      .select({ id: usersTable.id })
      .from(usersTable)
      .where(eq(usersTable.username, candidate))
      .limit(1);
    if (!taken) return candidate;
  }

  return `${base}${Date.now()}`;
}

const ACCENTS = ["blush", "lilac", "mint", "butter", "sky", "peach"] as const;

/**
 * Returns the local profile row for a Clerk user, creating it on first sight.
 */
export async function resolveLocalUser(clerkUserId: string): Promise<User> {
  const [existing] = await db
    .select()
    .from(usersTable)
    .where(eq(usersTable.clerkUserId, clerkUserId))
    .limit(1);

  if (existing) return existing;

  let username = "";
  let displayName = "";
  let avatarPath: string | null = null;

  try {
    const clerkUser = await clerkClient.users.getUser(clerkUserId);
    const email = clerkUser.emailAddresses[0]?.emailAddress ?? "";
    username = await pickUsername([
      clerkUser.username ?? "",
      email.split("@")[0] ?? "",
      clerkUser.firstName ?? "",
    ]);
    displayName =
      [clerkUser.firstName, clerkUser.lastName].filter(Boolean).join(" ") ||
      clerkUser.username ||
      username;
    avatarPath = clerkUser.imageUrl || null;
  } catch {
    username = await pickUsername([]);
    displayName = username;
  }

  const accentColor = ACCENTS[Math.floor(Math.random() * ACCENTS.length)]!;

  const [created] = await db
    .insert(usersTable)
    .values({ clerkUserId, username, displayName, avatarPath, accentColor })
    .onConflictDoNothing({ target: usersTable.clerkUserId })
    .returning();

  if (created) return created;

  const [row] = await db
    .select()
    .from(usersTable)
    .where(eq(usersTable.clerkUserId, clerkUserId))
    .limit(1);

  if (!row) throw new Error("Failed to create local user profile");
  return row;
}

/**
 * Rejects unauthenticated calls and attaches the local profile to the request.
 */
export const requireUser: RequestHandler = async (
  req: Request,
  res: Response,
  next: NextFunction,
) => {
  const auth = getAuth(req);

  if (!auth.userId) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }

  try {
    req.currentUser = await resolveLocalUser(auth.userId);
    next();
  } catch (error) {
    req.log.error({ err: error }, "Failed to resolve local user");
    res.status(500).json({ error: "Failed to load your profile" });
  }
};

export function currentUser(req: Request): User {
  if (!req.currentUser) {
    throw new Error("currentUser called without requireUser middleware");
  }
  return req.currentUser;
}
