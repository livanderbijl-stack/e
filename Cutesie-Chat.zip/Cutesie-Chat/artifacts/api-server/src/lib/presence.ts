/**
 * Tracks which users currently have at least one live realtime connection.
 * Kept in its own module so both the websocket hub (which writes) and the
 * data layer (which reads) can use it without importing each other.
 */
const connectionCounts = new Map<string, number>();

export function addPresence(userId: string): boolean {
  const next = (connectionCounts.get(userId) ?? 0) + 1;
  connectionCounts.set(userId, next);
  return next === 1;
}

export function removePresence(userId: string): boolean {
  const next = (connectionCounts.get(userId) ?? 1) - 1;
  if (next <= 0) {
    connectionCounts.delete(userId);
    return true;
  }
  connectionCounts.set(userId, next);
  return false;
}

export function isOnline(userId: string): boolean {
  return connectionCounts.has(userId);
}

export function onlineUserIds(): string[] {
  return [...connectionCounts.keys()];
}
