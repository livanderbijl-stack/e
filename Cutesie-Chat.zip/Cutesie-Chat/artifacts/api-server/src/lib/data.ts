import {
  db,
  usersTable,
  roomsTable,
  roomMembersTable,
  messagesTable,
  attachmentsTable,
  linkPreviewsTable,
  reactionsTable,
  callParticipantsTable,
  friendshipsTable,
  type User,
} from "@workspace/db";
import { and, asc, desc, eq, inArray, lt, sql } from "drizzle-orm";
import { isOnline } from "./presence";
import { attachmentKindFor, toServingUrl } from "./serving";

export type UserSummary = {
  id: string;
  username: string;
  displayName: string;
  avatarUrl: string | null;
  accentColor: string;
  bio: string | null;
  isOnline: boolean;
  lastSeenAt: string | null;
};

export function serializeUser(user: User): UserSummary {
  return {
    id: user.id,
    username: user.username,
    displayName: user.displayName,
    avatarUrl: toServingUrl(user.avatarPath),
    accentColor: user.accentColor,
    bio: user.bio,
    isOnline: isOnline(user.id),
    lastSeenAt: user.lastSeenAt ? user.lastSeenAt.toISOString() : null,
  };
}

export async function loadUsers(ids: string[]): Promise<Map<string, User>> {
  const unique = [...new Set(ids)].filter(Boolean);
  if (unique.length === 0) return new Map();
  const rows = await db
    .select()
    .from(usersTable)
    .where(inArray(usersTable.id, unique));
  return new Map(rows.map((row) => [row.id, row]));
}

export async function getMembership(roomId: string, userId: string) {
  const [row] = await db
    .select()
    .from(roomMembersTable)
    .where(
      and(
        eq(roomMembersTable.roomId, roomId),
        eq(roomMembersTable.userId, userId),
      ),
    )
    .limit(1);
  return row ?? null;
}

export async function getRoomMemberIds(roomId: string): Promise<string[]> {
  const rows = await db
    .select({ userId: roomMembersTable.userId })
    .from(roomMembersTable)
    .where(eq(roomMembersTable.roomId, roomId));
  return rows.map((row) => row.userId);
}

export async function areFriends(a: string, b: string): Promise<boolean> {
  const rows = await db
    .select({ id: friendshipsTable.id })
    .from(friendshipsTable)
    .where(
      and(
        eq(friendshipsTable.status, "accepted"),
        sql`((${friendshipsTable.requesterId} = ${a} AND ${friendshipsTable.addresseeId} = ${b}) OR (${friendshipsTable.requesterId} = ${b} AND ${friendshipsTable.addresseeId} = ${a}))`,
      ),
    )
    .limit(1);
  return rows.length > 0;
}

export async function friendIdsOf(userId: string): Promise<string[]> {
  const rows = await db
    .select({
      requesterId: friendshipsTable.requesterId,
      addresseeId: friendshipsTable.addresseeId,
    })
    .from(friendshipsTable)
    .where(
      and(
        eq(friendshipsTable.status, "accepted"),
        sql`(${friendshipsTable.requesterId} = ${userId} OR ${friendshipsTable.addresseeId} = ${userId})`,
      ),
    );
  return rows.map((row) =>
    row.requesterId === userId ? row.addresseeId : row.requesterId,
  );
}

/* -------------------------------------------------------------------------- */
/* Messages                                                                    */
/* -------------------------------------------------------------------------- */

export function previewTextFor(
  body: string | null,
  attachmentKinds: string[],
): string {
  if (body && body.trim().length > 0) return body.trim().slice(0, 140);
  if (attachmentKinds.includes("video")) return "Shared a video";
  if (attachmentKinds.includes("image")) return "Shared a photo";
  if (attachmentKinds.includes("audio")) return "Shared an audio clip";
  if (attachmentKinds.length > 0) return "Shared a file";
  return "Said hello";
}

type MessageRow = typeof messagesTable.$inferSelect;

export async function serializeMessages(
  rows: MessageRow[],
  viewerId: string,
): Promise<unknown[]> {
  if (rows.length === 0) return [];

  const messageIds = rows.map((row) => row.id);
  const replyIds = rows
    .map((row) => row.replyToId)
    .filter((value): value is string => Boolean(value));

  const [attachments, links, reactions, replies] = await Promise.all([
    db
      .select()
      .from(attachmentsTable)
      .where(inArray(attachmentsTable.messageId, messageIds)),
    db
      .select()
      .from(linkPreviewsTable)
      .where(inArray(linkPreviewsTable.messageId, messageIds)),
    db
      .select()
      .from(reactionsTable)
      .where(inArray(reactionsTable.messageId, messageIds)),
    replyIds.length > 0
      ? db
          .select()
          .from(messagesTable)
          .where(inArray(messagesTable.id, [...new Set(replyIds)]))
      : Promise.resolve([] as MessageRow[]),
  ]);

  const users = await loadUsers([
    ...rows.map((row) => row.authorId),
    ...replies.map((row) => row.authorId),
  ]);

  const replyById = new Map(replies.map((row) => [row.id, row]));

  return rows.map((row) => {
    const rowAttachments = attachments.filter((a) => a.messageId === row.id);
    const rowLinks = links.filter((l) => l.messageId === row.id);
    const rowReactions = reactions.filter((r) => r.messageId === row.id);

    const grouped = new Map<string, { userIds: string[] }>();
    for (const reaction of rowReactions) {
      const entry = grouped.get(reaction.emoji) ?? { userIds: [] };
      entry.userIds.push(reaction.userId);
      grouped.set(reaction.emoji, entry);
    }

    const author = users.get(row.authorId);
    const reply = row.replyToId ? replyById.get(row.replyToId) : undefined;
    const replyAuthor = reply ? users.get(reply.authorId) : undefined;

    return {
      id: row.id,
      roomId: row.roomId,
      author: author
        ? serializeUser(author)
        : {
            id: row.authorId,
            username: "unknown",
            displayName: "Someone",
            avatarUrl: null,
            accentColor: "lilac",
            bio: null,
            isOnline: false,
            lastSeenAt: null,
          },
      body: row.body,
      kind: row.kind,
      attachments: rowAttachments.map((attachment) => ({
        id: attachment.id,
        kind: attachment.kind,
        url: toServingUrl(attachment.objectPath) ?? attachment.objectPath,
        fileName: attachment.fileName,
        contentType: attachment.contentType,
        size: attachment.size,
      })),
      links: rowLinks.map((link) => ({
        url: link.url,
        title: link.title,
        description: link.description,
        imageUrl: link.imageUrl,
        siteName: link.siteName,
      })),
      reactions: [...grouped.entries()].map(([emoji, entry]) => ({
        emoji,
        count: entry.userIds.length,
        reactedByMe: entry.userIds.includes(viewerId),
        userIds: entry.userIds,
      })),
      replyTo: reply
        ? {
            id: reply.id,
            preview: previewTextFor(reply.body, []),
            authorName: replyAuthor?.displayName ?? null,
            createdAt: reply.createdAt.toISOString(),
          }
        : undefined,
      createdAt: row.createdAt.toISOString(),
    };
  });
}

export async function serializeMessageById(
  messageId: string,
  viewerId: string,
): Promise<unknown | null> {
  const [row] = await db
    .select()
    .from(messagesTable)
    .where(eq(messagesTable.id, messageId))
    .limit(1);
  if (!row) return null;
  const [serialized] = await serializeMessages([row], viewerId);
  return serialized ?? null;
}

/* -------------------------------------------------------------------------- */
/* Rooms                                                                       */
/* -------------------------------------------------------------------------- */

export function directRoomKey(a: string, b: string): string {
  return [a, b].sort().join(":");
}

async function lastMessageFor(roomId: string) {
  const [row] = await db
    .select()
    .from(messagesTable)
    .where(eq(messagesTable.roomId, roomId))
    .orderBy(desc(messagesTable.createdAt))
    .limit(1);
  if (!row) return null;

  const kinds = await db
    .select({ kind: attachmentsTable.kind })
    .from(attachmentsTable)
    .where(eq(attachmentsTable.messageId, row.id));

  const [author] = await db
    .select()
    .from(usersTable)
    .where(eq(usersTable.id, row.authorId))
    .limit(1);

  return {
    id: row.id,
    preview: previewTextFor(
      row.body,
      kinds.map((k) => k.kind),
    ),
    authorName: author?.displayName ?? null,
    createdAt: row.createdAt.toISOString(),
  };
}

async function unreadCountFor(
  roomId: string,
  userId: string,
  lastReadAt: Date,
): Promise<number> {
  const [row] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(messagesTable)
    .where(
      and(
        eq(messagesTable.roomId, roomId),
        sql`${messagesTable.createdAt} > ${lastReadAt.toISOString()}`,
        sql`${messagesTable.authorId} <> ${userId}`,
      ),
    );
  return row?.count ?? 0;
}

export async function callParticipantsFor(roomId: string) {
  const rows = await db
    .select()
    .from(callParticipantsTable)
    .where(eq(callParticipantsTable.roomId, roomId))
    .orderBy(asc(callParticipantsTable.joinedAt));
  const users = await loadUsers(rows.map((row) => row.userId));
  return rows.map((row) => ({
    user: users.get(row.userId),
    joinedAt: row.joinedAt,
  }));
}

export async function getCallState(roomId: string) {
  const [room] = await db
    .select()
    .from(roomsTable)
    .where(eq(roomsTable.id, roomId))
    .limit(1);

  const participants = await callParticipantsFor(roomId);
  const present = participants.filter((entry) => entry.user);

  return {
    roomId,
    roomName: room?.name ?? "Chat",
    active: present.length > 0,
    startedAt: present[0]?.joinedAt.toISOString() ?? null,
    participants: present.map((entry) => ({
      user: serializeUser(entry.user!),
      joinedAt: entry.joinedAt.toISOString(),
    })),
  };
}

type RoomRow = typeof roomsTable.$inferSelect;

function roomDisplayName(room: RoomRow, otherUser?: User): string {
  if (room.kind === "direct") return otherUser?.displayName ?? "Private chat";
  return room.name ?? "Untitled fort";
}

export async function serializeRoomSummary(
  room: RoomRow,
  viewerId: string,
  lastReadAt: Date,
) {
  const memberRows = await db
    .select()
    .from(roomMembersTable)
    .where(eq(roomMembersTable.roomId, room.id));
  const users = await loadUsers(memberRows.map((row) => row.userId));
  const otherUser =
    room.kind === "direct"
      ? users.get(
          memberRows.find((row) => row.userId !== viewerId)?.userId ?? "",
        )
      : undefined;

  const [lastMessage, unreadCount, call] = await Promise.all([
    lastMessageFor(room.id),
    unreadCountFor(room.id, viewerId, lastReadAt),
    getCallState(room.id),
  ]);

  return {
    id: room.id,
    kind: room.kind,
    name: roomDisplayName(room, otherUser),
    description: room.description,
    colorKey: room.colorKey,
    pictureUrl: room.kind === "group" ? toServingUrl(room.picturePath) : null,
    memberCount: memberRows.length,
    unreadCount,
    callActive: call.active,
    lastMessage: lastMessage ?? undefined,
    otherUser: otherUser ? serializeUser(otherUser) : undefined,
    members: memberRows
      .map((row) => users.get(row.userId))
      .filter((user): user is User => Boolean(user))
      .map(serializeUser),
    updatedAt: room.updatedAt.toISOString(),
  };
}

export async function serializeRoomDetail(room: RoomRow, viewerId: string) {
  const memberRows = await db
    .select()
    .from(roomMembersTable)
    .where(eq(roomMembersTable.roomId, room.id))
    .orderBy(asc(roomMembersTable.joinedAt));
  const users = await loadUsers(memberRows.map((row) => row.userId));
  const viewerMembership = memberRows.find((row) => row.userId === viewerId);
  const otherUser =
    room.kind === "direct"
      ? users.get(
          memberRows.find((row) => row.userId !== viewerId)?.userId ?? "",
        )
      : undefined;

  const [call, unreadCount] = await Promise.all([
    getCallState(room.id),
    viewerMembership
      ? unreadCountFor(room.id, viewerId, viewerMembership.lastReadAt)
      : Promise.resolve(0),
  ]);

  return {
    id: room.id,
    kind: room.kind,
    name: roomDisplayName(room, otherUser),
    description: room.description,
    colorKey: room.colorKey,
    pictureUrl: room.kind === "group" ? toServingUrl(room.picturePath) : null,
    ownerId: room.ownerId,
    members: memberRows
      .filter((row) => users.has(row.userId))
      .map((row) => ({
        user: serializeUser(users.get(row.userId)!),
        role: row.role,
        joinedAt: row.joinedAt.toISOString(),
      })),
    otherUser: otherUser ? serializeUser(otherUser) : undefined,
    callActive: call.active,
    unreadCount,
    createdAt: room.createdAt.toISOString(),
    updatedAt: room.updatedAt.toISOString(),
  };
}

export async function listRoomsFor(viewerId: string) {
  const memberships = await db
    .select()
    .from(roomMembersTable)
    .where(eq(roomMembersTable.userId, viewerId));

  if (memberships.length === 0) return [];

  const rooms = await db
    .select()
    .from(roomsTable)
    .where(
      inArray(
        roomsTable.id,
        memberships.map((row) => row.roomId),
      ),
    )
    .orderBy(desc(roomsTable.updatedAt));

  const lastReadByRoom = new Map(
    memberships.map((row) => [row.roomId, row.lastReadAt]),
  );

  return Promise.all(
    rooms.map((room) =>
      serializeRoomSummary(
        room,
        viewerId,
        lastReadByRoom.get(room.id) ?? new Date(0),
      ),
    ),
  );
}

export async function touchRoom(roomId: string): Promise<void> {
  await db
    .update(roomsTable)
    .set({ updatedAt: new Date() })
    .where(eq(roomsTable.id, roomId));
}

export async function messagesPage(
  roomId: string,
  before: string | undefined,
  limit: number,
) {
  let beforeDate: Date | undefined;
  if (before) {
    const [anchor] = await db
      .select({ createdAt: messagesTable.createdAt })
      .from(messagesTable)
      .where(eq(messagesTable.id, before))
      .limit(1);
    beforeDate = anchor?.createdAt;
  }

  const rows = await db
    .select()
    .from(messagesTable)
    .where(
      beforeDate
        ? and(
            eq(messagesTable.roomId, roomId),
            lt(messagesTable.createdAt, beforeDate),
          )
        : eq(messagesTable.roomId, roomId),
    )
    .orderBy(desc(messagesTable.createdAt))
    .limit(limit);

  return rows.reverse();
}
