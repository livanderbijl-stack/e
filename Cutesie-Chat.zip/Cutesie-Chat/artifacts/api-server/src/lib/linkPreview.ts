import { lookup } from "dns/promises";
import http from "http";
import https from "https";
import { isIP } from "net";
import { db, linkPreviewsTable } from "@workspace/db";
import { logger } from "./logger";

const URL_PATTERN = /https?:\/\/[^\s<>"')]+/gi;

export function extractUrls(text: string | null | undefined): string[] {
  if (!text) return [];
  const matches = text.match(URL_PATTERN) ?? [];
  return [...new Set(matches)].slice(0, 3);
}

function metaContent(html: string, patterns: RegExp[]): string | null {
  for (const pattern of patterns) {
    const match = pattern.exec(html);
    if (match?.[1]) {
      return match[1]
        .replace(/&quot;/g, '"')
        .replace(/&#39;/g, "'")
        .replace(/&amp;/g, "&")
        .replace(/&lt;/g, "<")
        .replace(/&gt;/g, ">")
        .trim()
        .slice(0, 300);
    }
  }
  return null;
}

/**
 * Only ordinary public addresses are allowed out. IPv6 is deliberately
 * restricted to global unicast (2000::/3), which rejects loopback, unique-local,
 * link-local and every IPv4-mapped form at once — including the compressed
 * hex spelling Node produces for `::ffff:127.0.0.1`.
 */
function isPublicAddress(address: string): boolean {
  const family = isIP(address);

  if (family === 6) {
    const normalized = address.toLowerCase();
    const head = Number.parseInt(normalized.split(":")[0] || "0", 16);
    if (Number.isNaN(head)) return false;
    // Global unicast only, minus the documentation and ORCHID reservations
    // that sit inside it.
    if (head < 0x2000 || head > 0x3fff) return false;
    if (normalized.startsWith("2001:db8:")) return false;
    if (head === 0x2001) {
      const second = Number.parseInt(normalized.split(":")[1] || "0", 16);
      // 2001::/23 is IETF protocol assignments (Teredo, ORCHID, benchmarking).
      if (!Number.isNaN(second) && second <= 0x01ff) return false;
    }
    return true;
  }

  if (family !== 4) return false;

  const parts = address.split(".").map(Number);
  if (parts.length !== 4 || parts.some((part) => Number.isNaN(part))) {
    return false;
  }

  const [a, b, c] = parts as [number, number, number, number];
  if (a === 0 || a === 10 || a === 127) return false;
  if (a === 169 && b === 254) return false;
  if (a === 172 && b >= 16 && b <= 31) return false;
  if (a === 192 && b === 168) return false;
  if (a === 192 && b === 0 && (c === 0 || c === 2)) return false;
  if (a === 192 && b === 88 && c === 99) return false;
  if (a === 198 && (b === 18 || b === 19)) return false;
  if (a === 198 && b === 51 && c === 100) return false;
  if (a === 203 && b === 0 && c === 113) return false;
  if (a === 100 && b >= 64 && b <= 127) return false;
  if (a >= 224) return false;
  return true;
}

type Destination = { address: string; family: 4 | 6 };

/**
 * Message text is user supplied, so a preview fetch must never be able to reach
 * anything on the private network. Each hop resolves the host itself and the
 * request is then pinned to the address that was checked, so a second
 * resolution cannot swing the connection somewhere else.
 */
async function resolveSafely(
  url: URL,
  deadlineAt: number,
): Promise<Destination | null> {
  if (url.protocol !== "http:" && url.protocol !== "https:") return null;

  const host = url.hostname.replace(/^\[|\]$/g, "");

  const literal = isIP(host);
  if (literal) {
    return isPublicAddress(host)
      ? { address: host, family: literal === 6 ? 6 : 4 }
      : null;
  }

  if (host === "localhost" || host.endsWith(".localhost")) return null;
  if (host.endsWith(".internal") || host.endsWith(".local")) return null;

  const remaining = deadlineAt - Date.now();
  if (remaining <= 0) return null;

  try {
    // dns.lookup has no timeout of its own, so it races the shared deadline.
    const records = await Promise.race([
      lookup(host, { all: true }),
      new Promise<null>((resolve) =>
        setTimeout(() => resolve(null), remaining),
      ),
    ]);
    if (!records) return null;

    const usable = records.find((record) => isPublicAddress(record.address));
    if (!usable) return null;
    if (!records.every((record) => isPublicAddress(record.address))) {
      return null;
    }
    return {
      address: usable.address,
      family: usable.family === 6 ? 6 : 4,
    };
  } catch {
    return null;
  }
}

const MAX_BODY_BYTES = 200_000;
const REQUEST_DEADLINE_MS = 5000;

type HopResult =
  | { kind: "redirect"; location: string }
  | { kind: "body"; contentType: string; html: string }
  | { kind: "stop" };

/**
 * One HTTP hop, pinned to an already-validated address, with a deadline that
 * stays armed while the body streams and a hard cap on how much is read.
 */
function requestHop(
  url: URL,
  destination: Destination,
  deadlineAt: number,
): Promise<HopResult> {
  return new Promise((resolve) => {
    const transport = url.protocol === "https:" ? https : http;
    const remaining = deadlineAt - Date.now();
    if (remaining <= 0) {
      resolve({ kind: "stop" });
      return;
    }

    let settled = false;
    const finish = (result: HopResult) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      request.destroy();
      resolve(result);
    };

    const request = transport.request(
      url,
      {
        method: "GET",
        headers: {
          "user-agent": "CutesieChatBot/1.0 (+link preview)",
          accept: "text/html",
        },
        // Pin the socket to the address that passed validation.
        lookup: (_hostname, options, callback) => {
          const entry = {
            address: destination.address,
            family: destination.family,
          };
          if (options && typeof options === "object" && options.all) {
            (
              callback as unknown as (
                err: null,
                addrs: (typeof entry)[],
              ) => void
            )(null, [entry]);
            return;
          }
          (
            callback as unknown as (
              err: null,
              address: string,
              family: number,
            ) => void
          )(null, entry.address, entry.family);
        },
      },
      (response) => {
        const status = response.statusCode ?? 0;

        if (status >= 300 && status < 400) {
          const location = response.headers.location;
          response.resume();
          finish(location ? { kind: "redirect", location } : { kind: "stop" });
          return;
        }

        const contentType = response.headers["content-type"] ?? "";
        if (
          status < 200 ||
          status >= 300 ||
          !contentType.includes("text/html")
        ) {
          response.resume();
          finish({ kind: "stop" });
          return;
        }

        let received = 0;
        const chunks: Buffer[] = [];

        response.on("data", (chunk: Buffer) => {
          received += chunk.length;
          chunks.push(
            received > MAX_BODY_BYTES
              ? chunk.subarray(0, chunk.length - (received - MAX_BODY_BYTES))
              : chunk,
          );
          if (received >= MAX_BODY_BYTES) {
            finish({
              kind: "body",
              contentType,
              html: Buffer.concat(chunks).toString("utf8"),
            });
          }
        });

        response.on("end", () => {
          finish({
            kind: "body",
            contentType,
            html: Buffer.concat(chunks).toString("utf8"),
          });
        });

        response.on("error", () => finish({ kind: "stop" }));
      },
    );

    const timer = setTimeout(() => finish({ kind: "stop" }), remaining);

    request.on("error", () => finish({ kind: "stop" }));
    request.end();
  });
}

type Preview = {
  url: string;
  title: string | null;
  description: string | null;
  imageUrl: string | null;
  siteName: string | null;
};

/**
 * Best-effort Open Graph scrape. Never throws — a link that cannot be read
 * simply gets a bare card with its URL.
 */
export async function fetchPreview(url: string): Promise<Preview> {
  const fallback: Preview = {
    url,
    title: null,
    description: null,
    imageUrl: null,
    siteName: null,
  };

  try {
    const deadlineAt = Date.now() + REQUEST_DEADLINE_MS;

    let target: URL;
    try {
      target = new URL(url);
    } catch {
      return fallback;
    }

    // Redirects are followed by hand so every hop is re-validated.
    let html: string | null = null;
    for (let hop = 0; hop < 4; hop += 1) {
      const destination = await resolveSafely(target, deadlineAt);
      if (!destination) return fallback;

      const result = await requestHop(target, destination, deadlineAt);

      if (result.kind === "redirect") {
        try {
          target = new URL(result.location, target);
        } catch {
          return fallback;
        }
        continue;
      }

      if (result.kind === "body") html = result.html;
      break;
    }

    if (html === null) return fallback;

    return {
      url,
      title:
        metaContent(html, [
          /<meta[^>]+property=["']og:title["'][^>]+content=["']([^"']+)["']/i,
          /<meta[^>]+content=["']([^"']+)["'][^>]+property=["']og:title["']/i,
          /<title[^>]*>([^<]+)<\/title>/i,
        ]) ?? null,
      description: metaContent(html, [
        /<meta[^>]+property=["']og:description["'][^>]+content=["']([^"']+)["']/i,
        /<meta[^>]+name=["']description["'][^>]+content=["']([^"']+)["']/i,
      ]),
      imageUrl: metaContent(html, [
        /<meta[^>]+property=["']og:image["'][^>]+content=["']([^"']+)["']/i,
        /<meta[^>]+content=["']([^"']+)["'][^>]+property=["']og:image["']/i,
      ]),
      siteName:
        metaContent(html, [
          /<meta[^>]+property=["']og:site_name["'][^>]+content=["']([^"']+)["']/i,
        ]) ?? new URL(url).hostname.replace(/^www\./, ""),
    };
  } catch (error) {
    logger.debug({ err: error, url }, "Link preview lookup failed");
    return fallback;
  }
}

export async function storePreviews(
  messageId: string,
  urls: string[],
): Promise<boolean> {
  if (urls.length === 0) return false;

  const previews = await Promise.all(urls.map((url) => fetchPreview(url)));
  const usable = previews.filter(
    (preview) => preview.title || preview.description || preview.imageUrl,
  );
  if (usable.length === 0) return false;

  await db
    .insert(linkPreviewsTable)
    .values(usable.map((preview) => ({ messageId, ...preview })));

  return true;
}
