import type { IncomingMessage, Server as HttpServer } from "http";
import type { Duplex } from "stream";
import { WebSocketServer, WebSocket } from "ws";
import { clerkClient } from "@clerk/express";
import { db, roomMembersTable, callParticipantsTable } from "@workspace/db";
import { and, eq } from "drizzle-orm";
import { logger } from "./logger";
import { resolveLocalUser } from "./auth";
import { addPresence, removePresence } from "./presence";
import { getCallState } from "./data";

type Frame = Record<string, unknown> & { type: string };

type Socket = WebSocket & { userId?: string; displayName?: string };

const sockets = new Map<string, Set<Socket>>();

function track(userId: string, socket: Socket): void {
  const existing = sockets.get(userId) ?? new Set<Socket>();
  existing.add(socket);
  sockets.set(userId, existing);
}

function untrack(userId: string, socket: Socket): void {
  const existing = sockets.get(userId);
  if (!existing) return;
  existing.delete(socket);
  if (existing.size === 0) sockets.delete(userId);
}

export function sendToUser(userId: string, frame: Frame): void {
  const targets = sockets.get(userId);
  if (!targets) return;
  const payload = JSON.stringify(frame);
  for (const socket of targets) {
    if (socket.readyState === WebSocket.OPEN) socket.send(payload);
  }
}

export function sendToUsers(userIds: string[], frame: Frame): void {
  for (const userId of new Set(userIds)) sendToUser(userId, frame);
}

/**
 * Never rejects. Most callers fire this after the HTTP response has already
 * gone out, so a failed lookup must not become an unhandled rejection.
 */
export async function broadcastToRoom(
  roomId: string,
  frame: Frame,
  exceptUserId?: string,
): Promise<void> {
  try {
    const members = await db
      .select({ userId: roomMembersTable.userId })
      .from(roomMembersTable)
      .where(eq(roomMembersTable.roomId, roomId));

    for (const member of members) {
      if (member.userId === exceptUserId) continue;
      sendToUser(member.userId, frame);
    }
  } catch (error) {
    logger.error({ err: error, roomId }, "Failed to broadcast to room");
  }
}

async function isRoomMember(roomId: string, userId: string): Promise<boolean> {
  const [row] = await db
    .select({ id: roomMembersTable.id })
    .from(roomMembersTable)
    .where(
      and(
        eq(roomMembersTable.roomId, roomId),
        eq(roomMembersTable.userId, userId),
      ),
    )
    .limit(1);
  return Boolean(row);
}

async function broadcastPresence(userId: string, online: boolean) {
  const rooms = await db
    .select({ roomId: roomMembersTable.roomId })
    .from(roomMembersTable)
    .where(eq(roomMembersTable.userId, userId));

  const seen = new Set<string>();
  for (const room of rooms) {
    const members = await db
      .select({ userId: roomMembersTable.userId })
      .from(roomMembersTable)
      .where(eq(roomMembersTable.roomId, room.roomId));
    for (const member of members) {
      if (member.userId === userId || seen.has(member.userId)) continue;
      seen.add(member.userId);
      sendToUser(member.userId, { type: "presence", userId, isOnline: online });
    }
  }
}

/**
 * Verifies the Clerk session on the websocket handshake. The browser sends the
 * same cookies it uses for normal API calls, so the upgrade request can be
 * authenticated with Clerk's request authenticator.
 */
async function authenticateUpgrade(
  request: IncomingMessage,
): Promise<string | null> {
  try {
    const protocol =
      (request.headers["x-forwarded-proto"] as string | undefined)?.split(
        ",",
      )[0] ?? "http";
    const host =
      (request.headers["x-forwarded-host"] as string | undefined)?.split(
        ",",
      )[0] ??
      request.headers.host ??
      "localhost";

    const headers = new Headers();
    for (const [key, value] of Object.entries(request.headers)) {
      if (Array.isArray(value)) {
        for (const item of value) headers.append(key, item);
      } else if (typeof value === "string") {
        headers.set(key, value);
      }
    }

    const fetchRequest = new Request(
      `${protocol}://${host}${request.url ?? "/ws"}`,
      { headers },
    );

    const state = await clerkClient.authenticateRequest(fetchRequest);
    const auth = state.toAuth();
    return auth && "userId" in auth ? (auth.userId ?? null) : null;
  } catch (error) {
    logger.warn({ err: error }, "Websocket authentication failed");
    return null;
  }
}

export function initRealtime(server: HttpServer): void {
  // Frames here are small control messages and WebRTC descriptions; the ws
  // default of ~100MiB would let one client exhaust the process.
  const wss = new WebSocketServer({ noServer: true, maxPayload: 64 * 1024 });

  server.on("upgrade", (request: IncomingMessage, socket: Duplex, head) => {
    const pathname = (request.url ?? "").split("?")[0];
    if (pathname !== "/ws") return;

    void (async () => {
      const clerkUserId = await authenticateUpgrade(request);
      if (!clerkUserId) {
        socket.write("HTTP/1.1 401 Unauthorized\r\n\r\n");
        socket.destroy();
        return;
      }

      let localUserId: string;
      let displayName: string;
      try {
        const user = await resolveLocalUser(clerkUserId);
        localUserId = user.id;
        displayName = user.displayName;
      } catch (error) {
        logger.error({ err: error }, "Websocket profile lookup failed");
        socket.write("HTTP/1.1 500 Internal Server Error\r\n\r\n");
        socket.destroy();
        return;
      }

      wss.handleUpgrade(request, socket, head, (ws) => {
        const client = ws as Socket;
        client.userId = localUserId;
        client.displayName = displayName;
        wss.emit("connection", client, request);
      });
    })();
  });

  wss.on("connection", (socket: Socket) => {
    const userId = socket.userId;
    if (!userId) {
      socket.close();
      return;
    }

    track(userId, socket);
    if (addPresence(userId)) {
      void broadcastPresence(userId, true).catch((error: unknown) => {
        logger.warn({ err: error }, "Failed to broadcast presence");
      });
    }

    socket.send(JSON.stringify({ type: "ready", userId }));

    socket.on("message", (raw) => {
      let parsed: unknown;
      try {
        parsed = JSON.parse(raw.toString());
      } catch {
        return;
      }

      if (
        typeof parsed !== "object" ||
        parsed === null ||
        typeof (parsed as { type?: unknown }).type !== "string"
      ) {
        return;
      }

      const frame = parsed as Frame;

      if (frame.type === "ping") {
        socket.send(JSON.stringify({ type: "pong" }));
        return;
      }

      if (frame.type === "typing" && typeof frame.roomId === "string") {
        const roomId = frame.roomId;
        const isTyping = Boolean(frame.isTyping);
        void (async () => {
          if (!(await isRoomMember(roomId, userId))) return;
          await broadcastToRoom(
            roomId,
            {
              type: "typing",
              roomId,
              userId,
              displayName: socket.displayName ?? "Someone",
              isTyping,
            },
            userId,
          );
        })().catch((error: unknown) => {
          logger.warn({ err: error }, "Failed to relay typing frame");
        });
        return;
      }

      if (
        frame.type === "call:signal" &&
        typeof frame.roomId === "string" &&
        typeof frame.toUserId === "string"
      ) {
        const roomId = frame.roomId;
        const toUserId = frame.toUserId;
        const signal = frame.signal;
        // Both ends must belong to the room, so a signed-in stranger cannot
        // push WebRTC offers at arbitrary people.
        void (async () => {
          const [senderIsMember, recipientIsMember] = await Promise.all([
            isRoomMember(roomId, userId),
            isRoomMember(roomId, toUserId),
          ]);
          if (!senderIsMember || !recipientIsMember) return;

          sendToUser(toUserId, {
            type: "call:signal",
            roomId,
            fromUserId: userId,
            toUserId,
            signal,
          });
        })().catch((error: unknown) => {
          logger.warn({ err: error }, "Failed to relay call signal");
        });
      }
    });

    socket.on("close", () => {
      untrack(userId, socket);
      if (removePresence(userId)) {
        void broadcastPresence(userId, false).catch((error: unknown) => {
          logger.warn({ err: error }, "Failed to broadcast presence");
        });
        void dropFromCalls(userId);
      }
    });
  });

  logger.info("Realtime websocket server listening on /ws");
}

/**
 * When someone's last connection drops, take them out of any live call so the
 * call state does not keep showing ghosts.
 */
async function dropFromCalls(userId: string): Promise<void> {
  try {
    const rows = await db
      .select({ roomId: callParticipantsTable.roomId })
      .from(callParticipantsTable)
      .where(eq(callParticipantsTable.userId, userId));

    for (const row of rows) {
      await db
        .delete(callParticipantsTable)
        .where(
          and(
            eq(callParticipantsTable.roomId, row.roomId),
            eq(callParticipantsTable.userId, userId),
          ),
        );
      const call = await getCallState(row.roomId);
      await broadcastToRoom(row.roomId, {
        type: "call:state",
        roomId: row.roomId,
        call,
      });
    }
  } catch (error) {
    logger.error({ err: error }, "Failed to clean up calls on disconnect");
  }
}
