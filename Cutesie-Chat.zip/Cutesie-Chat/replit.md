# Cutesie Chat

A cozy private chat space where a small group of friends can DM, make group "forts", share files and links, and hop on video calls together.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (serves `/api` and the `/ws` websocket)
- `pnpm --filter @workspace/cutesie-chat run dev` — run the web client
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL`, `CLERK_SECRET_KEY`, `CLERK_PUBLISHABLE_KEY`, `VITE_CLERK_PUBLISHABLE_KEY`, `DEFAULT_OBJECT_STORAGE_BUCKET_ID`, `PUBLIC_OBJECT_SEARCH_PATHS`, `PRIVATE_OBJECT_DIR`

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5, `ws` for realtime
- Web: React 19 + Vite + Tailwind v4 + wouter + TanStack Query
- Auth: Replit-managed Clerk (cookie sessions, no bearer tokens)
- DB: PostgreSQL + Drizzle ORM
- Files: Replit object storage with direct-to-bucket uploads via Uppy
- API codegen: Orval (from OpenAPI spec)

## Where things live

- `lib/api-spec/openapi.yaml` — the API contract; the source of truth. Everything in `lib/api-client-react/src/generated` and `lib/api-zod/src/generated` is generated from it, never hand-edited.
- `lib/db/src/schema/` — one file per table, re-exported from `index.ts`.
- `artifacts/api-server/src/lib/` — `auth.ts` (Clerk → local user), `data.ts` (all serializers and shared queries), `realtime.ts` (websocket hub), `presence.ts`, `linkPreview.ts`, `serving.ts`.
- `artifacts/api-server/src/routes/` — one file per resource group, mounted in `routes/index.ts`.
- `artifacts/cutesie-chat/src/` — `pages/` per screen, `lib/realtime.tsx` (websocket context), `lib/webrtc.ts` (peer connections), `index.css` (the whole theme).

## Architecture decisions

- Local users are created just-in-time from the Clerk session on first authenticated request, so there is no signup webhook to keep in sync.
- Realtime and WebRTC signaling share one websocket at `/ws`, authenticated with the same Clerk session cookie as the REST API. Presence is derived from open connection counts, not stored state.
- Video calls are peer-to-peer mesh with a public STUN server — no media server. Practical for small friend groups, not for large rooms.
- Link previews are scraped after a message is saved and pushed out as a `message:updated` frame, so sending never waits on a third-party site.
- `listMessages` is `GET /messages?roomId=...` rather than a nested path. See Gotchas.

## Product

Friend requests by username, private DMs, group forts with colours and members, image/video/file sharing, link cards, emoji reactions, typing indicators, presence, per-room media galleries, and peer-to-peer group video calls.

## Gotchas

- An OpenAPI operation must not mix path params and query params — Orval then emits a `<Op>Params` type in both generated packages and the build fails with TS2308. Put the identifier in the query string instead.
- `artifact.toml` files are never edited directly; change them through the artifact tooling's verify-and-replace flow.
- React 19 is pinned through `overrides` in `pnpm-workspace.yaml` (not `package.json`, since the root has no direct react dependency).

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
