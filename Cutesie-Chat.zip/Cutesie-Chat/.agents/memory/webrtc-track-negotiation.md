---
name: WebRTC track and negotiation traps
description: Non-obvious rules for adding media to an existing peer connection and for keeping signalling from silently dropping.
---

## Use addTrack, not replaceTrack, to add media mid-call

When a peer joined without a camera it holds `recvonly` transceivers. Before sending media
after permission is granted, explicitly change the matching transceiver's direction to
`sendrecv`, then call `pc.addTrack(track, stream)`. A `recvonly` transceiver is not eligible
for addTrack's reuse algorithm until its direction allows sending.

`sender.replaceTrack(track)` looks equivalent and fails in two ways if used by itself: it
does not change the transceiver direction (so nothing is sent, and no renegotiation fires),
and it carries no msid, so the far side's `ontrack` fires with an empty `event.streams`.
Any handler that reads `event.streams[0]` drops that track on the floor.

**How to apply:** whenever media is attached to a connection that already exists. Also make
`ontrack` fall back to a per-peer `MediaStream` when `event.streams` is empty, because a
remote peer may have used replaceTrack.

## Verify remote frames, not just tracks

For restricted-network fixes, require a forced-relay test with a selected relay
candidate pair and increasing inbound decoded video frames at both ends.

**Why:** local camera previews, ontrack events, and successful same-machine direct
connections have repeatedly passed while users still saw no remote video.
An attached provider connection also does not prove its credentials can issue TURN tokens.

**How to apply:** validate provider authentication before promising relay availability;
report blocked authentication explicitly rather than calling local-only tests a fix.

## Signals must be applied in order, one at a time

Frames arrive in bursts from a websocket relay. Handling only the newest one, or applying
two concurrently, corrupts the signalling state. Keep a per-peer promise chain, and on the
consumer side keep a cursor so every frame is handled exactly once.

## ICE candidates need generation-aware buffering

Buffer a candidate when there is no remote description **or** when its `usernameFragment`
does not appear as an `a=ice-ufrag:` line in the current remote SDP, then drain after each
`setRemoteDescription`. Checking only for the presence of a remote description is not
enough: after `restartIce()` the old description is still in place, so new-generation
candidates get applied to the old one, rejected, and lost.

## A media failure must reach the UI

`getUserMedia` failing and being logged to the console reads to the user as "camera and mic
don't work" with no explanation. Map the DOMException to a message and show it, keep the
person in the call as a listener, and offer a retry. Distinguish a real user denial from a
 Permissions-Policy block (an embedded preview iframe) — the second one is fixed by opening
 the app in its own tab, and only the message text distinguishes them.

## Remote video needs an autoplay fallback

Attaching a remote `MediaStream` to a video element is not enough: after navigation,
browsers can reject unmuted autoplay, leaving the tile visually blank even though the
tracks and peer connection are healthy. Call `play()` when metadata/canplay arrives;
if it is rejected, temporarily mute and retry so video renders, then offer a user-click
path to restore sound.

**Why:** the call page is a new document after the user clicks Start Call, so that click
does not reliably count as activation for an unmuted remote media element.

**How to apply:** whenever remote audio and video share one autoplaying `<video>` element.
