---
name: Workspace and tooling quirks
description: Non-obvious rules for changing artifact config and pinning dependency versions in this monorepo.
---

## artifact.toml edits

Never edit an artifact.toml in place. Write the full replacement to a temp file and
run the verify-and-replace tool. That tool requires an ABSOLUTE path for the existing
artifact.toml — a workspace-relative path is rejected outright.

**Why:** the file drives the generated workflow and the preview routing; an unvalidated
edit can leave the artifact unroutable.

## Building a web artifact needs PORT and BASE_PATH

The web artifact's vite.config.ts throws unless both `PORT` and `BASE_PATH` are set, so a
bare `pnpm --filter <artifact> run build` always fails. Set them on the command:
`PORT=5999 BASE_PATH=/ pnpm --filter <artifact> run build`.

**Why:** the config derives the dev server port and the router base path from the
environment the workflow provides; a manual shell build has no workflow around it.

**How to apply:** any time you verify a production build by hand, not just for one artifact.

## Running real browser checks without Playwright

Playwright is not installed at the root, but a chromium binary is available at
`/repl/tools/bin/chromium`, and esbuild can be borrowed from
`artifacts/api-server/node_modules/.bin/esbuild`. That is enough to bundle a browser
module, serve it from a throwaway node http server, run it in headless chromium
(`--headless=new --no-sandbox`), and have the page POST results back.

**Why:** the testing subagent's browser exposes no media devices and cannot evaluate
arbitrary in-page logic, so browser-API-heavy code (WebRTC, canvas capture, media
devices) cannot be verified through it. `--use-fake-device-for-media-stream` in a
self-driven chromium gives a working fake camera and mic.

**How to apply:** for any browser-API logic that needs devices or two instances talking
to each other. Keep the harness in /tmp — note /tmp files can be reaped between commands,
so re-write them if a run reports a missing module.

## Pinning a version across the workspace

Dependency overrides for packages the root does not depend on directly must go in the
`overrides` block of pnpm-workspace.yaml. The `"$pkg"` shorthand in the root
package.json only resolves when the root itself declares that dependency, so it fails
for things like react in an artifact-only setup.
