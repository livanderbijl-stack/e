---
name: OpenAPI operations must not mix path and query params
description: Orval codegen gotchas — param naming collisions, and the shape of generated query keys when matching them in React Query.
---

An operation that declares BOTH a path parameter and a query parameter makes Orval
emit a type named `<OperationId>Params` in two places at once: the path-param shape
in the api-zod generated api.ts, and the query-param shape in the api-client-react
generated types. Both are re-exported from the same barrel, so the build fails with
TS2308 (duplicate export) and no amount of editing the generated files helps.

**Why:** it is a codegen naming collision, not a spec error, so the spec looks
perfectly valid while the workspace typecheck fails.

**How to apply:** when an endpoint needs both an identifier and filters/pagination,
put the identifier in the query string too (`GET /messages?roomId=...&before=...`)
rather than nesting it in the path. Path params are fine on their own; query params
are fine on their own.

## Generated query keys are request paths, not id tuples

An Orval query key is the interpolated request path plus an optional params object:
`["/api/rooms/<id>"]`, or `["/api/messages", { roomId, limit }]`. There is no bare id
element in the key.

**Why:** a React Query `removeQueries`/`invalidateQueries` predicate written as
`key.some(part => part === id)` silently matches nothing, so the cache keeps serving the
old data and the bug looks like a server or routing problem.

**How to apply:** to match every query scoped to one resource, test string elements with
`includes(id)` and object elements by their id field. Needed whenever access can be
revoked mid-session (leaving or being removed from a room) — there, remove rather than
invalidate, since a forbidden refetch leaves previously fetched data renderable.
